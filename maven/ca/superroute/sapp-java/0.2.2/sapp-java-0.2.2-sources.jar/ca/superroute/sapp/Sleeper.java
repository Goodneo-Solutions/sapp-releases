package ca.superroute.sapp;

/** Waits between retries; tests pass one that does not sleep. */
@FunctionalInterface
public interface Sleeper {
    void sleep(long millis) throws InterruptedException;
}
