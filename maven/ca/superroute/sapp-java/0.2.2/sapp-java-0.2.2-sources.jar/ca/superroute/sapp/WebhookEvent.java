package ca.superroute.sapp;

/**
 * A verified webhook. {@code type} is the Superroute event type without the CloudEvents {@code ca.superroute.}
 * prefix; {@code business} the sending business (CloudEvents {@code srbusiness}); {@code attempt} the delivery
 * attempt (CloudEvents binary {@code ce-srattempt}); {@code format} is {@code native}, {@code ce_binary} or
 * {@code ce_structured}; {@code data} the event (the body, or a structured envelope's {@code data}) and
 * {@code payload} the whole parsed body, both as {@link Json} values.
 */
public record WebhookEvent(String id, String type, String time, String subject, String source, Long business,
                           Long attempt, String format, Object data, Object payload) {
}
