package ca.superroute.sapp;

import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;
import java.util.function.LongSupplier;

/**
 * The partner profile: an app registered on the Open Platform console, acting for one person at one service provider
 * (docs/PLATFORM-APP-SDK-DESIGN.md §8).
 *
 * <pre>{@code
 * PartnerClient sr = PartnerClient.builder("p_acme_parcels").clientCode("k3m9q2").appKey("sp_appkey_…").build();
 * sr.signInWithIdToken(googleIdToken);
 * Object notifications = sr.api.platformAppNotifications();
 * }</pre>
 *
 * Safe to share between threads: concurrent calls that need a refresh wait for the same one.
 */
public final class PartnerClient {
    public static final String SDK_VERSION = Http.SDK_VERSION;
    public static final String DEFAULT_BASE_URL = Http.DEFAULT_BASE_URL;
    private static final String TOKEN_EXCHANGE = "urn:ietf:params:oauth:grant-type:token-exchange";
    private static final String ID_TOKEN = "urn:ietf:params:oauth:token-type:id_token";
    /** Refresh this long before the access token expires, so a call never starts with a token about to lapse. */
    private static final long REFRESH_MARGIN_MS = 60_000L;

    public final String appCode;
    public final String appKey;
    public final String baseUrl;
    public final TokenStore tokenStore;
    private volatile String clientCode;
    private volatile String locale;
    private final String deviceId;
    private final int retries;
    private final Transport transport;
    private final LongSupplier clock;
    private final Sleeper sleeper;
    private final Runnable onSignedOut;
    private final List<Consumer<Boolean>> listeners = new CopyOnWriteArrayList<>();
    private final Object refreshLock = new Object();
    private CompletableFuture<Tokens> refreshing;

    /** One method per operation of the partner surface. */
    public final PartnerApi api;

    private PartnerClient(Builder b) {
        this.appCode = b.appCode;
        this.clientCode = b.clientCode;
        this.appKey = b.appKey;
        this.tokenStore = b.tokenStore != null ? b.tokenStore : new MemoryTokenStore();
        this.baseUrl = Http.trimSlash(b.baseUrl);
        this.locale = b.locale;
        this.deviceId = b.deviceId;
        this.retries = b.retries;
        this.transport = b.transport != null ? b.transport : new HttpClientTransport();
        this.clock = b.clock;
        this.sleeper = b.sleeper;
        this.onSignedOut = b.onSignedOut;
        this.api = new PartnerApi(this::call);
    }

    public static Builder builder(String appCode) {
        return new Builder(appCode);
    }

    /** Options of a {@link PartnerClient}. */
    public static final class Builder {
        private final String appCode;
        private String clientCode;
        private String appKey;
        private TokenStore tokenStore;
        private String baseUrl = Http.DEFAULT_BASE_URL;
        private String locale;
        private String deviceId;
        private int retries = 2;
        private Transport transport;
        private LongSupplier clock = System::currentTimeMillis;
        private Sleeper sleeper = Thread::sleep;
        private Runnable onSignedOut;

        private Builder(String appCode) {
            if (appCode == null || appCode.isEmpty()) throw new IllegalArgumentException("appCode is required");
            this.appCode = appCode;
        }

        /** The service provider's public client code; required for sign-in and public calls. */
        public Builder clientCode(String v) { clientCode = v; return this; }
        /** The restricted key for calls before sign-in. */
        public Builder appKey(String v) { appKey = v; return this; }
        public Builder tokenStore(TokenStore v) { tokenStore = v; return this; }
        public Builder baseUrl(String v) { baseUrl = v; return this; }
        /** Sent as Accept-Language. */
        public Builder locale(String v) { locale = v; return this; }
        public Builder deviceId(String v) { deviceId = v; return this; }
        /** Retries of a repeatable call (2 by default). */
        public Builder retries(int v) { retries = v; return this; }
        public Builder transport(Transport v) { transport = v; return this; }
        /** Milliseconds since the epoch. */
        public Builder clock(LongSupplier v) { clock = v; return this; }
        /** Waits between retries (milliseconds). */
        public Builder sleeper(Sleeper v) { sleeper = v; return this; }
        /** Called when the session ends. */
        public Builder onSignedOut(Runnable v) { onSignedOut = v; return this; }

        public PartnerClient build() {
            return new PartnerClient(this);
        }
    }

    // ------------------------------------------------------------------------------------------ session

    /** Change the service provider, e.g. after the person picked one at sign-up. Sign in again afterwards. */
    public void setClientCode(String code) {
        this.clientCode = code;
    }

    public String clientCode() {
        return clientCode;
    }

    public void setLocale(String locale) {
        this.locale = locale;
    }

    /** Called with true when a sign-in starts a session and false when it ends. Answers the function that stops it. */
    public Runnable onSessionChange(Consumer<Boolean> listener) {
        listeners.add(listener);
        return () -> listeners.remove(listener);
    }

    private void emit(boolean signedIn) {
        for (Consumer<Boolean> l : listeners) {
            try {
                l.accept(signedIn);
            } catch (RuntimeException ignored) {
                // A listener's error never breaks the session.
            }
        }
    }

    private String requireClientCode() {
        if (clientCode == null || clientCode.isEmpty()) throw new IllegalStateException("clientCode is required to sign in");
        return clientCode;
    }

    private Map<String, String> formHeaders() {
        Map<String, String> h = Http.headers(locale);
        h.put("Content-Type", "application/x-www-form-urlencoded");
        return h;
    }

    private Tokens tokenRequest(Map<String, String> fields) {
        Map<String, String> all = new LinkedHashMap<>();
        all.put("client_id", appCode);
        fields.forEach((k, v) -> { if (v != null && !v.isEmpty()) all.put(k, v); });
        Transport.Request request = new Transport.Request("POST", baseUrl + "/app/oauth/token", formHeaders(), Http.form(all).getBytes(StandardCharsets.UTF_8));
        Object body = Http.send(transport, sleeper, request, 0, false).orThrow();
        Map<?, ?> map = body instanceof Map<?, ?> m ? m : Map.of();
        if (!(map.get("access_token") instanceof String access)) {
            throw new SuperrouteException(200, "invalid_response", "The token answer had no access token.", body);
        }
        double expiresIn = map.get("expires_in") instanceof Number n ? n.doubleValue() : 3600;
        List<String> scope = new ArrayList<>();
        if (map.get("scope") instanceof String s) for (String part : s.split(" ")) if (!part.isEmpty()) scope.add(part);
        Tokens tokens = new Tokens(access, map.get("refresh_token") instanceof String r ? r : null, clock.getAsLong() + (long) (expiresIn * 1000), scope);
        boolean wasSignedIn = tokenStore.read() != null;
        tokenStore.write(tokens);
        if (!wasSignedIn) emit(true);
        return tokens;
    }

    private void endSession() {
        tokenStore.clear();
        if (onSignedOut != null) onSignedOut.run();
        emit(false);
    }

    /** The Superroute sign-in page (method 1): open the URL in the system browser and pass what it returns to {@link #completeSignIn}. */
    public AuthorizationRequest authorizationRequest(String redirectUri) {
        return authorizationRequest(redirectUri, List.of(), null);
    }

    public AuthorizationRequest authorizationRequest(String redirectUri, List<String> scope, String language) {
        Pkce.Pair pkce = Pkce.create();
        String state = Pkce.randomString(16);
        Map<String, String> q = new LinkedHashMap<>();
        q.put("response_type", "code");
        q.put("client_id", appCode);
        q.put("client_code", requireClientCode());
        q.put("redirect_uri", redirectUri);
        q.put("state", state);
        q.put("code_challenge", pkce.challenge());
        q.put("code_challenge_method", "S256");
        if (scope != null && !scope.isEmpty()) q.put("scope", String.join(" ", scope));
        String lang = language != null ? language : locale;
        if (lang != null) q.put("language", lang);
        return new AuthorizationRequest(baseUrl + "/app/oauth/authorize?" + Http.form(q), pkce.verifier(), state, redirectUri);
    }

    /** Finishes method 1 with the URL the sign-in page returned to. Throws when it does not belong to the request. */
    public Tokens completeSignIn(AuthorizationRequest request, String returnedUrl) {
        Map<String, String> query = new LinkedHashMap<>();
        String raw = URI.create(returnedUrl).getRawQuery();
        if (raw != null) {
            for (String pair : raw.split("&")) {
                if (pair.isEmpty()) continue;
                int eq = pair.indexOf('=');
                String k = eq < 0 ? pair : pair.substring(0, eq);
                String v = eq < 0 ? "" : pair.substring(eq + 1);
                query.put(URLDecoder.decode(k, StandardCharsets.UTF_8), URLDecoder.decode(v, StandardCharsets.UTF_8));
            }
        }
        if (!request.state().equals(query.get("state"))) {
            throw new SuperrouteException(400, "invalid_state", "The sign-in answer does not belong to this request.");
        }
        if (query.get("error") != null) throw new SuperrouteException(400, query.get("error"), query.get("error_description"));
        return exchangeCode(query.get("code"), request.redirectUri(), request.verifier());
    }

    /** Finishes method 1 with the redirect's code and the verifier of the request. */
    public Tokens exchangeCode(String code, String redirectUri, String verifier) {
        Map<String, String> f = new LinkedHashMap<>();
        f.put("grant_type", "authorization_code");
        f.put("code", code);
        f.put("redirect_uri", redirectUri);
        f.put("code_verifier", verifier);
        f.put("device_id", deviceId);
        return tokenRequest(f);
    }

    /** Method 2: a Google or Apple ID token issued for one of the app's registered audiences. */
    public Tokens signInWithIdToken(String idToken) {
        return signInWithIdToken(idToken, List.of());
    }

    public Tokens signInWithIdToken(String idToken, List<String> scope) {
        Map<String, String> f = new LinkedHashMap<>();
        f.put("grant_type", TOKEN_EXCHANGE);
        f.put("client_code", requireClientCode());
        f.put("subject_token", idToken);
        f.put("subject_token_type", ID_TOKEN);
        f.put("scope", String.join(" ", scope));
        f.put("device_id", deviceId);
        return tokenRequest(f);
    }

    /** Method 3: email and password in the app's own screens, for apps approved for it. */
    public Tokens signInWithPassword(String username, String password) {
        return signInWithPassword(username, password, List.of());
    }

    public Tokens signInWithPassword(String username, String password, List<String> scope) {
        Map<String, String> f = new LinkedHashMap<>();
        f.put("grant_type", "password");
        f.put("client_code", requireClientCode());
        f.put("username", username);
        f.put("password", password);
        f.put("scope", String.join(" ", scope));
        f.put("device_id", deviceId);
        return tokenRequest(f);
    }

    /** One refresh at a time: concurrent callers wait for the same one (a refresh token works once). */
    public Tokens refresh() {
        CompletableFuture<Tokens> future;
        boolean owner = false;
        synchronized (refreshLock) {
            if (refreshing == null) {
                refreshing = new CompletableFuture<>();
                owner = true;
            }
            future = refreshing;
        }
        if (!owner) {
            try {
                return future.join();
            } catch (CompletionException e) {
                if (e.getCause() instanceof RuntimeException r) throw r;
                throw e;
            }
        }
        try {
            Tokens current = tokenStore.read();
            if (current == null || current.refreshToken() == null) {
                endSession();
                throw new SuperrouteException(401, "invalid_grant", "Not signed in.");
            }
            Tokens tokens;
            try {
                Map<String, String> f = new LinkedHashMap<>();
                f.put("grant_type", "refresh_token");
                f.put("refresh_token", current.refreshToken());
                f.put("device_id", deviceId);
                tokens = tokenRequest(f);
            } catch (SuperrouteException e) {
                if ("invalid_grant".equals(e.code) || e.status == 401) endSession();
                throw e;
            }
            future.complete(tokens);
            return tokens;
        } catch (RuntimeException e) {
            future.completeExceptionally(e);
            throw e;
        } finally {
            synchronized (refreshLock) {
                refreshing = null;
            }
        }
    }

    private String accessToken() {
        Tokens tokens = tokenStore.read();
        if (tokens == null) return null;
        if (tokens.refreshToken() != null && tokens.expiresAt() - REFRESH_MARGIN_MS <= clock.getAsLong()) return refresh().accessToken();
        return tokens.accessToken();
    }

    /** Ends this sign-in on the server and forgets the tokens. */
    public void signOut() {
        Tokens tokens = tokenStore.read();
        if (tokens != null && tokens.refreshToken() != null) {
            Map<String, String> f = new LinkedHashMap<>();
            f.put("token", tokens.refreshToken());
            f.put("client_id", appCode);
            try {
                Http.send(transport, sleeper, new Transport.Request("POST", baseUrl + "/app/oauth/revoke", formHeaders(), Http.form(f).getBytes(StandardCharsets.UTF_8)), 0, false);
            } catch (RuntimeException ignored) {
                // Signing out locally never waits on the network.
            }
        }
        endSession();
    }

    public boolean isSignedIn() {
        return tokenStore.read() != null;
    }

    // ------------------------------------------------------------------------------------------ calls

    private Map<String, String> headers(Operation operation) {
        Map<String, String> headers = Http.headers(locale);
        if (operation.auth == Operation.Auth.TOKEN || operation.auth == Operation.Auth.TOKEN_OR_KEY) {
            String token = accessToken();
            if (token != null) {
                headers.put("Authorization", "Bearer " + token);
                return headers;
            }
            if (operation.auth == Operation.Auth.TOKEN) throw new SuperrouteException(401, "invalid_token", "Not signed in.");
        }
        if ((operation.auth == Operation.Auth.KEY || operation.auth == Operation.Auth.TOKEN_OR_KEY) && appKey != null) {
            headers.put("X-App-Key", appKey);
        }
        return headers;
    }

    /**
     * Building on the sApp core: calls an operation described by hand exactly as the generated methods of {@link #api}
     * do — the same sign-in headers (the token, or the app key when the operation allows it), one refresh and retry
     * after a 401, an {@code Idempotency-Key} made once per call (and kept across that retry) when the operation
     * declares one and none is given, retries of GET calls, and {@link SuperrouteException} for a refusal (status 400
     * or more, or {@code "result": false}). Path and query values, header parameters (under the header's own name) and
     * the extra query (under {@link Args#EXTRA_QUERY}) travel in {@code params}; {@code {clientCode}} is filled from the
     * client when not given. For packages such as sLocker that add their own operations on top of this client.
     *
     * @param params path, query and header values, and the extra query; may be null
     * @param body the body of a JSON, form or multipart operation; may be null
     * @param files the files of a multipart operation; may be null
     */
    public Object callOperation(Operation operation, Map<String, Object> params, Map<String, ?> body, List<OperationFile> files) {
        return call(operation, params == null ? Map.of() : params, body, files == null ? List.of() : files);
    }

    /** {@link #callOperation(Operation, Map, Map, List)} without a body or files. */
    public Object callOperation(Operation operation, Map<String, Object> params) {
        return callOperation(operation, params, null, null);
    }

    private Object call(Operation operation, Map<String, Object> params, Map<String, ?> body, List<OperationFile> files) {
        Map<String, Object> values = new LinkedHashMap<>(params);
        // Public calls name the service provider in the path; take it from the client unless the caller passes one.
        if (operation.path.contains("{clientCode}") && values.get("clientCode") == null) values.put("clientCode", clientCode);
        String url = Http.buildUrl(baseUrl, operation, values);
        Http.Body encoded = Http.encode(operation.body, body, files);
        boolean retryable = operation.method.equals("GET");
        Map<String, String> perCall = Http.callHeaders(operation, values);
        Map<String, String> headers = headers(operation);
        Http.Answer answer = Http.send(transport, sleeper, request(operation, url, Http.withCallHeaders(headers, perCall), encoded), retries, retryable);
        // An access token can end early (revoked, the person's access changed): refresh once and try again.
        if (answer.status() == 401 && headers.containsKey("Authorization")) {
            refresh();
            headers = headers(operation);
            answer = Http.send(transport, sleeper, request(operation, url, Http.withCallHeaders(headers, perCall), encoded), retries, retryable);
        }
        return answer.orThrowRefused();
    }

    static Transport.Request request(Operation operation, String url, Map<String, String> headers, Http.Body encoded) {
        Map<String, String> h = new LinkedHashMap<>(headers);
        byte[] bytes = null;
        if (encoded != null) {
            h.put("Content-Type", encoded.contentType());
            bytes = encoded.bytes();
        } else if (operation.method.equals("POST") || operation.method.equals("PUT") || operation.method.equals("PATCH")) {
            bytes = new byte[0];
        }
        return new Transport.Request(operation.method, url, h, bytes);
    }

    /** A partner GraphQL operation (open.superroute.ca/app/graphql), with the token when signed in, else the app key. */
    public Object graphql(String query) {
        return graphql(query, Map.of());
    }

    public Object graphql(String query, Map<String, ?> variables) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("query", query);
        body.put("variables", variables == null ? Map.of() : variables);
        Object answer = call(new Operation("POST", "/app/graphql", Operation.Auth.TOKEN_OR_KEY, List.of(), Operation.Body.JSON), Map.of(), body, List.of());
        Map<?, ?> map = answer instanceof Map<?, ?> m ? m : Map.of();
        if (map.get("errors") instanceof List<?> errors && !errors.isEmpty()) {
            List<String> messages = new ArrayList<>();
            for (Object e : errors) messages.add(e instanceof Map<?, ?> em && em.get("message") instanceof String s ? s : "");
            throw new SuperrouteException(200, "graphql_error", String.join(" ", messages), answer);
        }
        return map.get("data");
    }
}
