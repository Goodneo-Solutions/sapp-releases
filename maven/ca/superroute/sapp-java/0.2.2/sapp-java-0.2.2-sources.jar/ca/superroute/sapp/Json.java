package ca.superroute.sapp;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The SDK's JSON codec: answers are plain Java values, {@code Map<String, Object>} (in the order sent),
 * {@code List<Object>}, {@code String}, {@code Long} (whole numbers that fit) or {@code Double}, {@code Boolean} and
 * null.
 *
 * <p>Why no JSON library: server applications already carry their own Jackson or Gson, often pinned to a version.
 * A dependency-free artifact can never conflict with them, and plain collections can be mapped onto your own types
 * by any of them ({@code objectMapper.convertValue(answer, Order.class)}).
 */
public final class Json {
    private Json() {
    }

    /** Thrown for text that is not JSON (RFC 8259). */
    public static final class ParseException extends RuntimeException {
        ParseException(String message, int at) {
            super(message + " at offset " + at);
        }
    }

    // ------------------------------------------------------------------------------------------ parse

    public static Object parse(String text) {
        Parser p = new Parser(text);
        p.space();
        Object value = p.value(0);
        p.space();
        if (p.i != text.length()) throw new ParseException("Unexpected text after the value", p.i);
        return value;
    }

    private static final class Parser {
        private static final int MAX_DEPTH = 512;
        final String s;
        int i;

        Parser(String s) {
            this.s = s;
        }

        void space() {
            while (i < s.length()) {
                char c = s.charAt(i);
                if (c == ' ' || c == '\t' || c == '\n' || c == '\r') i++;
                else break;
            }
        }

        Object value(int depth) {
            if (depth > MAX_DEPTH) throw new ParseException("Nested too deeply", i);
            if (i >= s.length()) throw new ParseException("Unexpected end", i);
            char c = s.charAt(i);
            switch (c) {
                case '{':
                    return object(depth);
                case '[':
                    return array(depth);
                case '"':
                    return string();
                case 't':
                    return literal("true", Boolean.TRUE);
                case 'f':
                    return literal("false", Boolean.FALSE);
                case 'n':
                    return literal("null", null);
                default:
                    if (c == '-' || (c >= '0' && c <= '9')) return number();
                    throw new ParseException("Unexpected character '" + c + "'", i);
            }
        }

        Object literal(String word, Object value) {
            if (!s.startsWith(word, i)) throw new ParseException("Unexpected text", i);
            i += word.length();
            return value;
        }

        Map<String, Object> object(int depth) {
            Map<String, Object> map = new LinkedHashMap<>();
            i++;
            space();
            if (peek() == '}') {
                i++;
                return map;
            }
            while (true) {
                space();
                if (peek() != '"') throw new ParseException("Expected a key", i);
                String key = string();
                space();
                if (peek() != ':') throw new ParseException("Expected ':'", i);
                i++;
                space();
                map.put(key, value(depth + 1));
                space();
                char c = peek();
                i++;
                if (c == '}') return map;
                if (c != ',') throw new ParseException("Expected ',' or '}'", i - 1);
            }
        }

        List<Object> array(int depth) {
            List<Object> list = new ArrayList<>();
            i++;
            space();
            if (peek() == ']') {
                i++;
                return list;
            }
            while (true) {
                space();
                list.add(value(depth + 1));
                space();
                char c = peek();
                i++;
                if (c == ']') return list;
                if (c != ',') throw new ParseException("Expected ',' or ']'", i - 1);
            }
        }

        char peek() {
            if (i >= s.length()) throw new ParseException("Unexpected end", i);
            return s.charAt(i);
        }

        String string() {
            i++;
            StringBuilder out = new StringBuilder();
            while (true) {
                if (i >= s.length()) throw new ParseException("Unterminated string", i);
                char c = s.charAt(i++);
                if (c == '"') return out.toString();
                if (c < 0x20) throw new ParseException("Control character in a string", i - 1);
                if (c != '\\') {
                    out.append(c);
                    continue;
                }
                if (i >= s.length()) throw new ParseException("Unterminated escape", i);
                char e = s.charAt(i++);
                switch (e) {
                    case '"' -> out.append('"');
                    case '\\' -> out.append('\\');
                    case '/' -> out.append('/');
                    case 'b' -> out.append('\b');
                    case 'f' -> out.append('\f');
                    case 'n' -> out.append('\n');
                    case 'r' -> out.append('\r');
                    case 't' -> out.append('\t');
                    case 'u' -> out.append(hex4());
                    default -> throw new ParseException("Unknown escape \\" + e, i - 1);
                }
            }
        }

        char hex4() {
            if (i + 4 > s.length()) throw new ParseException("Short \\u escape", i);
            int v = 0;
            for (int k = 0; k < 4; k++) {
                int d = Character.digit(s.charAt(i + k), 16);
                if (d < 0) throw new ParseException("Bad \\u escape", i);
                v = v * 16 + d;
            }
            i += 4;
            // Surrogate pairs arrive as two escapes and are kept as the two UTF-16 units Java strings hold.
            return (char) v;
        }

        Object number() {
            int start = i;
            if (s.charAt(i) == '-') i++;
            if (i >= s.length()) throw new ParseException("Bad number", start);
            if (s.charAt(i) == '0') {
                i++;
            } else if (s.charAt(i) >= '1' && s.charAt(i) <= '9') {
                while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
            } else {
                throw new ParseException("Bad number", start);
            }
            boolean integral = true;
            if (i < s.length() && s.charAt(i) == '.') {
                integral = false;
                i++;
                int digits = i;
                while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
                if (i == digits) throw new ParseException("Bad fraction", start);
            }
            if (i < s.length() && (s.charAt(i) == 'e' || s.charAt(i) == 'E')) {
                integral = false;
                i++;
                if (i < s.length() && (s.charAt(i) == '+' || s.charAt(i) == '-')) i++;
                int digits = i;
                while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
                if (i == digits) throw new ParseException("Bad exponent", start);
            }
            String text = s.substring(start, i);
            if (integral) {
                try {
                    return Long.parseLong(text);
                } catch (NumberFormatException tooBig) {
                    return Double.parseDouble(text);
                }
            }
            return Double.parseDouble(text);
        }
    }

    // ------------------------------------------------------------------------------------------ stringify

    /** JSON text of a value: maps, collections, arrays, strings, numbers, booleans, null (and enums by name). */
    public static String stringify(Object value) {
        StringBuilder out = new StringBuilder();
        write(out, value);
        return out.toString();
    }

    private static void write(StringBuilder out, Object value) {
        if (value == null) {
            out.append("null");
        } else if (value instanceof String s) {
            quote(out, s);
        } else if (value instanceof Boolean b) {
            out.append(b ? "true" : "false");
        } else if (value instanceof Double || value instanceof Float) {
            double d = ((Number) value).doubleValue();
            if (Double.isNaN(d) || Double.isInfinite(d)) throw new IllegalArgumentException("JSON has no NaN or infinity");
            if (d == Math.rint(d) && Math.abs(d) < 1e15) out.append((long) d);
            else out.append(value);
        } else if (value instanceof Number n) {
            out.append(n);
        } else if (value instanceof Map<?, ?> map) {
            out.append('{');
            boolean first = true;
            for (Map.Entry<?, ?> e : map.entrySet()) {
                if (!first) out.append(',');
                first = false;
                quote(out, String.valueOf(e.getKey()));
                out.append(':');
                write(out, e.getValue());
            }
            out.append('}');
        } else if (value instanceof Collection<?> list) {
            out.append('[');
            boolean first = true;
            for (Object item : list) {
                if (!first) out.append(',');
                first = false;
                write(out, item);
            }
            out.append(']');
        } else if (value.getClass().isArray()) {
            out.append('[');
            for (int k = 0; k < Array.getLength(value); k++) {
                if (k > 0) out.append(',');
                write(out, Array.get(value, k));
            }
            out.append(']');
        } else if (value instanceof Enum<?> e) {
            quote(out, e.name());
        } else if (value instanceof Character c) {
            quote(out, c.toString());
        } else {
            quote(out, value.toString());
        }
    }

    private static void quote(StringBuilder out, String s) {
        out.append('"');
        for (int k = 0; k < s.length(); k++) {
            char c = s.charAt(k);
            switch (c) {
                case '"' -> out.append("\\\"");
                case '\\' -> out.append("\\\\");
                case '\n' -> out.append("\\n");
                case '\r' -> out.append("\\r");
                case '\t' -> out.append("\\t");
                case '\b' -> out.append("\\b");
                case '\f' -> out.append("\\f");
                default -> {
                    if (c < 0x20) out.append(String.format("\\u%04x", (int) c));
                    else out.append(c);
                }
            }
        }
        out.append('"');
    }
}
