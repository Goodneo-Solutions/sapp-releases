package ca.superroute.sapp;

/** Where tokens are kept. On a server, keep them where the person's session lives (encrypted at rest). */
public interface TokenStore {
    Tokens read();

    void write(Tokens tokens);

    void clear();
}
