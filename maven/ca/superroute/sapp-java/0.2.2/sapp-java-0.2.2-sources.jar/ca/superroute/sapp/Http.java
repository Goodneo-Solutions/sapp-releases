package ca.superroute.sapp;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Requests shared by the partner and open clients: URLs, bodies, retries and answers. */
final class Http {
    static final String SDK_VERSION = "0.2.2";
    static final String DEFAULT_BASE_URL = "https://open.superroute.ca";
    private static final Pattern PATH_PARAM = Pattern.compile("\\{([^}]+)}");

    private Http() {
    }

    static String text(Object value) {
        if (value == null) return "";
        if (value instanceof Boolean b) return b ? "1" : "0";
        if (value instanceof Double || value instanceof Float) {
            double d = ((Number) value).doubleValue();
            if (d == Math.rint(d) && Math.abs(d) < 1e15) return Long.toString((long) d);
        }
        if (value instanceof Map<?, ?> || value instanceof Collection<?>) return Json.stringify(value);
        return value.toString();
    }

    static String percent(String value) {
        return URLEncoder.encode(value, StandardCharsets.UTF_8).replace("+", "%20").replace("%7E", "~");
    }

    static String buildUrl(String baseUrl, Operation operation, Map<String, ?> params) {
        Matcher m = PATH_PARAM.matcher(operation.path);
        StringBuilder path = new StringBuilder();
        while (m.find()) {
            Object value = params.get(m.group(1));
            String t = text(value);
            m.appendReplacement(path, Matcher.quoteReplacement(t.isEmpty() ? "" : percent(t)));
        }
        m.appendTail(path);
        String p = path.toString().replaceAll("/{2,}", "/").replaceAll("/+$", "");
        StringBuilder url = new StringBuilder(baseUrl).append(p.isEmpty() ? "/" : p);
        String sep = "?";
        for (String name : operation.query) {
            Object value = params.get(name);
            if (value == null) continue;
            Iterable<?> values = value instanceof Collection<?> c ? c : (value.getClass().isArray() && !(value instanceof byte[]) ? arrayList(value) : List.of(value));
            for (Object item : values) {
                url.append(sep).append(percent(name)).append('=').append(percent(text(item)));
                sep = "&";
            }
        }
        // The extra query comes after the declared names and never replaces one of them.
        Object extra = params.get(Args.EXTRA_QUERY);
        if (extra instanceof Map<?, ?> map) {
            java.util.Set<String> seen = new java.util.HashSet<>(operation.query);
            for (Map.Entry<?, ?> e : map.entrySet()) {
                String name = String.valueOf(e.getKey());
                Object value = e.getValue();
                if (name.isEmpty() || value == null || !seen.add(name)) continue;
                Iterable<?> values = value instanceof Collection<?> c ? c : (value.getClass().isArray() && !(value instanceof byte[]) ? arrayList(value) : List.of(value));
                for (Object item : values) {
                    if (item == null) continue;
                    url.append(sep).append(percent(name)).append('=').append(percent(text(item)));
                    sep = "&";
                }
            }
        }
        return url.toString();
    }

    /** Headers the SDK sets itself; a header argument never replaces them. */
    private static final java.util.Set<String> PROTECTED_HEADERS = java.util.Set.of("authorization", "x-app-key", "x-sapp", "accept", "accept-language", "content-type");

    /**
     * The header parameters of one call, worked out once so every attempt of the call sends the same values: an
     * operation that declares Idempotency-Key gets a fresh (version 4 UUID) key when the caller gave none.
     */
    static Map<String, String> callHeaders(Operation operation, Map<String, ?> params) {
        Map<String, String> out = new LinkedHashMap<>();
        for (String name : operation.headers) {
            String lower = name.toLowerCase(java.util.Locale.ROOT);
            if (PROTECTED_HEADERS.contains(lower)) continue;
            String value = text(params.get(name));
            if (!value.isEmpty()) out.put(name, value);
            else if (lower.equals("idempotency-key")) out.put(name, java.util.UUID.randomUUID().toString());
        }
        return out;
    }

    /** {@code headers} plus {@code extra}, never replacing a header the SDK set (compared without regard to case). */
    static Map<String, String> withCallHeaders(Map<String, String> headers, Map<String, String> extra) {
        Map<String, String> out = new LinkedHashMap<>(headers);
        java.util.Set<String> taken = new java.util.HashSet<>();
        for (String k : headers.keySet()) taken.add(k.toLowerCase(java.util.Locale.ROOT));
        for (Map.Entry<String, String> e : extra.entrySet()) {
            if (!taken.contains(e.getKey().toLowerCase(java.util.Locale.ROOT))) out.put(e.getKey(), e.getValue());
        }
        return out;
    }

    private static List<Object> arrayList(Object array) {
        int n = java.lang.reflect.Array.getLength(array);
        Object[] out = new Object[n];
        for (int k = 0; k < n; k++) out[k] = java.lang.reflect.Array.get(array, k);
        return List.of(out);
    }

    static String form(Map<String, ?> fields) {
        StringBuilder out = new StringBuilder();
        for (Map.Entry<String, ?> e : fields.entrySet()) {
            if (e.getValue() == null) continue;
            if (out.length() > 0) out.append('&');
            out.append(URLEncoder.encode(e.getKey(), StandardCharsets.UTF_8)).append('=').append(URLEncoder.encode(text(e.getValue()), StandardCharsets.UTF_8));
        }
        return out.toString();
    }

    /** The encoded body and its content type, or null for none. */
    record Body(byte[] bytes, String contentType) {
    }

    static Body encode(Operation.Body kind, Map<String, ?> body, List<OperationFile> files) {
        switch (kind) {
            case NONE:
                return null;
            case JSON:
                return body == null ? null : new Body(Json.stringify(body).getBytes(StandardCharsets.UTF_8), "application/json");
            case FORM:
                return body == null ? null : new Body(form(body).getBytes(StandardCharsets.UTF_8), "application/x-www-form-urlencoded");
            default:
                if (body == null && (files == null || files.isEmpty())) return null;
                return multipart(body, files);
        }
    }

    private static Body multipart(Map<String, ?> body, List<OperationFile> files) {
        String boundary = "sapp-" + Pkce.randomString(18);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        if (body != null) {
            for (Map.Entry<String, ?> e : body.entrySet()) {
                Object v = e.getValue();
                if (v == null) continue;
                if (v instanceof Collection<?> c) {
                    for (Object item : c) part(out, boundary, e.getKey() + "[]", null, null, text(item).getBytes(StandardCharsets.UTF_8));
                } else {
                    part(out, boundary, e.getKey(), null, null, text(v).getBytes(StandardCharsets.UTF_8));
                }
            }
        }
        if (files != null) {
            for (OperationFile f : files) part(out, boundary, f.field(), f.filename(), f.contentType(), f.content());
        }
        out.writeBytes(("--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
        return new Body(out.toByteArray(), "multipart/form-data; boundary=" + boundary);
    }

    private static void part(ByteArrayOutputStream out, String boundary, String name, String filename, String type, byte[] content) {
        StringBuilder head = new StringBuilder("--").append(boundary).append("\r\nContent-Disposition: form-data; name=\"").append(escape(name)).append('"');
        if (filename != null) head.append("; filename=\"").append(escape(filename)).append('"');
        head.append("\r\n");
        if (type != null) head.append("Content-Type: ").append(type).append("\r\n");
        head.append("\r\n");
        out.writeBytes(head.toString().getBytes(StandardCharsets.UTF_8));
        out.writeBytes(content);
        out.writeBytes("\r\n".getBytes(StandardCharsets.UTF_8));
    }

    private static String escape(String s) {
        return s.replace("\"", "%22").replace("\r", "%0D").replace("\n", "%0A");
    }

    /** A parsed answer. */
    record Answer(int status, Object body, String requestId) {
        Object orThrow() {
            if (status >= 400) throw SuperrouteException.from(status, body, requestId);
            return body;
        }

        /** An operation's answer: refused at status 400 or more, or a JSON object answering {@code result: false} (even 2xx). */
        Object orThrowRefused() {
            if (status >= 400 || (body instanceof Map<?, ?> m && Boolean.FALSE.equals(m.get("result")))) {
                throw SuperrouteException.from(status, body, requestId);
            }
            return body;
        }
    }

    /** Repeatable calls are retried on a lost connection, 502–504 and 429 with Retry-After. Writes are never retried. */
    static Answer send(Transport transport, Sleeper sleeper, Transport.Request request, int retries, boolean retryable) {
        for (int attempt = 0; ; attempt++) {
            Transport.Response response;
            try {
                response = transport.send(request);
            } catch (IOException e) {
                if (retryable && attempt < retries) {
                    pause(sleeper, 300L << attempt);
                    continue;
                }
                throw new SuperrouteException(0, "network_error", "The request could not reach Superroute.", null, null, e);
            }
            String retryAfter = response.header("Retry-After");
            boolean throttled = response.status() == 429 && retryAfter != null;
            boolean transient_ = response.status() >= 502 && response.status() <= 504;
            if (retryable && attempt < retries && (transient_ || throttled)) {
                long wait = 300L << attempt;
                if (throttled) {
                    long seconds;
                    try {
                        seconds = Long.parseLong(retryAfter.trim());
                    } catch (NumberFormatException e) {
                        seconds = 1;
                    }
                    wait = Math.min(30L, Math.max(seconds, 0)) * 1000;
                }
                pause(sleeper, wait);
                continue;
            }
            return new Answer(response.status(), read(response.body()), response.header("X-Request-Id"));
        }
    }

    private static void pause(Sleeper sleeper, long millis) {
        try {
            sleeper.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new SuperrouteException(0, "network_error", "Interrupted while waiting to retry.", null, null, e);
        }
    }

    static Object read(byte[] bytes) {
        if (bytes.length == 0) return null;
        String text = new String(bytes, StandardCharsets.UTF_8);
        try {
            return Json.parse(text);
        } catch (Json.ParseException e) {
            return text;
        }
    }

    static Map<String, String> headers(String locale) {
        Map<String, String> h = new LinkedHashMap<>();
        h.put("Accept", "application/json");
        h.put("X-SApp", "java/" + SDK_VERSION);
        if (locale != null) h.put("Accept-Language", locale);
        return h;
    }

    static String trimSlash(String url) {
        return url.replaceAll("/+$", "");
    }
}
