package ca.superroute.sapp;

/**
 * How a webhook is verified: the {@code scheme} the endpoint signs with ({@code standard} by default), the
 * {@code tolerance} in seconds (300, or 12600 for {@code tenant}) and {@code now} in seconds (the clock by default).
 *
 * <pre>{@code WebhookOptions.defaults().scheme("partner_locker").tolerance(600L) }</pre>
 */
public record WebhookOptions(String scheme, Long tolerance, Long now) {
    public WebhookOptions {
        scheme = scheme == null ? "standard" : scheme;
    }

    public static WebhookOptions defaults() {
        return new WebhookOptions("standard", null, null);
    }

    public WebhookOptions scheme(String value) {
        return new WebhookOptions(value, tolerance, now);
    }

    public WebhookOptions tolerance(Long seconds) {
        return new WebhookOptions(scheme, seconds, now);
    }

    public WebhookOptions now(Long seconds) {
        return new WebhookOptions(scheme, tolerance, seconds);
    }
}
