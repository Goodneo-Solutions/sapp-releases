package ca.superroute.sapp;

import java.util.List;
import java.util.Map;

/** What a generated API calls for each operation: the path and query values, the body and files. */
@FunctionalInterface
public interface OperationCall {
    Object call(Operation operation, Map<String, Object> params, Map<String, ?> body, List<OperationFile> files);
}
