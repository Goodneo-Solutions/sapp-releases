package ca.superroute.sapp;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

/** PKCE (RFC 7636) for the Superroute sign-in page. */
public final class Pkce {
    private static final SecureRandom RANDOM = new SecureRandom();

    /** A verifier and its S256 challenge. */
    public record Pair(String verifier, String challenge, String method) {
    }

    private Pkce() {
    }

    /** S256 code challenge of a verifier (RFC 7636 §4.2). */
    public static String codeChallenge(String verifier) {
        try {
            return base64Url(MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    /** A fresh pair: keep the verifier until the redirect comes back, send the challenge with the authorize request. */
    public static Pair create() {
        String verifier = randomString(48);
        return new Pair(verifier, codeChallenge(verifier), "S256");
    }

    static String randomString(int bytes) {
        byte[] b = new byte[bytes];
        RANDOM.nextBytes(b);
        return base64Url(b);
    }

    static String base64Url(byte[] bytes) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }
}
