package ca.superroute.sapp;

/** A started sign-in on the Superroute sign-in page: open {@code url}, keep the rest for {@code completeSignIn}. */
public record AuthorizationRequest(String url, String verifier, String state, String redirectUri) {
}
