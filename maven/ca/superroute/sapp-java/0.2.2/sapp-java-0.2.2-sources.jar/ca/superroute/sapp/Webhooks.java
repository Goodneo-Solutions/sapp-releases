package ca.superroute.sapp;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Pattern;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * Superroute webhook verification: Standard Webhooks, the native signatures each sender still sends, and CloudEvents
 * envelopes. The same rules, error codes and test vectors in every language of sApp.
 *
 * <pre>{@code
 * WebhookEvent event = Webhooks.verify(rawBody, headers, System.getenv("SUPERROUTE_WEBHOOK_SECRET"));
 * if (seen(event.id())) return;   // the same event can arrive more than once
 * }</pre>
 *
 * Pass the raw body exactly as received, never a re-encoded object. Schemes: {@code standard} (Standard Webhooks, the
 * default), {@code tenant}, {@code partner_locker}, {@code tpd}, {@code loading_plan}, {@code open_platform},
 * {@code dataset}.
 */
public final class Webhooks {
    public static final List<String> SCHEMES = List.of("standard", "tenant", "partner_locker", "tpd", "loading_plan", "open_platform", "dataset");
    /** Seconds a signed timestamp may be away from now. */
    public static final long DEFAULT_TOLERANCE = 300;
    /**
     * Tenant webhooks sign the time the event was dispatched and keep it on every retry (5 tries over about 3 hours),
     * so their default tolerance covers the retries. Pair it with de-duplication on the event id.
     */
    public static final long TENANT_TOLERANCE = 12600;

    private static final String TYPE_PREFIX = "ca.superroute.";
    private static final Pattern BASE64 = Pattern.compile("^[A-Za-z0-9+/]*={0,2}$");
    private static final Pattern DIGITS = Pattern.compile("^\\d+$");
    private static final Pattern INTEGER = Pattern.compile("^-?\\d+$");

    private Webhooks() {
    }

    public static WebhookEvent verify(String body, Map<String, ?> headers, String secret) {
        return verify(body.getBytes(StandardCharsets.UTF_8), headers, List.of(secret), WebhookOptions.defaults());
    }

    public static WebhookEvent verify(String body, Map<String, ?> headers, String secret, WebhookOptions options) {
        return verify(body.getBytes(StandardCharsets.UTF_8), headers, List.of(secret), options);
    }

    public static WebhookEvent verify(String body, Map<String, ?> headers, List<String> secrets, WebhookOptions options) {
        return verify(body.getBytes(StandardCharsets.UTF_8), headers, secrets, options);
    }

    public static WebhookEvent verify(byte[] body, Map<String, ?> headers, String secret) {
        return verify(body, headers, List.of(secret), WebhookOptions.defaults());
    }

    public static WebhookEvent verify(byte[] body, Map<String, ?> headers, String secret, WebhookOptions options) {
        return verify(body, headers, List.of(secret), options);
    }

    /**
     * Verifies a webhook and answers its event. {@code secrets}: the endpoint's secret ({@code whsec_…} or the plain
     * secret), several during a rotation. Throws {@link WebhookVerificationException}.
     */
    public static WebhookEvent verify(byte[] body, Map<String, ?> headers, List<String> secrets, WebhookOptions options) {
        WebhookOptions o = options == null ? WebhookOptions.defaults() : options;
        String scheme = o.scheme();
        if (!SCHEMES.contains(scheme)) throw fail("unknown_scheme", "Unknown webhook scheme " + scheme + ".");
        if (secrets == null || secrets.isEmpty()) throw fail("invalid_secret", "No webhook secret was given.");
        List<byte[]> keys = new ArrayList<>();
        for (String s : secrets) keys.add(keyOf(s));
        Map<String, String> h = normalise(headers);
        long now = o.now() != null ? o.now() : System.currentTimeMillis() / 1000;
        long tolerance = o.tolerance() != null ? o.tolerance() : (scheme.equals("tenant") ? TENANT_TOLERANCE : DEFAULT_TOLERANCE);
        checkSignature(scheme, h, body, keys, now, tolerance);
        Object payload;
        try {
            payload = Json.parse(new String(body, StandardCharsets.UTF_8));
        } catch (Json.ParseException e) {
            throw fail("invalid_payload", "The webhook body is not JSON.");
        }
        return eventOf(h, payload);
    }

    private static WebhookVerificationException fail(String code, String message) {
        return new WebhookVerificationException(code, message);
    }

    private static Map<String, String> normalise(Map<String, ?> headers) {
        Map<String, String> out = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        if (headers == null) return out;
        headers.forEach((k, v) -> {
            if (k == null || v == null) return;
            if (v instanceof List<?> list) {
                List<String> parts = new ArrayList<>();
                for (Object item : list) parts.add(String.valueOf(item));
                out.put(k, String.join(", ", parts));
            } else {
                out.put(k, String.valueOf(v));
            }
        });
        return out;
    }

    /** The key bytes of a secret: whsec_&lt;base64&gt; is decoded, anything else is used as its UTF-8 bytes. */
    private static byte[] keyOf(String secret) {
        if (secret == null || secret.isEmpty()) throw fail("invalid_secret", "The webhook secret is empty.");
        if (secret.startsWith("whsec_")) {
            String b64 = secret.substring(6);
            if (!BASE64.matcher(b64).matches() || b64.length() % 4 != 0) throw fail("invalid_secret", "The whsec_ secret is not valid base64.");
            byte[] key;
            try {
                key = Base64.getDecoder().decode(b64);
            } catch (IllegalArgumentException e) {
                throw fail("invalid_secret", "The whsec_ secret is not valid base64.");
            }
            if (key.length == 0) throw fail("invalid_secret", "The whsec_ secret is not valid base64.");
            return key;
        }
        return secret.getBytes(StandardCharsets.UTF_8);
    }

    private static byte[] hmac(byte[] key, byte[]... parts) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(key, "HmacSHA256"));
            for (byte[] p : parts) mac.update(p);
            return mac.doFinal();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(e);
        }
    }

    private static String need(Map<String, String> h, String name) {
        String value = h.get(name);
        if (value == null || value.isEmpty()) throw fail("missing_header", "The " + name + " header is missing.");
        return value;
    }

    private static String checkTime(String raw, long now, long tolerance) {
        String t = raw.trim();
        if (!DIGITS.matcher(t).matches()) throw fail("invalid_timestamp", "The webhook timestamp is not a number of seconds.");
        long ts;
        try {
            ts = Long.parseLong(t);
        } catch (NumberFormatException e) {
            throw fail("invalid_timestamp", "The webhook timestamp is not a number of seconds.");
        }
        if (Math.abs(now - ts) > tolerance) throw fail("timestamp_out_of_tolerance", "The webhook timestamp is outside the tolerance.");
        return t;
    }

    private static List<String> entries(String header, String prefix, String separators) {
        List<String> out = new ArrayList<>();
        for (String s : header.split(separators)) if (s.startsWith(prefix)) out.add(s.substring(prefix.length()));
        return out;
    }

    private static byte[] utf8(String s) {
        return s.getBytes(StandardCharsets.UTF_8);
    }

    private interface Signer {
        String sign(byte[] key);
    }

    private static void checkSignature(String scheme, Map<String, String> h, byte[] body, List<byte[]> keys, long now, long tolerance) {
        List<String> given;
        Signer expected;
        Base64.Encoder b64 = Base64.getEncoder();
        HexFormat hex = HexFormat.of();
        switch (scheme) {
            case "standard" -> {
                String id = need(h, "webhook-id");
                String ts = need(h, "webhook-timestamp");
                String header = need(h, "webhook-signature");
                String t = checkTime(ts, now, tolerance);
                given = entries(header, "v1,", " ");
                expected = key -> b64.encodeToString(hmac(key, utf8(id + "." + t + "."), body));
            }
            case "tenant" -> {
                String ts = need(h, "X-Webhook-Timestamp");
                String header = need(h, "X-Webhook-Signature-V2");
                String t = checkTime(ts, now, tolerance);
                given = List.of(header.trim());
                expected = key -> hex.formatHex(hmac(key, utf8(t + "."), body));
            }
            case "partner_locker", "tpd" -> {
                String ts = need(h, "X-Webhook-Timestamp");
                String delivery = need(h, "X-Webhook-Delivery-Id");
                String header = need(h, "X-Webhook-Signature");
                String t = checkTime(ts, now, tolerance);
                given = entries(header, "v1=", "[ ,]+");
                expected = key -> b64.encodeToString(hmac(key, utf8(t + "\n" + delivery + "\n"), body));
            }
            case "loading_plan", "open_platform" -> {
                String prefix = scheme.equals("open_platform") ? "X-Open" : "X-Webhook";
                String ts = need(h, prefix + "-Timestamp");
                String header = need(h, prefix + "-Signature");
                String t = checkTime(ts, now, tolerance);
                given = entries(header, "v1=", "[ ,]+");
                expected = key -> hex.formatHex(hmac(key, utf8(t + "."), body));
            }
            case "dataset" -> {
                String header = need(h, "X-Webhook-Signature");
                // Sent but not signed: it still turns away a plain replay of an old request.
                String ts = h.get("X-Webhook-Timestamp");
                if (ts != null && !ts.isEmpty()) checkTime(ts, now, tolerance);
                given = List.of(header.trim());
                expected = key -> hex.formatHex(hmac(key, body));
            }
            default -> throw fail("unknown_scheme", "Unknown webhook scheme " + scheme + ".");
        }
        for (byte[] key : keys) {
            byte[] sig = utf8(expected.sign(key));
            for (String g : given) {
                if (MessageDigest.isEqual(utf8(g), sig)) return;
            }
        }
        throw fail("invalid_signature", "No signature matches the secret.");
    }

    private static String str(Object value) {
        return value instanceof String s && !s.isEmpty() ? s : null;
    }

    private static Long integer(Object value) {
        if (value instanceof Long l) return l;
        if (value instanceof Integer i) return i.longValue();
        if (value instanceof String s && INTEGER.matcher(s).matches()) {
            try {
                return Long.parseLong(s);
            } catch (NumberFormatException e) {
                return null;
            }
        }
        return null;
    }

    private static String stripType(String type) {
        return type != null && type.startsWith(TYPE_PREFIX) ? type.substring(TYPE_PREFIX.length()) : type;
    }

    private static String first(Object... values) {
        for (Object v : values) {
            String s = str(v);
            if (s != null) return s;
        }
        return null;
    }

    private static WebhookEvent eventOf(Map<String, String> h, Object payload) {
        Map<?, ?> object = payload instanceof Map<?, ?> m ? m : Map.of();
        String contentType = h.getOrDefault("Content-Type", "").toLowerCase();
        if (contentType.startsWith("application/cloudevents+json")
            || (object.containsKey("specversion") && object.get("specversion") != null && object.containsKey("data") && str(object.get("type")) != null && str(object.get("id")) != null)) {
            return new WebhookEvent(str(object.get("id")), stripType(str(object.get("type"))), str(object.get("time")), str(object.get("subject")),
                str(object.get("source")), integer(object.get("srbusiness")), null, "ce_structured", object.get("data"), payload);
        }
        if (str(h.get("ce-specversion")) != null) {
            return new WebhookEvent(str(h.get("ce-id")), stripType(str(h.get("ce-type"))), str(h.get("ce-time")), str(h.get("ce-subject")),
                str(h.get("ce-source")), integer(h.get("ce-srbusiness")), integer(h.get("ce-srattempt")), "ce_binary", payload, payload);
        }
        return new WebhookEvent(
            first(h.get("webhook-id"), h.get("X-Webhook-Event-Id"), h.get("X-Webhook-Id"), h.get("X-Open-Delivery"), object.get("event_id")),
            first(h.get("X-Webhook-Event-Type"), h.get("X-Open-Event"), h.get("X-Webhook-Event"), object.get("event_type"), object.get("event")),
            first(object.get("occurred_at"), object.get("event_time"), object.get("timestamp")),
            null, null, null, null, "native", payload, payload);
    }
}
