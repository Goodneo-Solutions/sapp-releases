package ca.superroute.sapp;

/** Keeps the tokens in memory only. */
public final class MemoryTokenStore implements TokenStore {
    private volatile Tokens tokens;

    public MemoryTokenStore() {
    }

    public MemoryTokenStore(Tokens initial) {
        this.tokens = initial;
    }

    @Override
    public Tokens read() {
        return tokens;
    }

    @Override
    public void write(Tokens tokens) {
        this.tokens = tokens;
    }

    @Override
    public void clear() {
        tokens = null;
    }
}
