package ca.superroute.sapp;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/** Sends one HTTP request. {@link HttpClientTransport} is the default; pass your own to test or to proxy. */
@FunctionalInterface
public interface Transport {
    Response send(Request request) throws IOException;

    /** An HTTP request. The body is null for none. */
    record Request(String method, String url, Map<String, String> headers, byte[] body) {
    }

    /** An HTTP answer; header names are looked up without regard to case. */
    record Response(int status, Map<String, List<String>> headers, byte[] body) {
        public Response {
            TreeMap<String, List<String>> h = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
            if (headers != null) headers.forEach((k, v) -> { if (k != null) h.put(k, v); });
            headers = h;
            body = body == null ? new byte[0] : body;
        }

        public String header(String name) {
            List<String> values = headers.get(name);
            return values == null || values.isEmpty() ? null : values.get(0);
        }
    }
}
