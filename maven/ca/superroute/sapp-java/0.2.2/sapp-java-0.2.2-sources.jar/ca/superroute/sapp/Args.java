package ca.superroute.sapp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The optional parts of a call: optional path, query and header parameters (by their names in the spec), an extra
 * query, an optional body and files.
 *
 * <pre>{@code api.platformAppNotifications(Args.of().with("page", 2).with("filter", "unread")); }</pre>
 */
public final class Args {
    /** The parameter key that carries the extra query. */
    public static final String EXTRA_QUERY = "extraQuery";

    private final Map<String, Object> params = new LinkedHashMap<>();
    private Map<String, ?> body;
    private final List<OperationFile> files = new ArrayList<>();

    private Args() {
    }

    /** No optional parts. */
    public static Args none() {
        return new Args();
    }

    /** A new, empty set to fill. */
    public static Args of() {
        return new Args();
    }

    /** A parameter by its name in the spec ({@code per_page}, {@code clientCode}, …). Null leaves it out. */
    public Args with(String name, Object value) {
        params.put(name, value);
        return this;
    }

    /**
     * Query parameters the spec does not declare ({@code multiple}, {@code locale}, …), appended after the declared ones
     * and never replacing one. Carried in the parameters under the key {@value #EXTRA_QUERY}.
     */
    public Args extraQuery(Map<String, ?> query) {
        params.put(EXTRA_QUERY, query == null ? null : new LinkedHashMap<>(query));
        return this;
    }

    /** The {@code Idempotency-Key} header; when left out, an operation that declares it gets a fresh key per call. */
    public Args idempotencyKey(String key) {
        return with("Idempotency-Key", key);
    }

    /**
     * A header parameter by its name in the spec ({@code X-Guest-Cart-Token}, …). Only headers the operation declares
     * are sent, and never one the SDK sets itself (Authorization, X-App-Key, X-SApp, …).
     */
    public Args header(String name, String value) {
        return with(name, value);
    }

    public Args body(Map<String, ?> body) {
        this.body = body;
        return this;
    }

    public Args file(OperationFile file) {
        files.add(file);
        return this;
    }

    /** A fresh, mutable copy of the parameters. */
    public Map<String, Object> params() {
        return new LinkedHashMap<>(params);
    }

    public Map<String, ?> body() {
        return body;
    }

    public List<OperationFile> files() {
        return Collections.unmodifiableList(files);
    }
}
