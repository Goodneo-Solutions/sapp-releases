package ca.superroute.sapp;

import java.util.List;

/** A session's tokens. {@code expiresAt} is in milliseconds since the epoch. */
public record Tokens(String accessToken, String refreshToken, long expiresAt, List<String> scope) {
    public Tokens {
        scope = scope == null ? List.of() : List.copyOf(scope);
    }

    public Tokens(String accessToken, String refreshToken, long expiresAt) {
        this(accessToken, refreshToken, expiresAt, List.of());
    }
}
