package ca.superroute.sapp;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Every failed call. {@link #status} is the HTTP status (0 when the request never got an answer), {@link #code} the
 * server's error code ({@code invalid_token}, {@code insufficient_scope}, {@code access_denied}, a platform app code
 * such as {@code APP_ACCESS_DENIED}, …) when it sent one, {@link #body} the parsed answer.
 *
 * <p>An answer {@code {"result": false, …}} is a failed call too, whatever its status (Superroute sometimes answers a
 * refusal with 200): {@link #errors} holds its field messages, {@link #reasons} and {@link #data} what it sent beside them.
 */
public class SuperrouteException extends RuntimeException {
    public final int status;
    public final String code;
    public final Object body;
    public final String requestId;
    /** Field → messages ({@code {"email": ["The email is taken."]}}); empty when the answer named none. */
    public final Map<String, List<String>> errors;
    /** The answer's {@code reasons}, as sent (a list or a map), or null. */
    public final Object reasons;
    /** The answer's {@code data}, as sent, or null. */
    public final Object data;

    public SuperrouteException(int status, String code, String message, Object body, String requestId, Throwable cause) {
        this(status, code, message, body, requestId, cause, Map.of(), null, null);
    }

    public SuperrouteException(int status, String code, String message, Object body, String requestId, Throwable cause,
                               Map<String, List<String>> errors, Object reasons, Object data) {
        super(message != null ? message : (code != null ? code : "Request failed with status " + status), cause);
        this.status = status;
        this.code = code;
        this.body = body;
        this.requestId = requestId;
        this.errors = errors == null ? Map.of() : Collections.unmodifiableMap(errors);
        this.reasons = reasons;
        this.data = data;
    }

    public Map<String, List<String>> errors() {
        return errors;
    }

    public Object reasons() {
        return reasons;
    }

    public Object data() {
        return data;
    }

    public SuperrouteException(int status, String code, String message) {
        this(status, code, message, null, null, null);
    }

    public SuperrouteException(int status, String code, String message, Object body) {
        this(status, code, message, body, null, null);
    }

    /** The person must sign in again: the session ended or was revoked. */
    public boolean signInRequired() {
        return status == 401 || "invalid_grant".equals(code);
    }

    static SuperrouteException from(int status, Object body, String requestId) {
        Map<?, ?> b = body instanceof Map<?, ?> m ? m : Map.of();
        String code = text(b.get("error"));
        if (code == null) code = text(b.get("code"));
        if (code == null && b.get("code") instanceof Number n) code = Http.text(n);
        Object message = b.get("message");
        if (code == null && message instanceof String s && s.matches("^[A-Z_]+$")) code = s;
        String description = text(b.get("error_description"));
        if (description == null && message instanceof List<?> list) {
            description = list.stream().map(String::valueOf).collect(Collectors.joining(" "));
        }
        if (description == null) description = text(message);
        if (description == null) description = text(b.get("title"));
        String id = text(b.get("request_id"));
        return new SuperrouteException(status, code, description, body, id != null ? id : requestId, null,
            fieldErrors(b.get("errors")), b.get("reasons"), b.get("data"));
    }

    private static Map<String, List<String>> fieldErrors(Object raw) {
        Map<String, List<String>> out = new LinkedHashMap<>();
        if (!(raw instanceof Map<?, ?> map)) return out;
        for (Map.Entry<?, ?> e : map.entrySet()) {
            Object v = e.getValue();
            if (v == null) continue;
            List<String> messages = new ArrayList<>();
            if (v instanceof Collection<?> c) {
                for (Object item : c) messages.add(Http.text(item));
            } else {
                messages.add(Http.text(v));
            }
            out.put(String.valueOf(e.getKey()), Collections.unmodifiableList(messages));
        }
        return out;
    }

    private static String text(Object value) {
        return value instanceof String s && !s.isEmpty() ? s : null;
    }
}
