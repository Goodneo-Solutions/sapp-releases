package ca.superroute.sapp;

/** A file sent with a multipart operation (photos, signatures). */
public record OperationFile(String field, byte[] content, String filename, String contentType) {
    public OperationFile(String field, byte[] content, String filename) {
        this(field, content, filename, "application/octet-stream");
    }
}
