package ca.superroute.sapp;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Set;

/** The default transport, over java.net.http. */
public final class HttpClientTransport implements Transport {
    /** Headers java.net.http sets itself and refuses from the caller. */
    private static final Set<String> RESTRICTED = Set.of("connection", "content-length", "expect", "host", "upgrade");

    private final HttpClient client;
    private final Duration timeout;

    public HttpClientTransport() {
        this(HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).followRedirects(HttpClient.Redirect.NEVER).build(), Duration.ofSeconds(60));
    }

    public HttpClientTransport(HttpClient client, Duration timeout) {
        this.client = client;
        this.timeout = timeout;
    }

    @Override
    public Response send(Request request) throws IOException {
        HttpRequest.Builder builder = HttpRequest.newBuilder(URI.create(request.url())).timeout(timeout);
        request.headers().forEach((k, v) -> {
            if (!RESTRICTED.contains(k.toLowerCase())) builder.header(k, v);
        });
        HttpRequest.BodyPublisher body = request.body() == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofByteArray(request.body());
        builder.method(request.method(), body);
        try {
            HttpResponse<byte[]> response = client.send(builder.build(), HttpResponse.BodyHandlers.ofByteArray());
            return new Response(response.statusCode(), response.headers().map(), response.body());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Interrupted", e);
        }
    }
}
