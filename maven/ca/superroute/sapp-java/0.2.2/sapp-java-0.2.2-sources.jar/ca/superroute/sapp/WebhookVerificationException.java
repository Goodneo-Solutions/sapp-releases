package ca.superroute.sapp;

/**
 * A webhook that failed verification. {@link #code()} is one of {@code unknown_scheme}, {@code invalid_secret},
 * {@code missing_header}, {@code invalid_timestamp}, {@code timestamp_out_of_tolerance}, {@code invalid_signature},
 * {@code invalid_payload}. Answer it with 400 (or 401) and do not act on the body.
 */
public class WebhookVerificationException extends RuntimeException {
    private final String code;

    public WebhookVerificationException(String code, String message) {
        super(message != null ? message : code);
        this.code = code;
    }

    public String code() {
        return code;
    }
}
