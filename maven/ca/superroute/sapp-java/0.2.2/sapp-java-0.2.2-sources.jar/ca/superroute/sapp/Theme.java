package ca.superroute.sapp;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Theme tokens from the service provider's branding (the bootstrap's {@code client.settings.branding}, §10.3), for
 * pages a server renders: colours with a readable text colour on each, plus type, radius and spacing.
 */
public record Theme(String displayName, String logoUrl, Map<String, String> color, Map<String, Integer> radius,
                    Map<String, Integer> spacing, Map<String, Integer> type) {

    public static Theme fromBranding(Map<String, ?> branding) {
        Map<String, ?> b = branding == null ? Map.of() : branding;
        Object raw = b.get("primary_color");
        String primary = raw instanceof String s && s.matches("^#[0-9a-fA-F]{6}$") ? s.toUpperCase() : "#E02020";
        Map<String, String> color = new LinkedHashMap<>();
        color.put("primary", primary);
        color.put("onPrimary", luminance(primary) > 0.4 ? "#111111" : "#FFFFFF");
        color.put("primaryContainer", mix(primary, 255, 0.85));
        color.put("onPrimaryContainer", mix(primary, 0, 0.55));
        color.put("surface", "#FFFFFF");
        color.put("onSurface", "#1C1C1E");
        color.put("muted", "#6B7280");
        color.put("success", "#16A34A");
        color.put("warning", "#FD7E14");
        color.put("danger", "#DC2626");
        return new Theme(
            b.get("display_name") instanceof String d && !d.isEmpty() ? d : null,
            b.get("logo_url") instanceof String l && !l.isEmpty() ? l : null,
            Map.copyOf(color),
            Map.of("small", 6, "medium", 10, "large", 16),
            Map.of("xs", 4, "s", 8, "m", 12, "l", 16, "xl", 24),
            Map.of("body", 15, "small", 13, "title", 20, "headline", 26));
    }

    private static int channel(String hex, int i) {
        return Integer.parseInt(hex.substring(1 + i * 2, 3 + i * 2), 16);
    }

    private static double luminance(String hex) {
        double[] c = new double[3];
        for (int i = 0; i < 3; i++) {
            double v = channel(hex, i) / 255.0;
            c[i] = v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
        }
        return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
    }

    private static String mix(String hex, int target, double amount) {
        StringBuilder out = new StringBuilder("#");
        for (int i = 0; i < 3; i++) {
            int v = channel(hex, i);
            out.append(String.format("%02X", Math.round(v + (target - v) * amount)));
        }
        return out.toString();
    }
}
