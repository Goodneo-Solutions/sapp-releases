package ca.superroute.sapp;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Every failed call. {@link #status} is the HTTP status (0 when the request never got an answer), {@link #code} the
 * server's error code ({@code invalid_token}, {@code insufficient_scope}, {@code access_denied}, a platform app code
 * such as {@code APP_ACCESS_DENIED}, …) when it sent one, {@link #body} the parsed answer.
 *
 * <p>An answer {@code {"result": false, …}} is a failed call too, whatever its status (Superroute sometimes answers a
 * refusal with 200): {@link #errors} holds its field messages, {@link #reasons} and {@link #data} what it sent beside them.
 *
 * <p>{@link #headers()} are the refused answer's headers (names in lower case, several values of one name joined with
 * {@code ", "}; empty when there was no answer), {@link #retryAfter()} its {@code Retry-After} in whole seconds (null
 * when absent or not understood) and {@link #requestId} the answer's {@code request_id}, else its
 * {@code X-Request-Id} header.
 */
public class SuperrouteException extends RuntimeException {
    public final int status;
    public final String code;
    public final Object body;
    public final String requestId;
    /** Field → messages ({@code {"email": ["The email is taken."]}}); empty when the answer named none. */
    public final Map<String, List<String>> errors;
    /** The answer's {@code reasons}, as sent (a list or a map), or null. */
    public final Object reasons;
    /** The answer's {@code data}, as sent, or null. */
    public final Object data;
    /** The refused answer's headers: names in lower case, several values joined with {@code ", "}; empty without an answer. */
    public final Map<String, String> headers;
    /** The answer's {@code Retry-After} in whole seconds (an HTTP-date as the seconds until it, at least 0), or null. */
    public final Integer retryAfter;

    public SuperrouteException(int status, String code, String message, Object body, String requestId, Throwable cause) {
        this(status, code, message, body, requestId, cause, Map.of(), null, null);
    }

    public SuperrouteException(int status, String code, String message, Object body, String requestId, Throwable cause,
                               Map<String, List<String>> errors, Object reasons, Object data) {
        this(status, code, message, body, requestId, cause, errors, reasons, data, Map.of());
    }

    /**
     * With the refused answer's headers; {@link #retryAfter} is read from their {@code Retry-After} and
     * {@link #requestId} falls back to their {@code X-Request-Id}.
     */
    public SuperrouteException(int status, String code, String message, Object body, String requestId, Throwable cause,
                               Map<String, List<String>> errors, Object reasons, Object data, Map<String, ?> headers) {
        super(message != null ? message : (code != null ? code : "Request failed with status " + status), cause);
        this.status = status;
        this.code = code;
        this.body = body;
        this.headers = Collections.unmodifiableMap(lowerHeaders(headers));
        this.requestId = requestId != null ? requestId : this.headers.get("x-request-id");
        this.errors = errors == null ? Map.of() : Collections.unmodifiableMap(errors);
        this.reasons = reasons;
        this.data = data;
        this.retryAfter = retryAfterSeconds(this.headers.get("retry-after"), System.currentTimeMillis());
    }

    /** The refused answer's headers: names in lower case, several values of one name joined with {@code ", "}. */
    public Map<String, String> headers() {
        return headers;
    }

    /** The answer's {@code Retry-After} in whole seconds, or null when it sent none or one that could not be read. */
    public Integer retryAfter() {
        return retryAfter;
    }

    /** Header names in lower case; a list of values (several of one name) joined with {@code ", "}. */
    static Map<String, String> lowerHeaders(Map<String, ?> headers) {
        Map<String, String> out = new LinkedHashMap<>();
        if (headers == null) return out;
        for (Map.Entry<String, ?> e : headers.entrySet()) {
            if (e.getKey() == null || e.getValue() == null) continue;
            String key = e.getKey().toLowerCase(java.util.Locale.ROOT);
            String value = e.getValue() instanceof Collection<?> c
                ? c.stream().map(String::valueOf).collect(Collectors.joining(", "))
                : String.valueOf(e.getValue());
            out.merge(key, value, (a, b) -> a + ", " + b);
        }
        return out;
    }

    /**
     * {@code Retry-After} in whole seconds: a non-negative integer as is, an HTTP-date as the seconds until it (rounded
     * up, at least 0), anything else null.
     */
    static Integer retryAfterSeconds(String value, long nowMillis) {
        if (value == null) return null;
        String v = value.trim();
        if (v.matches("[0-9]+")) {
            try {
                return Integer.valueOf(v);
            } catch (NumberFormatException e) {
                return null;
            }
        }
        try {
            long millis = ZonedDateTime.parse(v, DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli() - nowMillis;
            return (int) Math.max(0, (millis + 999) / 1000);
        } catch (DateTimeParseException e) {
            return null;
        }
    }

    public Map<String, List<String>> errors() {
        return errors;
    }

    public Object reasons() {
        return reasons;
    }

    public Object data() {
        return data;
    }

    public SuperrouteException(int status, String code, String message) {
        this(status, code, message, null, null, null);
    }

    public SuperrouteException(int status, String code, String message, Object body) {
        this(status, code, message, body, null, null);
    }

    /** The person must sign in again: the session ended or was revoked. */
    public boolean signInRequired() {
        return status == 401 || "invalid_grant".equals(code);
    }

    static SuperrouteException from(int status, Object body, String requestId) {
        return from(status, body, requestId, Map.of());
    }

    static SuperrouteException from(int status, Object body, String requestId, Map<String, ?> headers) {
        Map<?, ?> b = body instanceof Map<?, ?> m ? m : Map.of();
        String code = text(b.get("error"));
        if (code == null) code = text(b.get("code"));
        if (code == null && b.get("code") instanceof Number n) code = Http.text(n);
        Object message = b.get("message");
        if (code == null && message instanceof String s && s.matches("^[A-Z_]+$")) code = s;
        String description = text(b.get("error_description"));
        if (description == null && message instanceof List<?> list) {
            description = list.stream().map(String::valueOf).collect(Collectors.joining(" "));
        }
        if (description == null) description = text(message);
        if (description == null) description = text(b.get("title"));
        String id = text(b.get("request_id"));
        return new SuperrouteException(status, code, description, body, id != null ? id : requestId, null,
            fieldErrors(b.get("errors")), b.get("reasons"), b.get("data"), headers);
    }

    private static Map<String, List<String>> fieldErrors(Object raw) {
        Map<String, List<String>> out = new LinkedHashMap<>();
        if (!(raw instanceof Map<?, ?> map)) return out;
        for (Map.Entry<?, ?> e : map.entrySet()) {
            Object v = e.getValue();
            if (v == null) continue;
            List<String> messages = new ArrayList<>();
            if (v instanceof Collection<?> c) {
                for (Object item : c) messages.add(Http.text(item));
            } else {
                messages.add(Http.text(v));
            }
            out.put(String.valueOf(e.getKey()), Collections.unmodifiableList(messages));
        }
        return out;
    }

    private static String text(Object value) {
        return value instanceof String s && !s.isEmpty() ? s : null;
    }
}
