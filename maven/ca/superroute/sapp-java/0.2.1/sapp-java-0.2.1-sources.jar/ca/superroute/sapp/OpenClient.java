package ca.superroute.sapp;

import java.util.Map;
import java.util.function.Supplier;

/**
 * The open profile: Open Platform capabilities (routing, geocoding, ETA, packing, …) at open.superroute.ca/v1.
 * On a server pass the Open Platform API key; to hand capabilities to an app, have your backend mint short-lived
 * tokens and pass {@code getToken}.
 *
 * <pre>{@code
 * OpenClient open = OpenClient.builder().apiKey(System.getenv("SUPERROUTE_OPEN_KEY")).build();
 * Object eta = open.api.etaEstimate(Map.of("origin", origin, "destination", destination));
 * }</pre>
 */
public final class OpenClient {
    /** One method per Open Platform operation. */
    public final OpenApi api;

    private OpenClient(Builder b) {
        if (b.getToken == null && b.apiKey == null) throw new IllegalArgumentException("getToken or apiKey is required");
        String baseUrl = Http.trimSlash(b.baseUrl);
        Transport transport = b.transport != null ? b.transport : new HttpClientTransport();
        Supplier<String> token = b.getToken != null ? b.getToken : () -> b.apiKey;
        String locale = b.locale;
        int retries = b.retries;
        Sleeper sleeper = b.sleeper;
        this.api = new OpenApi((operation, params, body, files) -> {
            Map<String, String> headers = Http.headers(locale);
            headers.put("Authorization", "Bearer " + token.get());
            Transport.Request request = PartnerClient.request(operation, Http.buildUrl(baseUrl, operation, params), headers, Http.encode(operation.body, body, files));
            return Http.send(transport, sleeper, request, retries, operation.method.equals("GET")).orThrow();
        });
    }

    public static Builder builder() {
        return new Builder();
    }

    /** Options of an {@link OpenClient}. */
    public static final class Builder {
        private Supplier<String> getToken;
        private String apiKey;
        private String baseUrl = Http.DEFAULT_BASE_URL;
        private String locale;
        private int retries = 2;
        private Transport transport;
        private Sleeper sleeper = Thread::sleep;

        private Builder() {
        }

        /** Asked for a token before every call (a short-lived token your backend minted). */
        public Builder getToken(Supplier<String> v) { getToken = v; return this; }
        /** An Open Platform API key: a server secret, never for an app. */
        public Builder apiKey(String v) { apiKey = v; return this; }
        public Builder baseUrl(String v) { baseUrl = v; return this; }
        public Builder locale(String v) { locale = v; return this; }
        public Builder retries(int v) { retries = v; return this; }
        public Builder transport(Transport v) { transport = v; return this; }
        public Builder sleeper(Sleeper v) { sleeper = v; return this; }

        public OpenClient build() {
            return new OpenClient(this);
        }
    }
}
