package ca.superroute.sapp;

import java.util.List;

/** One operation of a generated API (docs/PLATFORM-APP-SDK-DESIGN.md §10.2). */
public final class Operation {
    /** How an operation authenticates. */
    public enum Auth { TOKEN, KEY, TOKEN_OR_KEY, NONE }

    /** How an operation's body is sent. */
    public enum Body { NONE, JSON, FORM, MULTIPART }

    public final String method;
    public final String path;
    public final Auth auth;
    public final List<String> query;
    public final Body body;

    public Operation(String method, String path, Auth auth, List<String> query, Body body) {
        this.method = method;
        this.path = path;
        this.auth = auth;
        this.query = List.copyOf(query);
        this.body = body;
    }
}
