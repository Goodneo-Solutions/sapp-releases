package ca.superroute.sapp;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Every failed call. {@link #status} is the HTTP status (0 when the request never got an answer), {@link #code} the
 * server's error code ({@code invalid_token}, {@code insufficient_scope}, {@code access_denied}, a platform app code
 * such as {@code APP_ACCESS_DENIED}, …) when it sent one, {@link #body} the parsed answer.
 */
public class SuperrouteException extends RuntimeException {
    public final int status;
    public final String code;
    public final Object body;
    public final String requestId;

    public SuperrouteException(int status, String code, String message, Object body, String requestId, Throwable cause) {
        super(message != null ? message : (code != null ? code : "Request failed with status " + status), cause);
        this.status = status;
        this.code = code;
        this.body = body;
        this.requestId = requestId;
    }

    public SuperrouteException(int status, String code, String message) {
        this(status, code, message, null, null, null);
    }

    public SuperrouteException(int status, String code, String message, Object body) {
        this(status, code, message, body, null, null);
    }

    /** The person must sign in again: the session ended or was revoked. */
    public boolean signInRequired() {
        return status == 401 || "invalid_grant".equals(code);
    }

    static SuperrouteException from(int status, Object body, String requestId) {
        Map<?, ?> b = body instanceof Map<?, ?> m ? m : Map.of();
        String code = text(b.get("error"));
        if (code == null) code = text(b.get("code"));
        Object message = b.get("message");
        if (code == null && message instanceof String s && s.matches("^[A-Z_]+$")) code = s;
        String description = text(b.get("error_description"));
        if (description == null && message instanceof List<?> list) {
            description = list.stream().map(String::valueOf).collect(Collectors.joining(" "));
        }
        if (description == null) description = text(message);
        if (description == null) description = text(b.get("title"));
        String id = text(b.get("request_id"));
        return new SuperrouteException(status, code, description, body, id != null ? id : requestId, null);
    }

    private static String text(Object value) {
        return value instanceof String s && !s.isEmpty() ? s : null;
    }
}
