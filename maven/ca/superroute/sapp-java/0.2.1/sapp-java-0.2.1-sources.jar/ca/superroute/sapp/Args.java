package ca.superroute.sapp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The optional parts of a call: optional path and query parameters (by their names in the spec), an optional body
 * and files.
 *
 * <pre>{@code api.platformAppNotifications(Args.of().with("page", 2).with("filter", "unread")); }</pre>
 */
public final class Args {
    private final Map<String, Object> params = new LinkedHashMap<>();
    private Map<String, ?> body;
    private final List<OperationFile> files = new ArrayList<>();

    private Args() {
    }

    /** No optional parts. */
    public static Args none() {
        return new Args();
    }

    /** A new, empty set to fill. */
    public static Args of() {
        return new Args();
    }

    /** A parameter by its name in the spec ({@code per_page}, {@code clientCode}, …). Null leaves it out. */
    public Args with(String name, Object value) {
        params.put(name, value);
        return this;
    }

    public Args body(Map<String, ?> body) {
        this.body = body;
        return this;
    }

    public Args file(OperationFile file) {
        files.add(file);
        return this;
    }

    /** A fresh, mutable copy of the parameters. */
    public Map<String, Object> params() {
        return new LinkedHashMap<>(params);
    }

    public Map<String, ?> body() {
        return body;
    }

    public List<OperationFile> files() {
        return Collections.unmodifiableList(files);
    }
}
