package ca.superroute.sapp.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuAnchorType
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.serialization.json.JsonObject
import java.math.BigDecimal
import java.math.BigInteger
import java.math.MathContext
import java.math.RoundingMode

/**
 * A made-to-measure product's choices (UI-KIT-SPEC.md §P3h). Holds the answers the person gave and the last answer of
 * `platformAppStoreProductConfigure`; every rule and every price comes from that answer, never from the kit. Free of
 * composables so it runs in a plain JVM test.
 */
class SrConfigurator(val product: Obj) {
    val config: Obj = product["configurator"].obj()
    val options: List<Obj> = config["options"].objs()
    val steps: List<Obj> = config["steps"].objs()

    /** The answers sent, keyed by option key (see the spec's **Answers**). */
    val answers = mutableStateMapOf<String, Any?>()

    /** The answer shown: `initial` until the first quote, then the newest quote's. */
    var answer by mutableStateOf(config["initial"].obj())
        private set

    /** Options the person changed (their errors show before **Add to cart** was pressed). */
    val touched = mutableStateListOf<String>()

    /** True once **Add to cart** was pressed: every error shows. */
    var showAll by mutableStateOf(false)

    /** The cart's `configuration_errors` of a refusal, option → messages. */
    val refused = mutableStateMapOf<String, List<String>>()

    /** Counts changes; the component asks a quote whenever it moves ([typing] says whether to wait 350 ms). */
    var changes by mutableStateOf(0)
        private set
    var typing: Boolean = false
        private set

    /** True while the newest quote has not answered yet. */
    var quoting by mutableStateOf(false)
        private set

    private val units = mutableStateMapOf<String, Int>()
    private val drafts = mutableStateMapOf<String, String>()
    private var latest = 0

    init {
        answer["answers"].obj().forEach { (k, v) -> if (v != null) answers[k] = v }
        for (o in options) if (isMeasure(o)) unitFromAnswer(o)?.let { units[key(o)] = it }
    }

    // ------------------------------------------------------------------------------------------------ reading state

    fun option(key: String): Obj? = options.firstOrNull { key(it) == key }
    fun stateOf(key: String): Obj = answer["state"].obj()[key].obj()
    fun isHidden(key: String): Boolean = stateOf(key)["hidden"].isTrue()
    fun isRequired(option: Obj): Boolean = option["required"].isTrue() || stateOf(key(option))["required"].isTrue()
    fun isLocked(key: String): Boolean = stateOf(key)["locked"] != null

    /** The rule's reason under the label, while a rule locks the option. */
    fun lockReason(key: String): String? = if (isLocked(key)) stateOf(key)["reason"].text().ifEmpty { null } else null

    val visibleOptions: List<Obj> get() = options.filter { !isHidden(key(it)) }

    private fun valueState(key: String, value: String): Obj = stateOf(key)["values"].obj()[value].obj()
    fun isValueDisabled(key: String, value: String): Boolean = valueState(key, value)["disabled"].isTrue()
    fun valueReason(key: String, value: String): String? = if (isValueDisabled(key, value)) valueState(key, value)["reason"].text().ifEmpty { null } else null

    /** The values drawn (those the answer does not hide). */
    fun values(option: Obj): List<Obj> = option["values"].objs().filter { !valueState(key(option), it["key"].text())["hidden"].isTrue() }

    /** Whether a value can be tapped: not disabled, or the chosen one (which stays chosen so its error shows). */
    fun isChoosable(option: Obj, value: String): Boolean = !isLocked(key(option)) && (!isValueDisabled(key(option), value) || isChosen(option, value))

    /** The option's `summary` line, or null. */
    fun summary(key: String): String? = answer["summary"].objs().firstOrNull { it["option"].text() == key }?.get("value").text().ifEmpty { null }

    val errors: List<Obj> get() = answer["errors"].objs()
    val messages: List<Obj> get() = answer["messages"].objs()
    val price: Obj get() = answer["price"].obj()
    val priceLines: List<Obj> get() = price["lines"].objs()

    /** The errors shown under an option: the answer's (once changed, or all after **Add to cart**) and the cart's. */
    fun shownErrors(key: String): List<String> {
        val own = if (showAll || key in touched) errors.filter { it["option"].text() == key }.map { it["message"].text() } else emptyList()
        return (own + (refused[key] ?: emptyList())).filter { it.isNotEmpty() }.distinct()
    }

    /** Errors shown above the price: those without an option, and after **Add to cart** those of options not drawn. */
    val generalErrors: List<String>
        get() {
            val drawn = visibleOptions.map { key(it) }.toSet()
            return errors.filter { val o = it["option"].text(); o.isEmpty() || (showAll && o !in drawn) }.map { it["message"].text() }.filter { it.isNotEmpty() }.distinct()
        }

    /** The first drawn option with an error shown, to scroll to. */
    val firstErrorKey: String? get() = visibleOptions.map { key(it) }.firstOrNull { shownErrors(it).isNotEmpty() }

    /** The step headings: the step's label before an option whose step differs from the previous option's. */
    fun heading(index: Int, drawn: List<Obj>): String? {
        val step = drawn[index]["step"]?.text()?.ifEmpty { null } ?: return null
        if (index > 0 && drawn[index - 1]["step"].text() == step) return null
        return steps.firstOrNull { it["key"].text() == step }?.get("label").text().ifEmpty { null }
    }

    /** `help` as an object (a PHP empty object arrives as `[]`), or null when it has nothing. */
    fun help(option: Obj): Obj? = option["help"].obj().takeIf { h -> listOf("text", "image", "link").any { h[it].text().isNotEmpty() } }

    // ------------------------------------------------------------------------------------------------ choice, choices

    fun isChosen(option: Obj, value: String): Boolean {
        val a = answers[key(option)]
        return if (option["kind"] == "choices") a.obj().containsKey(value) else a != null && a.text() == value
    }

    fun quantityOf(option: Obj, value: String): Long = answers[key(option)].obj()[value].long() ?: 0

    /** A tap on a value: `choice` chooses it (the chosen one clears unless required), `choices` toggles it. */
    fun tap(option: Obj, value: String) {
        val key = key(option)
        if (!isChoosable(option, value)) return
        if (option["kind"] == "choices") {
            val m = answers[key].obj().toMutableMap()
            if (m.containsKey(value)) m.remove(value) else m[value] = 1L
            if (m.isEmpty()) answers.remove(key) else answers[key] = m
        } else if (isChosen(option, value)) {
            if (isRequired(option)) return
            answers.remove(key)
        } else {
            answers[key] = value
        }
        changed(key, typing = false)
    }

    /** A chosen value's quantity (`choices` with `quantity`), 1 to `max_quantity`. */
    fun setQuantity(option: Obj, value: String, quantity: Long) {
        val key = key(option)
        val max = option["max_quantity"].long()
        val q = quantity.coerceAtLeast(1).let { if (max != null) it.coerceAtMost(max) else it }
        val m = answers[key].obj().toMutableMap()
        if (!m.containsKey(value) || m[value].long() == q) return
        m[value] = q
        answers[key] = m
        changed(key, typing = false)
    }

    // ------------------------------------------------------------------------------------------------ size, length

    fun isMeasure(option: Obj): Boolean = option["kind"] == "size" || option["kind"] == "length"
    fun axes(option: Obj): List<String> = if (option["kind"] == "size") listOf("width", "height") else listOf("length")
    fun unitsOf(option: Obj): List<Int> = option["units"].list().mapNotNull { it.long()?.toInt() }
    fun unitOf(option: Obj): Int = units[key(option)] ?: option["unit"].long()?.toInt() ?: unitsOf(option).firstOrNull() ?: 1

    /** The step of [unit] (`steps` `{unit: step}`; a PHP list indexed by unit read too), else the unit's decimals. */
    fun stepOf(option: Obj, unit: Int): BigDecimal {
        val steps = option["steps"]
        val given = (steps as? Map<*, *>)?.get(unit.toString()).decimal() ?: (steps as? List<*>)?.getOrNull(unit).decimal()
        return given?.takeIf { it.signum() > 0 } ?: BigDecimal.ONE.movePointLeft(DECIMALS[unit] ?: 0)
    }

    /** The fraction pad: `display` `fraction_pad`, inches and a step below 1. */
    fun isFractionPad(option: Obj): Boolean = option["display"] == "fraction_pad" && unitOf(option) == 4 && stepOf(option, 4) < BigDecimal.ONE

    /** The text typed for an axis. */
    fun axisText(option: Obj, axis: String): String {
        val a = answers[key(option)].obj()
        return (if (option["kind"] == "size") a[axis].obj() else a)["value"].text()
    }

    /** An axis typed. */
    fun setAxis(option: Obj, axis: String, text: String, typing: Boolean = true) {
        writeAxis(option, axis, text, unitOf(option))
        changed(key(option), typing)
    }

    private fun writeAxis(option: Obj, axis: String, text: String, unit: Int) {
        val key = key(option)
        val entry = if (text.isBlank()) null else mapOf("value" to text, "unit" to unit.toLong())
        if (option["kind"] == "size") {
            val m = answers[key].obj().toMutableMap()
            if (entry == null) m.remove(axis) else m[axis] = entry
            for (other in axes(option)) m[other].obj().takeIf { other != axis && it.isNotEmpty() }?.let { m[other] = it + ("unit" to unit.toLong()) }
            if (m.isEmpty()) answers.remove(key) else answers[key] = m
        } else if (entry == null) answers.remove(key) else answers[key] = entry
    }

    /** Switches the unit: each typed figure converted and rounded **down** to the new unit's step. */
    fun switchUnit(option: Obj, unit: Int) {
        val from = unitOf(option)
        if (unit == from) return
        val texts = axes(option).associateWith { axisText(option, it) }
        units[key(option)] = unit
        for ((axis, text) in texts) {
            val figure = parseFigure(text)
            writeAxis(option, axis, if (figure == null) text else format(option, unit, convert(figure, from, unit, stepOf(option, unit))), unit)
        }
        changed(key(option), typing = false)
    }

    /** The whole inches of an axis (fraction pad). */
    fun wholeText(option: Obj, axis: String): String {
        val text = axisText(option, axis).trim()
        if (text.isEmpty()) return ""
        if (text.contains('/') || text.contains(' ')) return text.substringBefore(' ').takeIf { !it.contains('/') } ?: "0"
        return parseFigure(text)?.setScale(0, RoundingMode.FLOOR)?.toPlainString() ?: text
    }

    /** The fraction buttons: 0, then each step as a reduced fraction (1/8, 1/4, 3/8 … for 0.125). */
    fun fractions(option: Obj): List<String> {
        val step = stepOf(option, 4)
        val count = BigDecimal.ONE.divide(step, MathContext.DECIMAL64).setScale(0, RoundingMode.CEILING).toInt().coerceIn(1, 64)
        return (0 until count).map { if (it == 0) "0" else fractionText(step.multiply(BigDecimal(it))) }
    }

    /** The index of the chosen fraction button, or 0. */
    fun fractionIndex(option: Obj, axis: String): Int {
        val figure = parseFigure(axisText(option, axis)) ?: return 0
        val rest = figure - figure.setScale(0, RoundingMode.FLOOR)
        return rest.divide(stepOf(option, 4), 0, RoundingMode.HALF_UP).toInt().coerceIn(0, fractions(option).size - 1)
    }

    fun setWhole(option: Obj, axis: String, whole: String, typing: Boolean = true) {
        val digits = whole.filter { it.isDigit() }
        setAxis(option, axis, padValue(digits, fractions(option)[fractionIndex(option, axis)]), typing)
    }

    fun setFraction(option: Obj, axis: String, index: Int) {
        val whole = wholeText(option, axis)
        setAxis(option, axis, padValue(whole.ifEmpty { "0" }, fractions(option).getOrElse(index) { "0" }), typing = false)
    }

    private fun padValue(whole: String, fraction: String): String = when {
        whole.isEmpty() && fraction == "0" -> ""
        fraction == "0" -> whole
        else -> "${whole.ifEmpty { "0" }} $fraction"
    }

    /** A figure in the unit's own form: `"whole n/d"` on the fraction pad, else plain decimals. */
    fun format(option: Obj, unit: Int, value: BigDecimal): String {
        if (unit == 4 && option["display"] == "fraction_pad" && stepOf(option, 4) < BigDecimal.ONE) {
            val whole = value.setScale(0, RoundingMode.FLOOR)
            val rest = value - whole
            return if (rest.signum() == 0) whole.toPlainString() else "${whole.toPlainString()} ${fractionText(rest)}"
        }
        return plain(value)
    }

    /** `state[key].ranges[axis]` `{min, max}` in millimetres (a PHP empty object arrives as `[]`). */
    fun range(option: Obj, axis: String): Pair<BigDecimal?, BigDecimal?>? {
        val ranges = stateOf(key(option))["ranges"].obj()
        val r = (ranges[axis] ?: if (option["kind"] == "length") ranges.values.firstOrNull() else null).obj()
        if (r.isEmpty()) return null
        return r["min"].decimal() to r["max"].decimal()
    }

    // ------------------------------------------------------------------------------------------------ number, text, confirm

    fun numberText(option: Obj): String = drafts[key(option)] ?: answers[key(option)].text()

    fun setNumberText(option: Obj, text: String) {
        val key = key(option)
        drafts[key] = text
        val n = text.decimal()
        if (n == null) answers.remove(key) else answers[key] = n
        changed(key, typing = true)
    }

    /** The stepper or slider: a number within `min_value` / `max_value`. */
    fun setNumber(option: Obj, value: BigDecimal, typing: Boolean = false) {
        val key = key(option)
        var v = value
        option["min_value"].decimal()?.let { if (v < it) v = it }
        option["max_value"].decimal()?.let { if (v > it) v = it }
        drafts.remove(key)
        if (answers[key].decimal()?.compareTo(v) == 0) return
        answers[key] = v
        changed(key, typing)
    }

    fun stepNumber(option: Obj, direction: Int) {
        val step = option["number_step"].decimal()?.takeIf { it.signum() > 0 } ?: BigDecimal.ONE
        val current = answers[key(option)].decimal() ?: option["min_value"].decimal()?.subtract(if (direction > 0) step else BigDecimal.ZERO) ?: BigDecimal.ZERO
        setNumber(option, current + step.multiply(BigDecimal(direction)))
    }

    fun text(option: Obj): String = answers[key(option)].text()

    fun setText(option: Obj, text: String) {
        val key = key(option)
        val max = option["max_length"].long()?.toInt()
        val t = if (max != null && max > 0 && text.length > max) text.substring(0, max) else text
        if (t.isEmpty()) answers.remove(key) else answers[key] = t
        changed(key, typing = true)
    }

    fun isConfirmed(option: Obj): Boolean = answers[key(option)].isTrue()

    fun setConfirm(option: Obj, value: Boolean) {
        answers[key(option)] = value
        changed(key(option), typing = false)
    }

    // ------------------------------------------------------------------------------------------------ quotes and the cart

    private fun changed(key: String, typing: Boolean) {
        if (key !in touched) touched.add(key)
        refused.remove(key)
        this.typing = typing
        changes++
    }

    /** The body of `platformAppStoreProductConfigure`. */
    val requestBody: JsonObject get() = body("answers" to answers.toMap())

    /** Starts a quote: its number and body. */
    fun begin(): Pair<Int, JsonObject> {
        latest++
        quoting = true
        return latest to requestBody
    }

    /** Applies a quote's `data` when it is the newest asked; an older one is dropped (false). */
    fun finish(seq: Int, data: Obj): Boolean {
        if (seq != latest) return false
        apply(data)
        quoting = false
        return true
    }

    /** A failed quote keeps what is shown. */
    fun fail(seq: Int) {
        if (seq == latest) quoting = false
    }

    private fun apply(data: Obj) {
        answer = answer + data.filterKeys { it in ANSWER_FIELDS }
        val given = data["answers"].obj()
        for (o in options) {
            val key = key(o)
            if (!isLocked(key)) continue
            val a = given[key]
            if (a == null) answers.remove(key) else answers[key] = a
            drafts.remove(key)
            if (isMeasure(o)) unitFromAnswer(o)?.let { units[key] = it }
        }
    }

    /** `platformAppStoreCartAdd`'s body. */
    fun cartBody(quantity: Int): JsonObject = mapOf("product_id" to product["id"], "qty" to quantity, "configuration" to answers.toMap()).json()

    /** A `CONFIGURATION_INVALID` refusal: each of `configuration_errors` under its option, every error shown. */
    fun applyRefusal(body: Obj) {
        refused.clear()
        body["configuration_errors"].objs().groupBy { it["option"].text() }.forEach { (k, list) -> refused[k] = list.map { it["message"].text() } }
        showAll = true
    }

    private fun unitFromAnswer(option: Obj): Int? {
        val a = answers[key(option)].obj()
        val entry = if (option["kind"] == "size") axes(option).map { a[it].obj() }.firstOrNull { it.isNotEmpty() } ?: emptyMap() else a
        return entry["unit"].long()?.toInt()
    }

    companion object {
        /** Millimetres per unit: 1 mm, 2 cm, 3 m, 4 in. */
        val MM: Map<Int, BigDecimal> = mapOf(1 to BigDecimal.ONE, 2 to BigDecimal.TEN, 3 to BigDecimal(1000), 4 to BigDecimal("25.4"))
        private val DECIMALS = mapOf(1 to 0, 2 to 1, 3 to 3, 4 to 3)
        private val ANSWER_FIELDS = setOf("state", "errors", "messages", "price", "summary")

        fun key(option: Obj): String = option["key"].text()

        /** A typed figure: `"48"`, `"48 3/8"`, `"3/8"`, `"122.5"` (a comma read as the decimal point). */
        fun parseFigure(text: String): BigDecimal? {
            val t = text.trim().replace(',', '.')
            if (t.isEmpty()) return null
            val parts = t.split(Regex("\\s+"))
            var sum = BigDecimal.ZERO
            for (p in parts) {
                sum += if (p.contains('/')) {
                    val (n, d) = p.split('/', limit = 2).map { it.toBigDecimalOrNull() ?: return null }
                    if (d.signum() == 0) return null
                    n.divide(d, MathContext.DECIMAL64)
                } else p.toBigDecimalOrNull() ?: return null
            }
            return sum
        }

        /** [figure] in [from] as [to], rounded down to [step]. */
        fun convert(figure: BigDecimal, from: Int, to: Int, step: BigDecimal): BigDecimal {
            val mm = figure.multiply(MM[from] ?: BigDecimal.ONE)
            val value = mm.divide(MM[to] ?: BigDecimal.ONE, MathContext.DECIMAL64)
            // 9 decimals first so a figure that is exactly on a step is not pushed below it by the division.
            val steps = value.divide(step, MathContext.DECIMAL64).setScale(9, RoundingMode.HALF_UP).setScale(0, RoundingMode.FLOOR)
            return steps.multiply(step).stripTrailingZeros()
        }

        /** A fraction below 1 as reduced `n/d`. */
        fun fractionText(value: BigDecimal): String {
            val v = value.stripTrailingZeros()
            var n = v.unscaledValue()
            var d = BigInteger.TEN.pow(v.scale().coerceAtLeast(0))
            if (v.scale() < 0) n = n.multiply(BigInteger.TEN.pow(-v.scale()))
            val g = n.gcd(d)
            if (g.signum() != 0) { n /= g; d /= g }
            return "$n/$d"
        }

        /** Millimetres shown in [unit]: inches with a fraction in eighths at most, else the unit's decimals (mm 0, cm 1, m 3). */
        fun showMm(mm: BigDecimal, unit: Int): String {
            val value = mm.divide(MM[unit] ?: BigDecimal.ONE, MathContext.DECIMAL64)
            if (unit == 4) {
                val eighths = value.multiply(BigDecimal(8)).setScale(0, RoundingMode.HALF_UP).toBigInteger()
                val whole = eighths.divide(BigInteger.valueOf(8))
                val rest = eighths.mod(BigInteger.valueOf(8))
                if (rest.signum() == 0) return whole.toString()
                val f = fractionText(BigDecimal(rest).divide(BigDecimal(8)))
                return if (whole.signum() == 0) f else "$whole $f"
            }
            return plain(value.setScale(DECIMALS[unit] ?: 0, RoundingMode.HALF_UP))
        }

        private fun plain(value: BigDecimal): String = value.stripTrailingZeros().let { if (it.signum() == 0) "0" else it.toPlainString() }
    }
}

// ---------------------------------------------------------------------------------------------------------- drawing

/** Where each drawn option sits on screen (root y), to scroll to the first error. */
internal class SrConfiguratorPositions {
    val top = mutableMapOf<String, Float>()
}

/** The configurator's options, messages and price; drawn by [ProductDetail] instead of variants and option groups. */
@Composable
internal fun SrConfiguratorView(c: SrConfigurator, currency: Any?, positions: SrConfiguratorPositions, onOpenLink: (String) -> Unit) {
    val s = superroute()
    val drawn = c.visibleOptions
    Column(Modifier.fillMaxWidth().testTag("sr-config")) {
        drawn.forEachIndexed { i, option ->
            c.heading(i, drawn)?.let { Text(it, style = s.figureStyle(), modifier = Modifier.padding(top = s.space("l")).testTag("sr-config-step-${option["step"].text()}")) }
            val key = SrConfigurator.key(option)
            Column(Modifier.fillMaxWidth().padding(top = s.space("m")).onGloballyPositioned { positions.top[key] = it.positionInRoot().y }.testTag("sr-config-option-$key")) {
                ConfigOption(c, option, onOpenLink)
            }
        }
        Spacer(Modifier.height(s.space("l")))
        c.generalErrors.forEachIndexed { i, e -> SrDanger(e, Modifier.testTag("sr-config-general-error-$i")) }
        c.messages.forEachIndexed { i, m ->
            val color = when (m["level"]) { "warning" -> s.color("warning"); "error" -> s.color("danger"); else -> s.color("onSurface") }
            Text(m["text"].text(), color = color, fontSize = s.size("body"), modifier = Modifier.padding(vertical = s.space("xs") / 2).testTag("sr-config-message-$i"))
        }
        ConfigPrice(c, currency)
    }
}

@Composable
private fun ConfigPrice(c: SrConfigurator, currency: Any?) {
    val s = superroute()
    var open by remember { mutableStateOf(false) }
    val dim = if (c.quoting) 0.5f else 1f
    Row(Modifier.fillMaxWidth().padding(top = s.space("s")), verticalAlignment = Alignment.CenterVertically) {
        SrBody(s.t("config.price"), Modifier.weight(1f), weight = FontWeight.SemiBold)
        Text(s.money(c.price["total"], currency), style = s.figureStyle(), modifier = Modifier.alpha(dim).testTag("sr-config-total"))
    }
    if (c.priceLines.isNotEmpty()) {
        SrTextButton(s.t(if (open) "config.hide_breakdown" else "config.show_breakdown"), "sr-config-breakdown") { open = !open }
        if (open) {
            c.priceLines.forEachIndexed { i, line ->
                Row(Modifier.fillMaxWidth().padding(vertical = s.space("xs") / 2).testTag("sr-config-line-$i")) {
                    Column(Modifier.weight(1f)) {
                        SrBody(line["label"].text())
                        line["detail"].text().takeIf { it.isNotEmpty() }?.let { SrMuted(it, small = true) }
                    }
                    SrBody(s.money(line["amount"], currency), Modifier.alpha(dim))
                }
            }
        }
    }
}

@Composable
private fun ConfigOption(c: SrConfigurator, option: Obj, onOpenLink: (String) -> Unit) {
    val s = superroute()
    val key = SrConfigurator.key(option)
    val help = c.help(option)
    var helpOpen by remember(key) { mutableStateOf(false) }
    val required = c.isRequired(option)
    val requiredText = s.t("config.required")
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        val label = option["label"].text()
        val summary = c.summary(key)
        Text(
            buildString { append(label); if (required) append(" *"); if (summary != null) append(" · ").append(summary) },
            fontSize = s.size("body"), fontWeight = FontWeight.SemiBold, color = s.color("onSurface"),
            modifier = Modifier.weight(1f).testTag("sr-config-label-$key").semantics {
                contentDescription = listOfNotNull(label, if (required) requiredText else null, summary).joinToString(", ")
            },
        )
        if (help != null) {
            val helpLabel = s.t("config.help")
            TextButton(onClick = { helpOpen = !helpOpen }, modifier = Modifier.size(48.dp).testTag("sr-config-help-$key").semantics { contentDescription = helpLabel },
                contentPadding = PaddingValues(0.dp)) { Text("?", fontWeight = FontWeight.SemiBold) }
        }
    }
    c.lockReason(key)?.let { SrMuted(it, Modifier.testTag("sr-config-locked-$key"), small = true) }
    if (help != null && helpOpen) {
        Column(Modifier.fillMaxWidth().padding(vertical = s.space("xs")).testTag("sr-config-help-text-$key")) {
            help["text"].text().takeIf { it.isNotEmpty() }?.let { SrMuted(it) }
            help["image"].text().takeIf { it.isNotEmpty() }?.let { SrImage(it, Modifier.fillMaxWidth().height(160.dp).padding(top = s.space("xs"))) }
            help["link"].text().takeIf { it.isNotEmpty() }?.let { link ->
                SrTextButton(help["link_label"].text().ifEmpty { s.t("config.more_info") }, "sr-config-help-link-$key") { onOpenLink(link) }
            }
        }
    }
    Spacer(Modifier.height(s.space("xs")))
    when (option["kind"]) {
        "choice", "choices" -> ConfigValues(c, option)
        "size", "length" -> ConfigMeasure(c, option)
        "number" -> ConfigNumber(c, option)
        "text", "textarea" -> OutlinedTextField(
            value = c.text(option), onValueChange = { c.setText(option, it) }, enabled = !c.isLocked(key),
            label = { Text(option["label"].text()) }, placeholder = option["placeholder"].text().takeIf { it.isNotEmpty() }?.let { { Text(it) } },
            singleLine = option["kind"] == "text", minLines = if (option["kind"] == "textarea") 3 else 1,
            modifier = Modifier.fillMaxWidth().testTag("sr-config-text-$key"),
        )
        "confirm" -> Row(
            Modifier.fillMaxWidth().heightIn(min = 48.dp).toggleable(c.isConfirmed(option), enabled = !c.isLocked(key), role = Role.Checkbox) { c.setConfirm(option, it) }
                .testTag("sr-config-confirm-$key"),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Checkbox(checked = c.isConfirmed(option), onCheckedChange = null, enabled = !c.isLocked(key))
            Spacer(Modifier.width(s.space("s")))
            SrBody(option["label"].text())
        }
    }
    c.shownErrors(key).forEachIndexed { i, e -> SrDanger(e, Modifier.padding(top = s.space("xs") / 2).testTag("sr-config-error-$key-$i")) }
}

/** A value's label with its `price_hint`. */
private fun valueLabel(v: Obj): String = listOf(v["label"].text(), v["price_hint"].text()).filter { it.isNotEmpty() }.joinToString(" ")

@Composable
private fun Badge(text: String) {
    val s = superroute()
    Text(text, color = s.color("warning"), fontSize = s.size("small"), fontWeight = FontWeight.SemiBold,
        modifier = Modifier.border(1.dp, s.color("warning"), RoundedCornerShape(s.radius("small"))).padding(horizontal = 6.dp, vertical = 1.dp))
}

@Composable
private fun Reason(text: String?) {
    if (text == null) return
    val s = superroute()
    Text(text, color = s.color("warning"), fontSize = s.size("small"))
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ConfigValues(c: SrConfigurator, option: Obj) {
    val s = superroute()
    val key = SrConfigurator.key(option)
    val multi = option["kind"] == "choices"
    val values = c.values(option)
    if (option["display"] == "dropdown") return ConfigDropdown(c, option, values)
    val wide = option["display"] == "cards_wide" || option["display"] == "checkbox_list"
    val content: @Composable (Obj) -> Unit = { v ->
        val vk = v["key"].text()
        val chosen = c.isChosen(option, vk)
        val enabled = c.isChoosable(option, vk)
        val reason = c.valueReason(key, vk)
        val tag = "sr-config-value-$key-$vk"
        val select = Modifier.selectable(chosen, enabled = enabled, role = if (multi) Role.Checkbox else Role.RadioButton) { c.tap(option, vk) }
            .semantics { contentDescription = listOfNotNull(valueLabel(v), reason).joinToString(", ") }
        val border = BorderStroke(if (chosen) 2.dp else 1.dp, if (chosen) s.color("primary") else s.color("muted").copy(alpha = 0.4f))
        val shape = RoundedCornerShape(s.radius("medium"))
        val alpha = if (enabled) 1f else 0.6f
        Column {
            when (option["display"]) {
                "cards" -> Column(Modifier.widthIn(min = 140.dp, max = 220.dp).heightIn(min = 48.dp).border(border, shape).then(select).padding(s.space("s")).alpha(alpha).testTag(tag)) {
                    if (v["image"].text().isNotEmpty()) SrImage(v["image"], Modifier.fillMaxWidth().height(96.dp))
                    ValueText(v, reason)
                }
                "cards_wide" -> Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).border(border, shape).then(select).padding(s.space("s")).alpha(alpha).testTag(tag), verticalAlignment = Alignment.CenterVertically) {
                    if (v["image"].text().isNotEmpty()) { SrImage(v["image"], Modifier.size(64.dp)); Spacer(Modifier.width(s.space("s"))) }
                    Column(Modifier.weight(1f)) { ValueText(v, reason) }
                }
                "image_swatch" -> Column(Modifier.width(88.dp).heightIn(min = 48.dp).then(select).alpha(alpha).testTag(tag), horizontalAlignment = Alignment.CenterHorizontally) {
                    SrImage(v["image"], Modifier.size(72.dp).border(border, RoundedCornerShape(s.radius("small"))))
                    Text(v["label"].text(), fontSize = s.size("small"), color = s.color("onSurface"), textAlign = TextAlign.Center)
                    Reason(reason)
                }
                "color_swatch" -> Column(Modifier.width(80.dp).heightIn(min = 48.dp).then(select).alpha(alpha).testTag(tag), horizontalAlignment = Alignment.CenterHorizontally) {
                    val color = runCatching { SrScope.parseColor(v["color"].text()) }.getOrDefault(Color.Transparent)
                    Box(Modifier.size(44.dp).border(border, CircleShape).padding(4.dp).background(color, CircleShape))
                    Text(v["label"].text(), fontSize = s.size("small"), color = s.color("onSurface"), textAlign = TextAlign.Center)
                    v["price_hint"].text().takeIf { it.isNotEmpty() }?.let { SrMuted(it, small = true) }
                    v["badge"].text().takeIf { it.isNotEmpty() }?.let { Badge(it) }
                    Reason(reason)
                }
                "checkbox_list" -> Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).then(select).alpha(alpha).testTag(tag), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = chosen, onCheckedChange = null, enabled = enabled)
                    Spacer(Modifier.width(s.space("s")))
                    Column(Modifier.weight(1f)) { ValueText(v, reason) }
                }
                else -> FilterChip(
                    selected = chosen, enabled = enabled, onClick = { c.tap(option, vk) },
                    label = { Column { Row(verticalAlignment = Alignment.CenterVertically) { Text(valueLabel(v)); v["badge"].text().takeIf { it.isNotEmpty() }?.let { Spacer(Modifier.width(4.dp)); Badge(it) } }; Reason(reason) } },
                    modifier = Modifier.heightIn(min = 48.dp).testTag(tag).semantics { contentDescription = listOfNotNull(valueLabel(v), reason).joinToString(", ") },
                )
            }
            if (multi && chosen && option["quantity"].isTrue()) {
                val q = c.quantityOf(option, vk)
                val max = option["max_quantity"].long()
                ConfigStepper(q.toString(), "$tag-qty", minus = q > 1, plus = max == null || q < max, onMinus = { c.setQuantity(option, vk, q - 1) }, onPlus = { c.setQuantity(option, vk, q + 1) })
            }
        }
    }
    if (wide) Column(verticalArrangement = Arrangement.spacedBy(s.space("xs")), modifier = Modifier.fillMaxWidth()) { values.forEach { content(it) } }
    else FlowRow(horizontalArrangement = Arrangement.spacedBy(s.space("xs")), verticalArrangement = Arrangement.spacedBy(s.space("xs")), modifier = Modifier.fillMaxWidth()) { values.forEach { content(it) } }
}

@Composable
private fun ValueText(v: Obj, reason: String?) {
    val s = superroute()
    Row(verticalAlignment = Alignment.CenterVertically) {
        SrBody(v["label"].text(), weight = FontWeight.SemiBold)
        v["badge"].text().takeIf { it.isNotEmpty() }?.let { Spacer(Modifier.width(s.space("xs"))); Badge(it) }
    }
    v["price_hint"].text().takeIf { it.isNotEmpty() }?.let { SrBody(it, size = s.size("small")) }
    v["description"].text().takeIf { it.isNotEmpty() }?.let { SrMuted(it, small = true) }
    Reason(reason)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ConfigDropdown(c: SrConfigurator, option: Obj, values: List<Obj>) {
    val s = superroute()
    val key = SrConfigurator.key(option)
    var open by remember { mutableStateOf(false) }
    val shown = values.filter { c.isChosen(option, it["key"].text()) }.joinToString(", ") { valueLabel(it) }
    ExposedDropdownMenuBox(expanded = open, onExpandedChange = { if (!c.isLocked(key)) open = it }) {
        OutlinedTextField(
            value = shown, onValueChange = {}, readOnly = true, enabled = !c.isLocked(key),
            placeholder = { Text(s.t("config.choose")) },
            modifier = Modifier.fillMaxWidth().menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable).testTag("sr-config-dropdown-$key")
                .semantics { contentDescription = option["label"].text() },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = open) },
        )
        ExposedDropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            values.forEach { v ->
                val vk = v["key"].text()
                val reason = c.valueReason(key, vk)
                DropdownMenuItem(
                    text = { Column { Text(valueLabel(v)); Reason(reason) } },
                    enabled = c.isChoosable(option, vk),
                    modifier = Modifier.heightIn(min = 48.dp).testTag("sr-config-value-$key-$vk"),
                    onClick = { if (option["kind"] != "choices") open = false; c.tap(option, vk) },
                )
            }
        }
    }
}

/** − n +, each a 48 dp target labelled `config.less` / `config.more`. */
@Composable
private fun ConfigStepper(value: String, tag: String, minus: Boolean, plus: Boolean, onMinus: () -> Unit, onPlus: () -> Unit) {
    val s = superroute()
    val less = s.t("config.less")
    val more = s.t("config.more")
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = s.space("xs"))) {
        OutlinedButton(onClick = onMinus, enabled = minus, modifier = Modifier.size(48.dp).testTag("$tag-minus").semantics { contentDescription = less }, contentPadding = PaddingValues(0.dp)) { Text("−") }
        Text(value, modifier = Modifier.widthIn(min = 40.dp).padding(horizontal = 4.dp).testTag(tag), textAlign = TextAlign.Center, fontSize = s.size("body"), color = s.color("onSurface"))
        OutlinedButton(onClick = onPlus, enabled = plus, modifier = Modifier.size(48.dp).testTag("$tag-plus").semantics { contentDescription = more }, contentPadding = PaddingValues(0.dp)) { Text("+") }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ConfigMeasure(c: SrConfigurator, option: Obj) {
    val s = superroute()
    val key = SrConfigurator.key(option)
    val unit = c.unitOf(option)
    val symbol = s.t("config.unit_$unit")
    val locked = c.isLocked(key)
    val units = c.unitsOf(option)
    if (units.size > 1) {
        val unitsLabel = s.t("config.units")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(s.space("xs")), modifier = Modifier.semantics { contentDescription = unitsLabel }) {
            units.forEach { u ->
                FilterChip(selected = u == unit, enabled = !locked, onClick = { c.switchUnit(option, u) }, label = { Text(s.t("config.unit_$u")) },
                    modifier = Modifier.heightIn(min = 48.dp).testTag("sr-config-unit-$key-$u"))
            }
        }
    }
    for (axis in c.axes(option)) {
        val label = if (option["kind"] == "size") s.t("config.$axis") else option["label"].text()
        val pad = c.isFractionPad(option)
        Row(Modifier.fillMaxWidth().padding(top = s.space("xs")), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = if (pad) c.wholeText(option, axis) else c.axisText(option, axis),
                onValueChange = { if (pad) c.setWhole(option, axis, it) else c.setAxis(option, axis, it) },
                enabled = !locked, singleLine = true, label = { Text(label) },
                keyboardOptions = KeyboardOptions(keyboardType = if (pad) KeyboardType.Number else KeyboardType.Decimal),
                modifier = Modifier.weight(1f).testTag("sr-config-axis-$key-$axis"),
            )
            Spacer(Modifier.width(s.space("s")))
            SrBody(symbol)
        }
        if (pad) {
            val fractionLabel = s.t("config.fraction")
            val chosen = c.fractionIndex(option, axis)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(s.space("xs")), modifier = Modifier.semantics { contentDescription = "$label, $fractionLabel" }) {
                c.fractions(option).forEachIndexed { i, f ->
                    FilterChip(selected = i == chosen, enabled = !locked, onClick = { c.setFraction(option, axis, i) }, label = { Text(f) },
                        modifier = Modifier.heightIn(min = 48.dp).testTag("sr-config-fraction-$key-$axis-$i"))
                }
            }
        }
        c.range(option, axis)?.let { (min, max) ->
            if (min != null && max != null) {
                SrMuted(s.t("config.range", "min" to "${SrConfigurator.showMm(min, unit)} $symbol", "max" to "${SrConfigurator.showMm(max, unit)} $symbol"),
                    Modifier.testTag("sr-config-range-$key-$axis"), small = true)
            }
        }
    }
}

@Composable
private fun ConfigNumber(c: SrConfigurator, option: Obj) {
    val s = superroute()
    val key = SrConfigurator.key(option)
    val locked = c.isLocked(key)
    val min = option["min_value"].decimal()
    val max = option["max_value"].decimal()
    when {
        option["display"] == "stepper" -> {
            val value = c.answers[key].decimal()
            ConfigStepper(c.numberText(option).ifEmpty { "–" }, "sr-config-number-$key",
                minus = !locked && (value == null || min == null || value > min), plus = !locked && (value == null || max == null || value < max),
                onMinus = { c.stepNumber(option, -1) }, onPlus = { c.stepNumber(option, 1) })
        }
        option["display"] == "slider" && min != null && max != null && max > min -> {
            val step = option["number_step"].decimal()?.takeIf { it.signum() > 0 }
            val count = step?.let { (max - min).divide(it, MathContext.DECIMAL64).toInt() - 1 }?.coerceIn(0, 1000) ?: 0
            val current = c.answers[key].decimal() ?: min
            Row(verticalAlignment = Alignment.CenterVertically) {
                Slider(
                    value = current.toFloat(), valueRange = min.toFloat()..max.toFloat(), steps = count, enabled = !locked,
                    onValueChange = { f ->
                        var v = BigDecimal(f.toDouble())
                        v = if (step != null) min + (v - min).divide(step, 0, RoundingMode.HALF_UP).multiply(step) else v.setScale(2, RoundingMode.HALF_UP)
                        c.setNumber(option, v.stripTrailingZeros(), typing = true)
                    },
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("sr-config-number-$key").semantics { contentDescription = option["label"].text() },
                )
                Spacer(Modifier.width(s.space("s")))
                SrBody(c.numberText(option))
            }
        }
        else -> OutlinedTextField(
            value = c.numberText(option), onValueChange = { c.setNumberText(option, it) }, enabled = !locked, singleLine = true,
            label = { Text(option["label"].text()) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth().testTag("sr-config-number-$key"),
        )
    }
}
