package ca.superroute.sapp.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.InputChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import ca.superroute.sapp.OperationFile
import ca.superroute.sapp.SuperrouteException
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonElement
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** The `data` of an answer, or the answer itself where the driver route answers without one. */
internal fun JsonElement.dataOrSelf(): Any? = plain().let { if (it is Map<*, *> && it.containsKey("data")) it["data"] else it }

/** The message a driver route answered with (a string or a list), else the general error text. */
internal fun SrEnv.failure(e: Throwable): String {
    if (e is SuperrouteException && e.status in 400..499 && e.status != 401 && e.status != 403) {
        when (val m = errorBody(e)["message"]) {
            is String -> if (m.isNotEmpty()) return m
            is List<*> -> if (m.isNotEmpty()) return m.joinToString(" ") { it.text() }
        }
    }
    return errorText(e)
}

/** A claim status in the driver's language: the four active ones are translated, any other is its code as words. */
internal fun SrEnv.claimStatus(status: Any?): String = "drv.claim_${status.text()}".let { if (strings.has(it)) t(it) else status.text().replace('_', ' ') }

/** A driver's position, as the app reads it (UI-KIT-SPEC.md §P3e: the device is the app's). */
data class SrPosition(val latitude: Double, val longitude: Double)

/** A list of one answer's driver data, loaded and reloaded. */
abstract class SrDriverState(val env: SrEnv) {
    var loading by mutableStateOf(true)
        protected set
    var error by mutableStateOf<Throwable?>(null)
        protected set
    var message by mutableStateOf<String?>(null)
        protected set

    protected abstract suspend fun fetch()

    suspend fun reload() {
        loading = true
        error = null
        env.attempt { fetch() }.onFailure { error = it }
        loading = false
    }
}

@Composable
private fun DriverChips(options: List<Pair<String, String>>, value: String?, tag: String, onChoose: (String) -> Unit) {
    val s = superroute()
    Column(Modifier.padding(horizontal = s.space("m"), vertical = s.space("s"))) { SrChips(options, { it == value }, tag, onChoose) }
}

@Composable
private fun ListRow(tag: String, onClick: (() -> Unit)? = null, leading: (@Composable () -> Unit)? = null, trailing: (@Composable () -> Unit)? = null, title: String, subtitle: String) {
    val s = superroute()
    Row(
        Modifier.fillMaxWidth().heightIn(min = 48.dp).let { if (onClick != null) it.clickable(onClick = onClick) else it }
            .padding(horizontal = s.space("m"), vertical = s.space("s")).testTag(tag),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        leading?.let { it(); Spacer(Modifier.width(s.space("m"))) }
        Column(Modifier.weight(1f)) {
            SrBody(title)
            if (subtitle.isNotEmpty()) SrMuted(subtitle, small = true)
        }
        trailing?.invoke()
    }
}

// ---------------------------------------------------------------------------------------------------------- routes

/** The state of [DriverRoutes] (UI-KIT-SPEC.md §Driver routes). */
class DriverRoutesState(env: SrEnv) : SrDriverState(env) {
    var history by mutableStateOf(false)
        private set
    var routes by mutableStateOf<List<Obj>>(emptyList())
        private set

    override suspend fun fetch() { routes = env.api.driverRoutes(isHistory = if (history) 1 else null).dataOrSelf().objs() }

    suspend fun choose(history: Boolean) {
        this.history = history
        reload()
    }

    fun details(r: Obj): String {
        val counts = r["count"].obj().entries.joinToString(" · ") { (k, v) -> "${k.replace('_', ' ')}: ${v.text()}" }
        return listOf(r["date"].text(), env.t("drv.stops", "count" to (r["total"] ?: 0)), counts).filter { it.isNotEmpty() }.joinToString("\n")
    }
}

/** The driver's routes, **Current** and **History**. [onOpen] gets a route's id. */
@Composable
fun DriverRoutes(onOpen: (routeId: Long) -> Unit = {}, modifier: Modifier = Modifier, onError: ((SuperrouteException) -> Unit)? = null) {
    val s = superroute()
    val state = rememberLoaded(onError, create = ::DriverRoutesState) { reload() }
    val scope = rememberCoroutineScope()
    Column(modifier.fillMaxSize()) {
        DriverChips(listOf("current" to s.t("drv.current"), "history" to s.t("drv.history")), if (state.history) "history" else "current", "sr-drv-chip") {
            scope.launch { state.choose(it == "history") }
        }
        SrStateView(state.loading, state.error, state.routes.isEmpty(), s.t("drv.no_routes"), { scope.launch { state.reload() } }) {
            LazyColumn(Modifier.fillMaxSize()) {
                items(state.routes) { r ->
                    ListRow("sr-drv-route-${r["id"].text()}", { onOpen(r["id"].long() ?: 0) }, title = (r["name"] ?: r["id"]).text(), subtitle = state.details(r))
                    HorizontalDivider()
                }
            }
        }
    }
}

/** The state of [RouteStops] (UI-KIT-SPEC.md §Route stops). */
class RouteStopsState(env: SrEnv, val routeId: Long) : SrDriverState(env) {
    var hideFinished by mutableStateOf(false)
        private set
    var stops by mutableStateOf<List<Obj>>(emptyList())
        private set
    var busy by mutableStateOf(false)
        private set

    override suspend fun fetch() { stops = env.api.driverRoutesOrders(routeId, isHideSuccess = if (hideFinished) 1 else null).dataOrSelf().objs() }

    suspend fun hide(on: Boolean) {
        hideFinished = on
        reload()
    }

    fun finished(o: Obj): Boolean = o["is_finished"].let { it == true || it.long() == 1L }

    fun details(o: Obj): String = listOf(
        o["full_address"].text(),
        listOfNotNull(o["status"].text(), env.t("drv.packages", "count" to (o["packages"] ?: 0)), if (finished(o)) env.t("drv.finished") else null).filter { it.isNotEmpty() }.joinToString(" · "),
    ).filter { it.isNotEmpty() }.joinToString("\n")

    /** **Start delivery** / **End delivery**, after the driver confirmed; reloads. */
    suspend fun run(start: Boolean) {
        busy = true
        message = null
        val request = body("routeId" to routeId)
        env.attempt { if (start) env.api.driverStartDelivery(request) else env.api.driverEndDelivery(request) }
            .onSuccess {
                message = env.t(if (start) "drv.started" else "drv.ended")
                reload()
            }
            .onFailure { message = env.failure(it) }
        busy = false
    }
}

/** One route's stops, with **Start delivery** and **End delivery** (each asked first). [onOpenStop] gets the route and order ids. */
@Composable
fun RouteStops(routeId: Long, onOpenStop: (routeId: Long, orderId: Long) -> Unit = { _, _ -> }, modifier: Modifier = Modifier, onError: ((SuperrouteException) -> Unit)? = null) {
    val s = superroute()
    val state = rememberLoaded(onError, routeId, create = { RouteStopsState(it, routeId) }) { reload() }
    val scope = rememberCoroutineScope()
    var ask by remember { mutableStateOf<SrAsk?>(null) }
    SrAskDialog(ask, scope) { ask = null }
    Column(modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(s.space("m"))) {
            SrPrimaryButton(s.t("drv.start"), "sr-drv-start", enabled = !state.busy, modifier = Modifier.weight(1f)) {
                ask = SrAsk(s.t("drv.start_confirm"), s.t("drv.start"), "sr-drv-confirm") { state.run(true) }
            }
            Spacer(Modifier.width(s.space("s")))
            SrOutlinedButton(s.t("drv.end"), "sr-drv-end", enabled = !state.busy, modifier = Modifier.weight(1f)) {
                ask = SrAsk(s.t("drv.end_confirm"), s.t("drv.end"), "sr-drv-confirm") { state.run(false) }
            }
        }
        Column(Modifier.padding(horizontal = s.space("m"))) {
            SrSwitch(s.t("drv.hide_finished"), state.hideFinished, "sr-drv-hide-finished") { scope.launch { state.hide(it) } }
        }
        SrNotice(state.message, "sr-drv-message")
        SrStateView(state.loading, state.error, state.stops.isEmpty(), s.t("drv.no_stops"), { scope.launch { state.reload() } }) {
            LazyColumn(Modifier.fillMaxSize()) {
                items(state.stops) { o ->
                    val finished = state.finished(o)
                    ListRow(
                        "sr-drv-stop-${o["id"].text()}", { onOpenStop(routeId, o["id"].long() ?: 0) },
                        leading = {
                            Box(Modifier.size(40.dp).background(if (finished) s.color("success") else s.color("primary"), CircleShape), contentAlignment = Alignment.Center) {
                                Text(o["stop_number"].text(), color = s.color("onPrimary"))
                            }
                        },
                        title = o["name"].text(), subtitle = state.details(o),
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------- signature

/** A signature drawn with a finger: its strokes in pixels and the pad's size; exported as a PNG. */
class SrSignature {
    val strokes = mutableStateListOf<List<Offset>>()
    var width = 0
    var height = 0

    val isEmpty: Boolean get() = strokes.all { it.size < 2 }

    fun clear() = strokes.clear()
    fun start(at: Offset) { strokes.add(listOf(at)) }
    fun extend(to: Offset) { if (strokes.isNotEmpty()) strokes[strokes.lastIndex] = strokes.last() + to }

    /** Draws the strokes into PNG bytes (replaceable, so a JVM test needs no Android graphics). */
    var render: (SrSignature) -> ByteArray? = ::renderPng

    /** The signature as PNG bytes, or null when nothing was drawn. */
    fun toPng(): ByteArray? = if (isEmpty || width <= 0 || height <= 0) null else render(this)

    companion object {
        fun renderPng(signature: SrSignature): ByteArray? {
            val bitmap = android.graphics.Bitmap.createBitmap(signature.width, signature.height, android.graphics.Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(bitmap)
            canvas.drawColor(android.graphics.Color.WHITE)
            val paint = android.graphics.Paint().apply {
                color = android.graphics.Color.BLACK; strokeWidth = 5f; style = android.graphics.Paint.Style.STROKE
                strokeCap = android.graphics.Paint.Cap.ROUND; isAntiAlias = true
            }
            for (stroke in signature.strokes) {
                if (stroke.size < 2) continue
                val path = android.graphics.Path().apply {
                    moveTo(stroke[0].x, stroke[0].y)
                    stroke.drop(1).forEach { lineTo(it.x, it.y) }
                }
                canvas.drawPath(path, paint)
            }
            return ByteArrayOutputStream().use { out ->
                bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out)
                bitmap.recycle()
                out.toByteArray()
            }
        }
    }
}

/** The pad a driver signs on with a finger. */
@Composable
fun SrSignaturePad(signature: SrSignature, label: String, modifier: Modifier = Modifier) {
    val s = superroute()
    Box(
        modifier.fillMaxWidth().height(160.dp).border(1.dp, s.color("muted"), RoundedCornerShape(s.radius("medium")))
            .background(Color.White, RoundedCornerShape(s.radius("medium")))
            .onSizeChanged { signature.width = it.width; signature.height = it.height }
            .pointerInput(signature) { detectDragGestures(onDragStart = { signature.start(it) }) { change, _ -> signature.extend(change.position) } }
            .semantics { contentDescription = label }.testTag("sr-drv-signature-pad"),
    ) {
        Canvas(Modifier.fillMaxSize()) {
            for (stroke in signature.strokes) {
                if (stroke.size < 2) continue
                val path = Path().apply {
                    moveTo(stroke[0].x, stroke[0].y)
                    stroke.drop(1).forEach { lineTo(it.x, it.y) }
                }
                drawPath(path, Color.Black, style = Stroke(width = 5f, cap = StrokeCap.Round))
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------- stop

/** The state of [Stop] (UI-KIT-SPEC.md §Stop). */
class StopState(env: SrEnv, val routeId: Long, val orderId: Long) : SrDriverState(env) {
    var order by mutableStateOf<Obj>(emptyMap())
        private set
    var pod by mutableStateOf<Obj>(emptyMap())
        private set
    var statuses by mutableStateOf<Map<String, String>>(emptyMap())
        private set
    var reasons by mutableStateOf<List<Obj>>(emptyList())
        private set
    var done by mutableStateOf(true)
    var failStatus by mutableStateOf<String?>(null)
    var reasonId by mutableStateOf<Long?>(null)
    val photos = mutableStateListOf<SrPickedFile>()
    val signature = SrSignature()
    var signedBy by mutableStateOf("")
    var pin by mutableStateOf("")
    val errors = mutableStateMapOf<String, String>()
    var sending by mutableStateOf(false)
        private set
    /** Set after a successful completion. */
    var completed by mutableStateOf(false)
        private set

    override suspend fun fetch() {
        val api = env.api
        order = api.driverOrders(orderId).dataOrSelf().obj()
        pod = attempt { api.driverPodRequirements().plain().obj() }.getOrElse { emptyMap() }
        statuses = attempt { api.driverOrdersStatus().plain().obj().mapValues { it.value.text() } }.getOrElse { emptyMap() }
        reasons = attempt { api.driverReturnReasons(orderId).dataOrSelf().objs() }.getOrElse { emptyList() }
        photos.clear()
        failStatus = statuses.keys.firstOrNull { it != "S" }
    }

    val isPickup: Boolean get() = order["type"].text().uppercase() == "P"
    val photoRequired: Boolean get() = done && pod["enabled"] != false && pod["pickup_photo_required"].isTrue() && isPickup
    val signatureRequired: Boolean get() = done && (order["signature_option"] as? Number)?.toInt()?.let { it != 0 } == true
    val pinRequired: Boolean get() = done && order["pin_required"].let { it == true || it.long() == 1L }
    val failStatuses: Map<String, String> get() = statuses.filterKeys { it != "S" }
    val address: String
        get() = order["full_address"]?.text() ?: listOf(order["address_1"].text(), order["city"].text(), order["postcode"].text()).filter { it.isNotEmpty() }.joinToString(", ")

    /** Takes a photo the app picked: JPEG or PNG, at most 2 MB, up to 5. */
    fun addPhoto(file: SrPickedFile?) {
        file ?: return
        val ext = if (file.name.contains('.')) file.name.substringAfterLast('.').lowercase() else ""
        if (ext !in setOf("jpg", "jpeg", "png") || file.bytes.size > MAX_BYTES || photos.size >= MAX_PHOTOS) {
            errors["photos"] = env.t("drv.photo_invalid")
        } else {
            photos.add(file)
            errors.remove("photos")
        }
    }

    fun validate(): Boolean {
        errors.clear()
        if (photoRequired && photos.isEmpty()) errors["photos"] = env.t("drv.photo_required")
        if (signatureRequired && signature.isEmpty) errors["signature"] = env.t("drv.signature_required")
        if (pinRequired && !Regex("^\\d{6}$").matches(pin.trim())) errors["pin"] = env.t("drv.pin_invalid")
        if (!done && failStatus == null) errors["status"] = env.t("rform.required")
        if (!done && reasons.isNotEmpty() && reasonId == null) errors["reason"] = env.t("rform.required")
        return errors.isEmpty()
    }

    /**
     * **Complete stop**: asks the position and sends one multipart call (photos as `photo_files[]`, the signature as
     * `signature_file`). Without a position nothing is sent. Answers the status code sent.
     */
    suspend fun complete(getPosition: suspend () -> SrPosition?, now: () -> Date = ::Date): String? {
        message = null
        if (!validate()) return null
        sending = true
        val result = env.attempt {
            val position = getPosition()
            if (position == null) {
                message = env.t("drv.no_position")
                return@attempt null
            }
            val png = if (done) signature.toPng() else null
            val status = if (done) "S" else failStatus!!
            val fields = buildMap<String, Any?> {
                put("route_id", routeId)
                put("order_id", orderId)
                put("latitude", position.latitude)
                put("longitude", position.longitude)
                put("status_code", status)
                if (!done && reasonId != null) put("return_reason_id", reasonId)
                if (png != null && signedBy.isNotBlank()) put("signature_note", signedBy.trim())
                if (pinRequired) put("delivery_pin", pin.trim())
                put("captured_at", isoUtc(now()))
            }
            val files = photos.map { OperationFile("photo_files[]", it.bytes, it.name, it.contentType ?: if (it.name.lowercase().endsWith(".png")) "image/png" else "image/jpeg") } +
                listOfNotNull(png?.let { OperationFile("signature_file", it, "signature.png", "image/png") })
            env.api.driverUpdateDeliver(fields.json(), files)
            completed = true
            message = env.t("drv.completed")
            status
        }
        result.onFailure { message = env.failure(it) }
        sending = false
        return result.getOrNull()
    }

    companion object {
        const val MAX_PHOTOS = 5
        const val MAX_BYTES = 2 * 1024 * 1024

        fun isoUtc(date: Date): String = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(date)
    }
}

/**
 * One stop and its completion. The position, photos and calls are the app's: [getPosition], [pickPhoto], [onCall],
 * [onNavigate]. [onCompleted] gets the order id and the status code sent.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Stop(
    routeId: Long,
    orderId: Long,
    getPosition: suspend () -> SrPosition?,
    pickPhoto: (suspend () -> SrPickedFile?)? = null,
    onCompleted: (orderId: Long, statusCode: String) -> Unit = { _, _ -> },
    onCall: (phone: String) -> Unit = {},
    onNavigate: (latitude: Double?, longitude: Double?, address: String) -> Unit = { _, _, _ -> },
    modifier: Modifier = Modifier,
    onError: ((SuperrouteException) -> Unit)? = null,
) {
    val s = superroute()
    val state = rememberLoaded(onError, routeId, orderId, create = { StopState(it, routeId, orderId) }) { reload() }
    val scope = rememberCoroutineScope()
    SrFormFrame(state.loading, state.error, { scope.launch { state.reload() } }) {
        val o = state.order
        val e = state.errors
        val phone = o["telephone"].text()
        Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(s.space("m"))) {
            SrMuted(s.t("drv.stop_number", "n" to (o["stop_number"] ?: "")))
            Text(o["name"].text(), fontSize = s.size("headline"), fontWeight = FontWeight.SemiBold, color = s.color("onSurface"))
            "${o["ref"].text()} ${o["tracking_number"].text()}".trim().takeIf { it.isNotEmpty() }?.let { SrBody(it) }
            ListRow("sr-drv-navigate", { onNavigate(o["latitude"].decimal()?.toDouble(), o["longitude"].decimal()?.toDouble(), state.address) },
                trailing = { SrBody(s.t("drv.navigate"), color = s.color("primary")) }, title = state.address,
                subtitle = if (o["buzz_code"].text().isEmpty()) "" else "${s.t("drv.buzz")}: ${o["buzz_code"].text()}")
            if (phone.isNotEmpty()) ListRow("sr-drv-call", { onCall(phone) }, trailing = { SrBody(s.t("drv.call"), color = s.color("primary")) }, title = phone, subtitle = "")
            SrBody(s.t("drv.packages", "count" to (o["packages"] ?: 0)))
            if (o["note"].text().isNotEmpty()) SrBody(o["note"].text(), Modifier.padding(top = s.space("s")))
            o["driverNotes"].objs().forEach { SrMuted((it["note"] ?: it["content"]).text()) }
            Spacer(Modifier.height(s.space("l")))
            SrChips(listOf("done" to s.t("drv.done"), "failed" to s.t("drv.not_done")), { (it == "done") == state.done }, "sr-drv-outcome") { state.done = it == "done" }
            if (!state.done) {
                Spacer(Modifier.height(s.space("s")))
                SrBody(s.t("drv.status"), weight = FontWeight.SemiBold)
                SrChips(state.failStatuses.toList(), { it == state.failStatus }, "sr-drv-status") { state.failStatus = it }
                e["status"]?.let { SrDanger(it, Modifier.testTag("sr-drv-error-status")) }
                if (state.reasons.isNotEmpty()) {
                    Spacer(Modifier.height(s.space("s")))
                    SrBody("${s.t("drv.reason")} *", weight = FontWeight.SemiBold)
                    state.reasons.forEach { r ->
                        val id = r["id"].long() ?: 0
                        Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { state.reasonId = id }.testTag("sr-drv-reason-$id"), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = state.reasonId == id, onClick = { state.reasonId = id })
                            SrBody(r["reason"].text())
                        }
                    }
                    e["reason"]?.let { SrDanger(it, Modifier.testTag("sr-drv-error-reason")) }
                }
            }
            Spacer(Modifier.height(s.space("m")))
            SrBody("${s.t("drv.photos")}${if (state.photoRequired) " *" else ""}", weight = FontWeight.SemiBold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(s.space("xs"))) {
                state.photos.forEachIndexed { i, p ->
                    InputChip(selected = false, onClick = { state.photos.removeAt(i) }, label = { Text("${p.name}  ×") }, modifier = Modifier.heightIn(min = 44.dp).testTag("sr-drv-photo-$i"))
                }
                if (pickPhoto != null && state.photos.size < StopState.MAX_PHOTOS) {
                    SrOutlinedButton(s.t("drv.add_photo"), "sr-drv-add-photo") { scope.launch { state.addPhoto(pickPhoto()) } }
                }
            }
            e["photos"]?.let { SrDanger(it, Modifier.testTag("sr-drv-error-photos")) }
            if (state.done) {
                Spacer(Modifier.height(s.space("m")))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SrBody("${s.t("drv.signature")}${if (state.signatureRequired) " *" else ""}", Modifier.weight(1f), weight = FontWeight.SemiBold)
                    SrTextButton(s.t("drv.clear"), "sr-drv-signature-clear") { state.signature.clear() }
                }
                SrSignaturePad(state.signature, s.t("drv.signature"))
                e["signature"]?.let { SrDanger(it, Modifier.testTag("sr-drv-error-signature")) }
                SrField(state.signedBy, { state.signedBy = it }, s.t("drv.signed_by"), "sr-drv-signed-by")
                if (state.pinRequired) {
                    SrField(state.pin, { if (it.length <= 6) state.pin = it }, s.t("drv.pin"), "sr-drv-pin", required = true, error = e["pin"], keyboard = KeyboardType.Number)
                }
            }
            SrNotice(state.message, "sr-drv-message", danger = !state.completed)
            Spacer(Modifier.height(s.space("l")))
            SrPrimaryButton(s.t("drv.complete"), "sr-drv-complete", enabled = !state.sending) {
                scope.launch { state.complete(getPosition)?.let { onCompleted(orderId, it) } }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------- duty

/** The state of [DriverDuty] (UI-KIT-SPEC.md §Duty and offers). */
class DriverDutyState(env: SrEnv) : SrDriverState(env) {
    var duty by mutableStateOf<Obj>(emptyMap())
        private set
    var busy by mutableStateOf(false)
        private set

    override suspend fun fetch() { duty = env.api.driverDuty().dataOrSelf().obj() }

    val enabled: Boolean get() = duty["feature_enabled"].isTrue()
    val offers: List<Obj> get() = duty["pending_offers"].objs()

    /** The **On duty** switch; put back on failure. */
    suspend fun toggle(on: Boolean) {
        val before = duty["on_duty"]
        duty = duty + ("on_duty" to on)
        message = null
        env.attempt { env.api.driverDutyUpdate(body("on_duty" to on)).dataOrSelf().obj() }
            .onSuccess { if (it.isNotEmpty()) duty = it }
            .onFailure {
                duty = duty + ("on_duty" to before)
                message = env.failure(it)
            }
    }

    private fun orderId(offer: Obj): Long = offer["order_id"].long() ?: offer["subject_id"].long() ?: 0

    suspend fun accept(offer: Obj) = answer { env.api.driverAssignmentRespond(orderId(offer)) }

    /** Rejects (after the driver confirmed) with an optional reason. */
    suspend fun reject(offer: Obj, reason: String) = answer {
        env.api.driverOrdersOrderIdRejectPost(orderId(offer), if (reason.isBlank()) body() else body("reason" to reason.trim()))
    }

    private suspend fun answer(call: suspend () -> Unit) {
        busy = true
        message = null
        env.attempt { call() }.onSuccess { reload() }.onFailure { message = env.failure(it) }
        busy = false
    }
}

/** On / off duty and the auto-assign offers. */
@Composable
fun DriverDuty(modifier: Modifier = Modifier, onError: ((SuperrouteException) -> Unit)? = null) {
    val s = superroute()
    val state = rememberLoaded(onError, create = ::DriverDutyState) { reload() }
    val scope = rememberCoroutineScope()
    var ask by remember { mutableStateOf<SrAsk?>(null) }
    SrAskDialog(ask, scope, reasonLabel = s.t("drv.reject_reason")) { ask = null }
    SrStateView(state.loading, state.error, state.duty.isEmpty() && (state.loading || state.error != null), "", { scope.launch { state.reload() } }) {
        if (!state.enabled) {
            SrBody(s.t("drv.duty_off"), Modifier.padding(s.space("l")).testTag("sr-drv-duty-off"))
            return@SrStateView
        }
        LazyColumn(modifier.fillMaxSize()) {
            item {
                Column(Modifier.padding(horizontal = s.space("m"))) {
                    SrSwitch(s.t("drv.on_duty"), state.duty["on_duty"].isTrue(), "sr-drv-on-duty", enabled = !state.busy) { scope.launch { state.toggle(it) } }
                    SrNotice(state.message, "sr-drv-message")
                    SrTitle(s.t("drv.offers"))
                    if (state.offers.isEmpty()) SrMuted(s.t("drv.no_offers"))
                }
            }
            items(state.offers) { offer ->
                val id = offer["offer_id"].text()
                val expires = offer["expires_at"]?.let { s.t("drv.offer_expires", "date" to s.date(it.text().replaceFirst(' ', 'T'))) }
                ListRow("sr-drv-offer-$id", title = (offer["order_ref"] ?: offer["order_id"]).text(),
                    subtitle = listOfNotNull(offer["address"].text(), expires).filter { it.isNotEmpty() }.joinToString("\n"),
                    trailing = {
                        Row {
                            SrPrimaryButton(s.t("drv.accept"), "sr-drv-accept-$id", enabled = !state.busy, modifier = Modifier) { scope.launch { state.accept(offer) } }
                            SrTextButton(s.t("drv.reject"), "sr-drv-reject-$id", enabled = !state.busy) {
                                ask = SrAsk(s.t("drv.reject_confirm"), s.t("drv.reject"), "sr-drv-confirm", reason = true) { state.reject(offer, it) }
                            }
                        }
                    })
                HorizontalDivider()
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------- pool

/** The state of [DriverPool] (UI-KIT-SPEC.md §Pool). */
class DriverPoolState(env: SrEnv) : SrDriverState(env) {
    var answer by mutableStateOf<Obj>(emptyMap())
        private set
    var taking by mutableStateOf<Long?>(null)
        private set

    override suspend fun fetch() { answer = env.api.driverPoolOrders().plain().obj() }

    val enabled: Boolean get() = answer["meta"].obj()["enabled"] != false
    val orders: List<Obj> get() = answer["data"].objs()

    fun details(o: Obj): String = listOf(
        o["address"].text(),
        listOfNotNull(env.t("drv.packages", "count" to (o["packages"] ?: 0)), o["distance_km"]?.let { env.t("lockers.distance", "km" to it) }).joinToString(" · "),
        if (o["time_window_start"] != null) "${o["time_window_start"].text()} – ${o["time_window_end"].text()}" else "",
    ).filter { it.isNotEmpty() }.joinToString("\n")

    /** **Take**: shows the stop number, or `drv.pool_taken` on a 409; reloads either way. */
    suspend fun take(orderId: Long) {
        taking = orderId
        message = null
        env.attempt { env.api.driverPoolClaim(orderId).dataOrSelf().obj() }
            .onSuccess { message = env.t("drv.pool_claimed", "n" to (it["stop_number"] ?: "")) }
            .onFailure { message = if (it is SuperrouteException && it.status == 409) env.t("drv.pool_taken") else env.failure(it) }
        reload()
        taking = null
    }
}

/** Orders a dispatcher published to the driver pool. */
@Composable
fun DriverPool(modifier: Modifier = Modifier, onError: ((SuperrouteException) -> Unit)? = null) {
    val s = superroute()
    val state = rememberLoaded(onError, create = ::DriverPoolState) { reload() }
    val scope = rememberCoroutineScope()
    if (!state.loading && state.error == null && !state.enabled) {
        SrBody(s.t("drv.pool_off"), modifier.padding(s.space("l")).testTag("sr-drv-pool-off"))
        return
    }
    Column(modifier.fillMaxSize()) {
        SrNotice(state.message, "sr-drv-message")
        SrStateView(state.loading, state.error, state.orders.isEmpty(), s.t("drv.pool_empty"), { scope.launch { state.reload() } }) {
            LazyColumn(Modifier.fillMaxSize()) {
                items(state.orders) { o ->
                    val id = o["order_id"].long() ?: 0
                    ListRow("sr-drv-pool-$id", title = "${(o["ref"] ?: id).text()} · ${o["name"].text()}", subtitle = state.details(o), trailing = {
                        SrPrimaryButton(s.t("drv.take"), "sr-drv-take-$id", enabled = state.taking == null, modifier = Modifier) { scope.launch { state.take(id) } }
                    })
                    HorizontalDivider()
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------- boards

/** The state of [RouteBoards] (UI-KIT-SPEC.md §Route boards). */
class RouteBoardsState(env: SrEnv) : SrDriverState(env) {
    var boards by mutableStateOf<List<Obj>>(emptyList())
        private set

    override suspend fun fetch() { boards = env.api.driverRouteBoards().dataOrSelf().objs() }

    fun details(b: Obj): String {
        val mine = when {
            (b["my_primary"].long() ?: 0) > 0 -> "primary"
            (b["my_standby"].long() ?: 0) > 0 -> "standby"
            (b["my_pooled"].long() ?: 0) > 0 -> "pooled"
            else -> null
        }
        return listOfNotNull(
            b["date"].text(),
            if (b["is_open"].isTrue()) env.t("drv.open_seats", "open" to (b["open_seats"] ?: 0), "seats" to (b["seats"] ?: 0)) else env.t("drv.board_closed"),
            mine?.let { env.t("drv.my_claim", "status" to env.claimStatus(it)) },
        ).filter { it.isNotEmpty() }.joinToString(" · ")
    }
}

/** The route boards the driver may claim from. [onOpen] gets a board's id. */
@Composable
fun RouteBoards(onOpen: (boardId: Long) -> Unit = {}, modifier: Modifier = Modifier, onError: ((SuperrouteException) -> Unit)? = null) {
    val s = superroute()
    val state = rememberLoaded(onError, create = ::RouteBoardsState) { reload() }
    val scope = rememberCoroutineScope()
    SrStateView(state.loading, state.error, state.boards.isEmpty(), s.t("drv.boards_empty"), { scope.launch { state.reload() } }) {
        LazyColumn(modifier.fillMaxSize()) {
            items(state.boards) { b ->
                ListRow("sr-drv-board-${b["id"].text()}", { onOpen(b["id"].long() ?: 0) }, title = b["title"].text(), subtitle = state.details(b))
                HorizontalDivider()
            }
        }
    }
}

/** The state of [RouteBoard] (UI-KIT-SPEC.md §Route boards). */
class RouteBoardState(env: SrEnv, val boardId: Long) : SrDriverState(env) {
    var board by mutableStateOf<Obj>(emptyMap())
        private set
    var seats by mutableStateOf<List<Obj>>(emptyList())
        private set
    val prices = mutableStateMapOf<Long, String>()
    val lowest = mutableStateMapOf<Long, Any?>()
    var busy by mutableStateOf(false)
        private set

    override suspend fun fetch() {
        val d = env.api.driverRouteBoard(boardId).dataOrSelf().obj()
        board = d["board"].obj()
        seats = d["seats"].objs()
    }

    val mode: String get() = (board["mode"] ?: "route").text()
    val open: Boolean get() = board["is_open"].isTrue()
    fun claimable(seat: Obj): Boolean = seat["claimable"].isTrue() && seat["blocked_reason"] == null && open
    fun price(seatId: Long): java.math.BigDecimal? = number(prices[seatId] ?: "")
    val canTakeSeat: Boolean get() = !busy && open && board["quota"].obj()["can_grab"] != false

    fun details(seat: Obj): String {
        val snap = seat["snapshot"].obj()
        return listOfNotNull(
            snap["work_from"]?.let { "${it.text()}–${snap["work_end"].text()}" },
            snap["stops"]?.let { env.t("drv.stops", "count" to it) },
            snap["distance"]?.let { env.t("lockers.distance", "km" to it) },
            snap["vehicle_type"].text(),
        ).filter { it.isNotEmpty() }.joinToString(" · ")
    }

    /** Sends a claim or a bid; shows the server's `message` and reloads. */
    private suspend fun send(seatId: Long? = null, call: suspend () -> JsonElement) {
        busy = true
        message = null
        env.attempt { call().plain().obj() }.onSuccess { answer ->
            val d = answer["data"].obj()
            if (seatId != null && d.containsKey("lowest")) lowest[seatId] = d["lowest"]
            (answer["message"] as? String)?.let { message = it }
            val keep = message
            reload()
            message = keep
        }.onFailure { message = env.failure(it) }
        busy = false
    }

    /** **Take a seat** on a seat-mode board (the pool). */
    suspend fun takeSeat() = send { env.api.driverBoardsIdClaimPost(boardId, body()) }

    suspend fun claim(seatId: Long) = send { env.api.driverBoardsIdClaimPost(boardId, body("seat_id" to seatId)) }

    /** **Bid** on a bid-mode board's seat, the price as typed (a decimal comma is read). */
    suspend fun bid(seatId: Long) {
        val p = price(seatId) ?: return
        send(seatId) { env.api.driverBoardsIdBidPost(boardId, body("seat_id" to seatId, "price" to p)) }
    }
}

/** One route board: claim a seat, take a pool seat or bid. */
@Composable
fun RouteBoard(boardId: Long, modifier: Modifier = Modifier, onError: ((SuperrouteException) -> Unit)? = null) {
    val s = superroute()
    val state = rememberLoaded(onError, boardId, create = { RouteBoardState(it, boardId) }) { reload() }
    val scope = rememberCoroutineScope()
    SrStateView(state.loading, state.error, state.board.isEmpty(), "", { scope.launch { state.reload() } }) {
        val board = state.board
        Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(s.space("m"))) {
            Text(board["title"].text(), style = s.figureStyle())
            SrMuted(listOfNotNull(board["date"].text(), if (!state.open) s.t("drv.board_closed") else null).filter { it.isNotEmpty() }.joinToString(" · "))
            SrNotice(state.message, "sr-drv-message")
            if (state.mode == "seat") {
                Spacer(Modifier.height(s.space("m")))
                SrPrimaryButton(s.t("drv.take_seat"), "sr-drv-take-seat", enabled = state.canTakeSeat) { scope.launch { state.takeSeat() } }
            }
            state.seats.forEach { seat ->
                val id = seat["seat_id"].long() ?: 0
                val snap = seat["snapshot"].obj()
                val claim = seat["my_claim"] as? Map<*, *>
                HorizontalDivider(Modifier.padding(vertical = s.space("s")))
                Column(Modifier.fillMaxWidth().testTag("sr-drv-seat-$id")) {
                    SrBody((snap["route_name"] ?: seat["route_id"]).text(), weight = FontWeight.SemiBold)
                    SrBody(state.details(seat))
                    if (claim != null) SrBody(s.t("drv.my_claim", "status" to s.env.claimStatus(claim["status"])), color = s.color("success"))
                    state.lowest[id]?.let { SrBody(s.t("drv.lowest", "price" to formatMoney(it, null))) }
                    when {
                        state.mode == "bid" -> Row(verticalAlignment = Alignment.CenterVertically) {
                            SrField(state.prices[id] ?: "", { state.prices[id] = it }, s.t("drv.price"), "sr-drv-price-$id", keyboard = KeyboardType.Decimal, modifier = Modifier.weight(1f))
                            Spacer(Modifier.width(s.space("s")))
                            SrPrimaryButton(s.t("drv.bid"), "sr-drv-bid-$id", enabled = !state.busy && state.claimable(seat) && state.price(id) != null, modifier = Modifier) {
                                scope.launch { state.bid(id) }
                            }
                        }
                        state.mode != "seat" -> SrPrimaryButton(s.t("drv.take"), "sr-drv-claim-$id", enabled = !state.busy && state.claimable(seat) && claim == null, modifier = Modifier) {
                            scope.launch { state.claim(id) }
                        }
                    }
                }
            }
        }
    }
}

/** The state of [BoardClaims] (UI-KIT-SPEC.md §Route boards). */
class BoardClaimsState(env: SrEnv) : SrDriverState(env) {
    var claims by mutableStateOf<List<Obj>>(emptyList())
        private set

    override suspend fun fetch() { claims = env.api.driverClaimsGet().dataOrSelf().objs() }

    fun details(c: Obj): String = listOf(
        c["route_name"].text(), c["date"].text(),
        if (c["work_from"] != null) "${c["work_from"].text()}–${c["work_end"].text()}" else "",
        env.claimStatus(c["status"]),
    ).filter { it.isNotEmpty() }.joinToString(" · ")

    /** **Withdraw** (after the driver confirmed); shows the server's `message` and reloads. */
    suspend fun withdraw(claimId: Long) {
        message = null
        env.attempt { env.api.driverClaimsIdWithdrawPost(claimId).plain().obj() }
            .onSuccess { answer ->
                reload()
                (answer["message"] as? String)?.let { message = it }
            }
            .onFailure { message = env.failure(it) }
    }
}

/** The driver's route board claims, with **Withdraw**. */
@Composable
fun BoardClaims(modifier: Modifier = Modifier, onError: ((SuperrouteException) -> Unit)? = null) {
    val s = superroute()
    val state = rememberLoaded(onError, create = ::BoardClaimsState) { reload() }
    val scope = rememberCoroutineScope()
    var ask by remember { mutableStateOf<SrAsk?>(null) }
    SrAskDialog(ask, scope) { ask = null }
    Column(modifier.fillMaxSize()) {
        SrNotice(state.message, "sr-drv-message")
        SrStateView(state.loading, state.error, state.claims.isEmpty(), s.t("drv.claims_empty"), { scope.launch { state.reload() } }) {
            LazyColumn(Modifier.fillMaxSize()) {
                items(state.claims) { c ->
                    val id = c["claim_id"].long() ?: 0
                    ListRow("sr-drv-claim-row-$id", title = c["board_title"].text(), subtitle = state.details(c), trailing = if (!c["can_withdraw"].isTrue()) null else ({
                        SrTextButton(s.t("drv.withdraw"), "sr-drv-withdraw-$id") {
                            ask = SrAsk(s.t("drv.withdraw_confirm"), s.t("drv.withdraw"), "sr-drv-confirm") { state.withdraw(id) }
                        }
                    }))
                    HorizontalDivider()
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------- earnings

/** The state of [DriverEarnings] (UI-KIT-SPEC.md §Earnings). */
class DriverEarningsState(env: SrEnv) : SrDriverState(env) {
    var period by mutableStateOf("today")
        private set
    var data by mutableStateOf<Obj>(emptyMap())
        private set
    var off by mutableStateOf(false)
        private set

    override suspend fun fetch() {
        off = false
        try {
            data = env.api.driverEarnings(period = period).dataOrSelf().obj()
        } catch (e: SuperrouteException) {
            if (e.status != 409) throw e
            off = true
        }
    }

    suspend fun choose(period: String) {
        this.period = period
        reload()
    }

    val currency: String? get() = data["currency"] as? String
    val tips: String get() = formatMoney(data["tips_driver_share"] ?: data["tips_total"] ?: 0, currency)
    val estimated: String get() = formatMoney(data["estimated_pay"] ?: 0, currency)
}

/** Delivered orders, tips and the estimated pay. */
@Composable
fun DriverEarnings(modifier: Modifier = Modifier, onError: ((SuperrouteException) -> Unit)? = null) {
    val s = superroute()
    val state = rememberLoaded(onError, create = ::DriverEarningsState) { reload() }
    val scope = rememberCoroutineScope()
    Column(modifier.fillMaxSize()) {
        DriverChips(listOf("today" to s.t("drv.today"), "yesterday" to s.t("drv.yesterday"), "week" to s.t("drv.week"), "month" to s.t("drv.month")), state.period, "sr-drv-period") {
            scope.launch { state.choose(it) }
        }
        if (state.off) {
            SrBody(s.t("drv.earnings_off"), Modifier.padding(s.space("l")).testTag("sr-drv-earnings-off"))
            return@Column
        }
        SrStateView(state.loading, state.error, state.data.isEmpty() && (state.loading || state.error != null), "", { scope.launch { state.reload() } }) {
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = s.space("m"))) {
                SrAmount(s.t("drv.delivered"), (state.data["delivered_orders"] ?: 0).text(), "sr-drv-delivered")
                SrAmount(s.t("drv.tips"), state.tips, "sr-drv-tips")
                HorizontalDivider()
                state.data["estimated_pay_items"].objs().forEach { item ->
                    SrAmount("${(item["name"] ?: item["type"]).text()} × ${item["quantity"].text()}", s.money(item["subtotal"], state.currency), "sr-drv-item-${item["type"].text()}")
                }
                SrAmount(s.t("drv.estimated_pay"), state.estimated, "sr-drv-estimated", strong = true)
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------- lookup

/** The state of [ScanLookup] (UI-KIT-SPEC.md §Scan lookup). */
class ScanLookupState(val env: SrEnv) {
    var ref by mutableStateOf("")
    var message by mutableStateOf<String?>(null)
        private set
    var busy by mutableStateOf(false)
        private set

    /** **Find**: answers the driver's own order, or shows `drv.not_found` on a 404. */
    suspend fun find(): Obj? {
        val value = ref.trim()
        if (value.isEmpty()) return null
        busy = true
        message = null
        val result = env.attempt { env.api.driverOrderByRef(value).dataOrSelf().obj() }
        result.onFailure { message = if (it is SuperrouteException && it.status == 404) env.t("drv.not_found") else env.failure(it) }
        busy = false
        return result.getOrNull()
    }

    suspend fun scan(scan: suspend () -> String?): Obj? {
        val value = scan()?.trim()
        if (value.isNullOrEmpty()) return null
        ref = value
        return find()
    }
}

/** Finds the driver's own order by reference, id or tracking number; **Scan** uses the app's [scan]. [onFound] gets the order. */
@Composable
fun ScanLookup(scan: (suspend () -> String?)? = null, onFound: (order: Obj) -> Unit = {}, modifier: Modifier = Modifier, onError: ((SuperrouteException) -> Unit)? = null) {
    val s = superroute()
    val state = rememberComponentEnv(onError).let { env -> remember(env) { ScanLookupState(env) } }
    val scope = rememberCoroutineScope()
    Column(modifier.fillMaxWidth().padding(s.space("m"))) {
        OutlinedTextField(
            value = state.ref, onValueChange = { state.ref = it }, label = { Text(s.t("drv.lookup")) }, singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions(onSearch = { scope.launch { state.find()?.let(onFound) } }),
            modifier = Modifier.fillMaxWidth().testTag("sr-drv-ref"),
        )
        Spacer(Modifier.height(s.space("s")))
        Row {
            SrPrimaryButton(s.t("drv.find"), "sr-drv-find", enabled = !state.busy, modifier = Modifier.weight(1f)) { scope.launch { state.find()?.let(onFound) } }
            if (scan != null) {
                Spacer(Modifier.width(s.space("s")))
                SrOutlinedButton(s.t("drv.scan"), "sr-drv-scan", enabled = !state.busy) { scope.launch { state.scan(scan)?.let(onFound) } }
            }
        }
        state.message?.let { SrDanger(it, Modifier.padding(top = s.space("s")).testTag("sr-drv-lookup-message")) }
    }
}
