package ca.superroute.sapp.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ca.superroute.sapp.SuperrouteException
import ca.superroute.sapp.Tokens
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject

// ---------------------------------------------------------------------------------------------------------- sign-in

/** Shows the Superroute sign-in page in an in-app browser session; answers the URL it returned to, or null when closed. */
typealias OpenBrowser = suspend (url: String, redirectUri: String) -> String?

/** The state of [SignIn] (UI-KIT-SPEC.md §Sign-in). */
class SignInState(val env: SrEnv) {
    var busy by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var email by mutableStateOf("")
    var password by mutableStateOf("")

    /** Whether the bootstrap's `authentication.methods.<name>` is on. */
    fun method(bootstrap: Obj, name: String): Boolean = bootstrap["authentication"].obj()["methods"].obj()[name].isTrue()

    /** Runs one sign-in; a cancelled one (null) is not an error and shows nothing. */
    suspend fun run(signIn: suspend () -> Tokens?): Tokens? {
        busy = true
        error = null
        val result = env.attempt { signIn() }
        result.onFailure { error = env.errorText(it, signingIn = true) }
        busy = false
        return result.getOrNull()
    }

    suspend fun withBrowser(redirectUri: String, openBrowser: OpenBrowser): Tokens? = run {
        val request = env.client.authorizationRequest(redirectUri)
        val returned = openBrowser(request.url, redirectUri)
        if (returned == null) null else env.client.completeSignIn(request, returned)
    }

    suspend fun withIdToken(get: suspend () -> String?): Tokens? = run { get()?.let { env.client.signInWithIdToken(it) } }

    suspend fun withPassword(): Tokens? = run { env.client.signInWithPassword(email.trim(), password) }
}

/**
 * Sign-in (UI-KIT-SPEC.md §Sign-in): the Superroute sign-in page always; Google and Apple when the bootstrap allows them
 * and the app hands in their ID tokens; email and password when the app allows it and the bootstrap does.
 */
@Composable
fun SignIn(
    bootstrap: JsonObject,
    redirectUri: String,
    openBrowser: OpenBrowser,
    getGoogleIdToken: (suspend () -> String?)? = null,
    getAppleIdToken: (suspend () -> String?)? = null,
    allowPassword: Boolean = false,
    onSignedIn: (Tokens) -> Unit = {},
    modifier: Modifier = Modifier,
    onError: ((SuperrouteException) -> Unit)? = null,
) {
    val s = superroute()
    val state = rememberComponentEnv(onError).let { env -> remember(env) { SignInState(env) } }
    val scope = rememberCoroutineScope()
    val boot = remember(bootstrap) { bootstrap.plain().obj() }
    fun go(block: suspend () -> Tokens?) = scope.launch { block()?.let(onSignedIn) }
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(s.space("m"))) {
        SrPrimaryButton(s.t("sign_in.page"), "sr-sign-in-page", enabled = !state.busy) { go { state.withBrowser(redirectUri, openBrowser) } }
        if (state.method(boot, "google") && getGoogleIdToken != null) {
            SrOutlinedButton(s.t("sign_in.google"), "sr-sign-in-google", enabled = !state.busy, modifier = Modifier.fillMaxWidth()) { go { state.withIdToken(getGoogleIdToken) } }
        }
        if (state.method(boot, "apple") && getAppleIdToken != null) {
            SrOutlinedButton(s.t("sign_in.apple"), "sr-sign-in-apple", enabled = !state.busy, modifier = Modifier.fillMaxWidth()) { go { state.withIdToken(getAppleIdToken) } }
        }
        if (allowPassword && state.method(boot, "email")) {
            Spacer(Modifier.height(s.space("xs")))
            SrField(state.email, { state.email = it }, s.t("sign_in.email"), "sr-sign-in-email", keyboard = KeyboardType.Email, enabled = !state.busy)
            SrField(state.password, { state.password = it }, s.t("sign_in.password"), "sr-sign-in-password", password = true, enabled = !state.busy)
            SrOutlinedButton(s.t("sign_in.with_email"), "sr-sign-in-with-email", enabled = !state.busy, modifier = Modifier.fillMaxWidth()) { go { state.withPassword() } }
        }
        state.error?.let { SrDanger(it, Modifier.testTag("sr-sign-in-error")) }
    }
}

// ---------------------------------------------------------------------------------------------------------- inbox

/** The state of [NotificationInbox] (UI-KIT-SPEC.md §Notification inbox). */
class NotificationInboxState(val env: SrEnv) {
    var filter by mutableStateOf("all")
        private set
    var unread by mutableStateOf(0)
        private set
    var list by mutableStateOf(newList())
        private set
    var message by mutableStateOf<String?>(null)
        private set

    private fun newList() = env.pagedList { page -> env.api.platformAppNotifications(filter = if (filter == "unread") "unread" else null, page = page, perPage = 20) }

    /** Reloads from the first page. */
    suspend fun refresh() {
        list = newList()
        list.reset()
        unread = list.data["unread_count"].long()?.toInt() ?: unread
    }

    suspend fun choose(filter: String) {
        this.filter = filter
        refresh()
    }

    /** Marks a row read at once (the count drops); a failure puts it back. */
    suspend fun open(item: Obj) {
        if (item["read"].isTrue()) return
        val id = item["id"]
        list.replace(id) { it + ("read" to true) }
        unread = (unread - 1).coerceAtLeast(0)
        env.attempt { env.api.platformAppMarkNotificationRead(id.text()) }.onFailure {
            list.replace(id) { it + ("read" to false) }
            unread++
        }
    }

    suspend fun markAll() {
        env.attempt { env.api.platformAppMarkAllNotificationsRead() }
            .onSuccess { refresh() }
            .onFailure { message = env.errorText(it) }
    }
}

/** The notification inbox. [onOpen] gets the notification (its `deep_link`, `entity_type`, `entity_id`). */
@Composable
fun NotificationInbox(onOpen: (Obj) -> Unit = {}, modifier: Modifier = Modifier, onError: ((SuperrouteException) -> Unit)? = null) {
    val s = superroute()
    val state = rememberLoaded(onError, create = ::NotificationInboxState) { refresh() }
    val scope = rememberCoroutineScope()
    val list = state.list
    Column(modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = s.space("l"), vertical = s.space("s")), verticalAlignment = Alignment.CenterVertically) {
            SingleChoiceSegmentedButtonRow {
                listOf("all" to s.t("inbox.all"), "unread" to if (state.unread > 0) "${s.t("inbox.unread")} (${state.unread})" else s.t("inbox.unread"))
                    .forEachIndexed { i, (key, label) ->
                        SegmentedButton(selected = state.filter == key, onClick = { scope.launch { state.choose(key) } },
                            shape = SegmentedButtonDefaults.itemShape(i, 2), modifier = Modifier.testTag("sr-inbox-filter-$key")) { Text(label) }
                    }
            }
            Spacer(Modifier.weight(1f))
            if (state.unread > 0) SrTextButton(s.t("inbox.mark_all_read"), "sr-inbox-mark-all") { scope.launch { state.markAll() } }
        }
        SrNotice(state.message, "sr-inbox-message", danger = true)
        SrStateView(list.loading, list.error, list.items.isEmpty(), s.t("inbox.empty"), { scope.launch { state.refresh() } }) {
            LazyColumn(Modifier.fillMaxSize()) {
                items(list.items, key = { it["id"].text() }) { item ->
                    val unread = !item["read"].isTrue()
                    Row(
                        Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { onOpen(item); scope.launch { state.open(item) } }
                            .padding(horizontal = s.space("l"), vertical = s.space("s")).testTag("sr-inbox-${item["id"].text()}"),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        val dot = s.t("inbox.unread_dot")
                        Box(Modifier.size(10.dp).let { if (unread) it.background(s.color("primary"), CircleShape).semantics { contentDescription = dot } else it })
                        Spacer(Modifier.width(s.space("m")))
                        Column(Modifier.weight(1f)) {
                            SrBody(item["title"].text(), weight = if (unread) FontWeight.SemiBold else FontWeight.Normal)
                            val sub = listOf(item["body"].text(), s.date(item["created_at"])).filter { it.isNotEmpty() }.joinToString("\n")
                            if (sub.isNotEmpty()) SrMuted(sub, small = true)
                        }
                    }
                    HorizontalDivider()
                }
                item { SrLoadMore(list) }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------- wallet

/** The state of [WalletSummary] (UI-KIT-SPEC.md §Wallet summary). */
class WalletSummaryState(val env: SrEnv) {
    var wallet by mutableStateOf<Obj?>(null)
        private set
    var error by mutableStateOf<Throwable?>(null)
        private set
    var loading by mutableStateOf(true)
        private set
    var transactions by mutableStateOf(newList())
        private set

    private fun newList() = env.pagedList { page -> env.api.platformAppWalletTransactions(page = page, perPage = 20) }

    suspend fun load() {
        transactions = newList()
        loading = true
        error = null
        env.attempt {
            wallet = env.api.platformAppWallet().data()
            transactions.reset()
        }.onFailure { error = it }
        loading = false
    }

    val currency: String? get() = wallet?.get("currency") as? String
    val showsCredit: Boolean get() = (wallet?.get("credit_limit").decimal()?.signum() ?: 0) > 0
    val canTopUp: Boolean get() = wallet?.get("online_payment").obj()["available"].isTrue()

    /** A transaction's signed amount: credit `+`, debit `−`. */
    fun signed(transaction: Obj): String {
        val credit = transaction["direction"] == "credit"
        val amount = (transaction["amount"] ?: "0").text().replaceFirst("-", "")
        return (if (credit) "+" else "−") + formatMoney(amount, currency)
    }
}

/** The wallet summary and its transactions. [onTopUp] gets the minimum, the maximum and the currency. */
@Composable
fun WalletSummary(onTopUp: (minimum: String?, maximum: String?, currency: String?) -> Unit = { _, _, _ -> }, modifier: Modifier = Modifier, onError: ((SuperrouteException) -> Unit)? = null) {
    val s = superroute()
    val state = rememberLoaded(onError, create = ::WalletSummaryState) { load() }
    val scope = rememberCoroutineScope()
    val w = state.wallet
    SrStateView(state.loading, state.error, w == null, "", { scope.launch { state.load() } }) {
        if (w == null) return@SrStateView
        val tx = state.transactions
        LazyColumn(modifier.fillMaxSize().padding(horizontal = s.space("l"))) {
            item {
                Spacer(Modifier.height(s.space("l")))
                Figure(s.t("wallet.balance"), w["balance"], state.currency, "sr-wallet-balance")
                if (state.showsCredit) Figure(s.t("wallet.credit_available"), w["credit_remaining"], state.currency, "sr-wallet-credit")
                Figure(s.t("wallet.available"), w["available_to_spend"], state.currency, "sr-wallet-available")
                if (state.canTopUp) {
                    Spacer(Modifier.height(s.space("m")))
                    val payment = w["online_payment"].obj()
                    SrPrimaryButton(s.t("wallet.top_up"), "sr-wallet-top-up") {
                        onTopUp(payment["minimum_top_up"]?.text(), payment["maximum_top_up"]?.text(), state.currency)
                    }
                }
                Spacer(Modifier.height(s.space("xl")))
                Text(s.t("wallet.transactions"), style = s.figureStyle())
                if (tx.items.isEmpty()) SrMuted(s.t("wallet.empty"), Modifier.padding(vertical = s.space("l")).testTag("sr-wallet-empty"))
            }
            items(tx.items) { t ->
                val credit = t["direction"] == "credit"
                Row(Modifier.fillMaxWidth().padding(vertical = s.space("s")), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        SrBody(t["category"].text())
                        if (t["created_at"] != null) SrMuted(s.date(t["created_at"]), small = true)
                    }
                    SrBody(state.signed(t), weight = FontWeight.SemiBold, color = if (credit) s.color("success") else s.color("onSurface"))
                }
            }
            item { SrLoadMore(tx) }
        }
    }
}

@Composable
private fun Figure(label: String, amount: Any?, currency: String?, tag: String) {
    val s = superroute()
    val negative = amount.text().startsWith("-")
    Row(Modifier.fillMaxWidth().padding(vertical = s.space("xs")), verticalAlignment = Alignment.CenterVertically) {
        SrMuted(label, Modifier.weight(1f))
        Text(formatMoney(amount, currency), modifier = Modifier.testTag(tag), style = s.figureStyle(if (negative) s.color("danger") else null))
    }
}

// ---------------------------------------------------------------------------------------------------------- orders

/** The state of [OrderList] (UI-KIT-SPEC.md §Order list). */
class OrderListState(val env: SrEnv) {
    var list by mutableStateOf(newList())
        private set

    private fun newList() = env.pagedList { page -> env.api.platformAppOrders(page = page, perPage = 20) }

    suspend fun reload() {
        list = newList()
        list.reset()
    }
}

/** The person's orders. [onOpen] gets the order type and id. */
@Composable
fun OrderList(onOpen: (type: String, id: Long) -> Unit = { _, _ -> }, modifier: Modifier = Modifier, onError: ((SuperrouteException) -> Unit)? = null) {
    val s = superroute()
    val state = rememberLoaded(onError, create = ::OrderListState) { reload() }
    val scope = rememberCoroutineScope()
    val list = state.list
    SrStateView(list.loading, list.error, list.items.isEmpty(), s.t("orders.empty"), { scope.launch { state.reload() } }) {
        LazyColumn(modifier.fillMaxSize()) {
            items(list.items) { o ->
                Row(
                    Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { onOpen(o["type"].text(), o["id"].long() ?: 0) }
                        .padding(horizontal = s.space("l"), vertical = s.space("s")).testTag("sr-order-${o["type"].text()}-${o["id"].text()}"),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        SrBody((o["reference"] ?: o["id"]).text())
                        SrMuted("${s.t("orders.type_${o["type"].text()}")} · ${o["status_label"].text()}", small = true)
                    }
                    if (o["total"] != null) SrBody(s.money(o["total"], o["currency"]))
                }
                HorizontalDivider()
            }
            item { SrLoadMore(list) }
        }
    }
}
