package ca.superroute.sapp.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ca.superroute.sapp.SuperrouteException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** The refusal's `messages` when given, else its `message` on a 422, else the error's string. */
internal fun SrEnv.messages(e: Throwable): List<String> {
    val b = (e as? SuperrouteException)?.let { errorBody(it) } ?: emptyMap()
    val list = b["messages"].list().map { it.text() }.filter { it.isNotEmpty() }
    if (list.isNotEmpty()) return list
    return listOf(if (e is SuperrouteException && e.status == 422 && b["message"] is String) b["message"] as String else errorText(e))
}

/** The server's `message` on a 4xx refusal (409, 422, …), else the error's string. */
internal fun SrEnv.refusalText(e: Throwable): String {
    val m = (e as? SuperrouteException)?.let { errorBody(it)["message"] as? String }
    return if (e is SuperrouteException && e.status in 400..499 && e.status != 401 && e.status != 403 && !m.isNullOrEmpty()) m else errorText(e)
}

// ---------------------------------------------------------------------------------------------------------- list

/** The state of [GroupBuyList] (UI-KIT-SPEC.md §Group buy list). */
class GroupBuyListState(val env: SrEnv) : SrOneAnswer(env, { error("unused") }) {
    var category by mutableStateOf<Long?>(null)
        private set

    override suspend fun reload() {
        loading = true
        error = null
        env.attempt { data = env.api.platformAppMallGroupBuys(category = category).data() }.onFailure { error = it }
        loading = false
    }

    suspend fun choose(category: Long?) {
        this.category = category
        reload()
    }

    val items: List<Obj> get() = data?.get("group_buys").objs()
    val categories: List<Obj> get() = data?.get("categories").objs().filter { it["parent_id"] == null }
}

/** The group buys open now. [onOpen] gets a campaign's code. */
@Composable
fun GroupBuyList(onOpen: (code: String) -> Unit = {}, modifier: Modifier = Modifier, onError: ((SuperrouteException) -> Unit)? = null) {
    val s = superroute()
    val state = rememberLoaded(onError, create = ::GroupBuyListState) { reload() }
    val scope = rememberCoroutineScope()
    Column(modifier.fillMaxSize()) {
        if (state.categories.isNotEmpty()) {
            val options = listOf<Pair<Long?, String>>(null to s.t("mall.all")) + state.categories.map { it["id"].long() to it["name"].text() }
            LazyRow(Modifier.fillMaxWidth().height(56.dp), horizontalArrangement = Arrangement.spacedBy(s.space("xs")),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = s.space("m"))) {
                items(options) { (id, name) ->
                    FilterChip(selected = state.category == id, onClick = { scope.launch { state.choose(id) } }, label = { Text(name) },
                        modifier = Modifier.heightIn(min = 44.dp).testTag("sr-gb-cat-${id ?: "all"}"))
                }
            }
        }
        SrStateView(state.loading, state.error, state.items.isEmpty(), s.t("gb.empty"), { scope.launch { state.reload() } }) {
            LazyColumn(Modifier.fillMaxSize()) {
                items(state.items) { g ->
                    Column(Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { onOpen(g["code"].text()) }
                        .padding(horizontal = s.space("l"), vertical = s.space("s")).testTag("sr-gb-${g["code"].text()}")) {
                        SrBody(g["title"].text())
                        SrMuted(listOf(g["store"].obj()["name"].text(), s.t("gb.cutoff", "date" to s.date(g["cutoff_at"]))).filter { it.isNotEmpty() }.joinToString("\n"), small = true)
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------- campaign

private val HOME_FIELDS = listOf("address_1", "address_2", "city", "province", "postcode")

/** The state of [GroupBuy] (UI-KIT-SPEC.md §Group buy). */
class GroupBuyState(val env: SrEnv, val code: String, val leader: String? = null) {
    var loading by mutableStateOf(true)
        private set
    var error by mutableStateOf<Throwable?>(null)
        private set
    var data by mutableStateOf<Obj>(emptyMap())
        private set
    val lines = mutableStateMapOf<String, Int>()
    var receive by mutableStateOf<String?>(null)
    val text = mutableStateMapOf<String, String>()
    var quote by mutableStateOf<Obj?>(null)
        private set
    val errors = mutableStateMapOf<String, String>()
    var messages by mutableStateOf<List<String>>(emptyList())
        private set
    var sending by mutableStateOf(false)
        private set

    fun v(f: String): String = text[f]?.trim() ?: ""

    val campaign: Obj get() = data["campaign"].obj()
    val currency: String? get() = data["currency"] as? String
    val orderable: Boolean get() = campaign["orderable"].isTrue()
    val items: List<Obj> get() = data["items"].objs()
    val pickups: List<Obj> get() = data["pickup"].objs()
    val offersHome: Boolean get() = data["home"].isTrue() && campaign["allow_home_delivery"] != false
    val hasLines: Boolean get() = lines.values.any { it > 0 }

    /** The ways to receive the order: each pickup's key, and `home`. */
    val choices: List<String> get() = pickups.map { it["key"].text() } + if (offersHome) listOf("home") else emptyList()

    suspend fun reload() {
        loading = true
        error = null
        env.attempt {
            data = env.api.platformAppGroupBuy(code, leader = leader).data()
            lines.clear()
            quote = null
            receive = choices.singleOrNull()
        }.onFailure { error = it }
        loading = false
    }

    fun qty(item: Obj): Int = lines[item["id"].text()] ?: 0
    fun change(item: Obj, by: Int) { lines[item["id"].text()] = (qty(item) + by).coerceAtLeast(0) }

    fun body(): Obj = buildMap {
        put("lines", lines.filterValues { it > 0 }.toMap())
        receive?.let { put("receive", it) }
        leader?.let { put("leader", it) }
        if (receive == "home") put("address", (HOME_FIELDS + "delivery_instruction").filter { v(it).isNotEmpty() }.associateWith { v(it) })
    }

    /** What the quote depends on: the lines, the choice and the postcode; null while no line has a quantity. */
    val quoteInputs: List<Any?>? get() = if (!hasLines) null else listOf(lines.filterValues { it > 0 }.toMap(), receive, if (receive == "home") v("postcode") else null)

    suspend fun askQuote() {
        if (!hasLines) {
            quote = null
            return
        }
        // The quote only informs; the order call decides and answers its own errors.
        attempt { env.api.platformAppGroupBuyQuote(code, body = body().json()).data() }.onSuccess { quote = it }
    }

    val quoteMessages: List<String> get() = quote?.get("messages").list().map { it.text() }
    val canOrder: Boolean get() = !sending && hasLines && quote?.get("ok") != false

    /** Places the order; answers the payment (a manual-capture hold) and the order for the app's card sheet. */
    suspend fun order(): Pair<Obj, Obj>? {
        errors.clear()
        messages = emptyList()
        if (receive == null) errors["receive"] = env.t("rform.required")
        if (receive == "home") HOME_FIELDS.filter { it != "address_2" && v(it).isEmpty() }.forEach { errors[it] = env.t("rform.required") }
        if (errors.isNotEmpty()) return null
        sending = true
        val result = env.attempt {
            val request = body() + (if (v("note").isNotEmpty()) mapOf("note" to v("note")) else emptyMap())
            val d = env.api.platformAppGroupBuyPlaceOrder(code, body = request.json()).data()
            d["payment"].obj() to d["order"].obj()
        }
        result.onFailure { messages = env.messages(it) }
        sending = false
        return result.getOrNull()
    }
}

/** One campaign: items, how the order is received, the quote and the order with its card hold ([onPayment] for the app's card sheet). */
@Composable
fun GroupBuy(code: String, leader: String? = null, onPayment: (payment: Obj, order: Obj) -> Unit = { _, _ -> }, modifier: Modifier = Modifier, onError: ((SuperrouteException) -> Unit)? = null) {
    val s = superroute()
    val state = rememberLoaded(onError, code, leader, create = { GroupBuyState(it, code, leader) }) { reload() }
    val scope = rememberCoroutineScope()
    val inputs = state.quoteInputs
    LaunchedEffect(state, inputs) {
        if (inputs != null) delay(400)
        state.askQuote()
    }
    SrFormFrame(state.loading, state.error, { scope.launch { state.reload() } }) {
        val campaign = state.campaign
        val currency = state.currency
        Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(s.space("m"))) {
            Text(campaign["title"].text(), fontSize = s.size("headline"), fontWeight = FontWeight.SemiBold, color = s.color("onSurface"))
            if (campaign["description"].text().isNotEmpty()) SrBody(campaign["description"].text(), Modifier.padding(top = s.space("s")))
            SrMuted(s.t("gb.cutoff", "date" to s.date(campaign["cutoff_at"])))
            if (campaign["expected_delivery_at"] != null) SrMuted(s.t("gb.delivery_expected", "date" to s.date(campaign["expected_delivery_at"])))
            if (!state.orderable) SrDanger(s.t("gb.closed"), Modifier.padding(top = s.space("s")).testTag("sr-gb-closed"))
            SrTitle(s.t("gb.items"))
            state.items.forEach { item ->
                val id = item["id"].text()
                Row(Modifier.fillMaxWidth().padding(vertical = s.space("xs")).testTag("sr-gb-item-$id"), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        SrBody(item["name"].text(), weight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(s.space("xs"))) {
                            SrBody(s.money(item["group_price"], currency))
                            if (centsOf(item["regular_price"]) > centsOf(item["group_price"])) SrBody(s.money(item["regular_price"], currency), color = s.color("muted"), strike = true)
                        }
                    }
                    Stepper(state.qty(item), "sr-gb-qty-$id", minusEnabled = state.orderable && state.qty(item) > 0, plusEnabled = state.orderable,
                        onMinus = { state.change(item, -1) }, onPlus = { state.change(item, 1) })
                }
            }
            if (!state.orderable) return@Column
            SrTitle(s.t("gb.receive"))
            @Composable fun choice(key: String, title: String, subtitle: String) {
                Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { state.receive = key }.testTag("sr-gb-receive-$key"), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = state.receive == key, onClick = { state.receive = key })
                    Column(Modifier.weight(1f)) {
                        SrBody(title)
                        if (subtitle.isNotEmpty()) SrMuted(subtitle, small = true)
                    }
                }
            }
            state.pickups.forEach { p ->
                choice(p["key"].text(), listOfNotNull(p["name"].text(), if (p["leader"].isTrue()) s.t("gb.leader") else null).joinToString(" · "),
                    listOf(p["address"].text(), p["notes"].text()).filter { it.isNotEmpty() }.joinToString("\n"))
            }
            if (state.offersHome) choice("home", s.t("gb.home"), "")
            state.errors["receive"]?.let { SrDanger(it) }
            if (state.receive == "home") {
                (HOME_FIELDS + "delivery_instruction").forEach { f ->
                    SrField(state.text[f] ?: "", { state.text[f] = it }, if (f == "delivery_instruction") s.t("checkout.instruction") else s.t("rform.$f"), "sr-gb-$f",
                        required = f != "address_2" && f != "delivery_instruction", error = state.errors[f])
                }
            }
            SrField(state.text["note"] ?: "", { state.text["note"] = it }, s.t("sform.note"), "sr-gb-note", multiline = true)
            state.quote?.let { q ->
                val c = q["currency"] ?: currency
                Spacer(Modifier.height(s.space("m")))
                SrAmount(s.t("cart.subtotal"), s.money(q["subtotal"], c), "sr-gb-subtotal")
                if (centsOf(q["delivery_fee"]) != 0L) SrAmount(s.t("checkout.delivery_fee"), s.money(q["delivery_fee"], c), "sr-gb-delivery-fee")
                SrAmount(s.t("sform.tax"), s.money(q["tax"] ?: 0, c), "sr-gb-tax")
                SrAmount(s.t("rform.total"), s.money(q["total"], c), "sr-gb-total", strong = true)
                state.quoteMessages.forEach { SrDanger(it, Modifier.testTag("sr-gb-quote-message")) }
            }
            state.messages.forEach { SrDanger(it, Modifier.testTag("sr-gb-message")) }
            Spacer(Modifier.height(s.space("m")))
            SrMuted(s.t("gb.hold_note"), small = true)
            Spacer(Modifier.height(s.space("s")))
            SrPrimaryButton(s.t("gb.place"), "sr-gb-order", enabled = state.canOrder) {
                scope.launch { state.order()?.let { (payment, order) -> onPayment(payment, order) } }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------- orders

/** The state of [GroupBuyOrders] (UI-KIT-SPEC.md §Group buy orders). */
class GroupBuyOrdersState(val env: SrEnv) {
    var list by mutableStateOf(newList())
        private set

    private fun newList() = env.pagedList { page -> env.api.platformAppGroupBuyOrders(page = page, perPage = 20) }

    suspend fun reload() {
        list = newList()
        list.reset()
    }

    fun details(o: Obj): String = listOf(
        env.t("gb.order_number", "number" to o["number"]),
        o["hold_label"].text(),
        (o["place"] as? Map<*, *>)?.get("name")?.text() ?: if (o["delivery"] == "home") env.t("gb.home") else "",
    ).filter { it.isNotEmpty() }.joinToString(" · ")
}

/** The buyer's group buy orders. [onOpen] gets an order's token. */
@Composable
fun GroupBuyOrders(onOpen: (token: String) -> Unit = {}, modifier: Modifier = Modifier, onError: ((SuperrouteException) -> Unit)? = null) {
    val s = superroute()
    val state = rememberLoaded(onError, create = ::GroupBuyOrdersState) { reload() }
    val scope = rememberCoroutineScope()
    val list = state.list
    SrStateView(list.loading, list.error, list.items.isEmpty(), s.t("gb.orders_empty"), { scope.launch { state.reload() } }) {
        LazyColumn(modifier.fillMaxSize()) {
            items(list.items) { o ->
                Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { onOpen(o["token"].text()) }
                    .padding(horizontal = s.space("l"), vertical = s.space("s")).testTag("sr-gb-order-${o["token"].text()}"), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        SrBody(o["campaign"].obj()["title"].text())
                        SrMuted(state.details(o), small = true)
                    }
                    SrBody(s.money(o["total"], o["currency"]))
                }
                HorizontalDivider()
            }
            item { SrLoadMore(list) }
        }
    }
}

/** The state of [GroupBuyOrder] (UI-KIT-SPEC.md §Group buy order). */
class GroupBuyOrderState(val env: SrEnv, val token: String) {
    var loading by mutableStateOf(true)
        private set
    var error by mutableStateOf<Throwable?>(null)
        private set
    var order by mutableStateOf<Obj>(emptyMap())
        private set
    var busy by mutableStateOf(false)
        private set
    var message by mutableStateOf<String?>(null)
        private set

    suspend fun reload() {
        loading = true
        error = null
        env.attempt { order = env.api.platformAppGroupBuyOrder(token).data()["order"].obj() }.onFailure { error = it }
        loading = false
    }

    /** **I have received it**: shows `gb.received_done` and the order the call answers. */
    suspend fun received() {
        busy = true
        message = null
        env.attempt { env.api.platformAppGroupBuyOrderReceived(token).data()["order"].obj() }
            .onSuccess {
                if (it.isNotEmpty()) order = it
                message = env.t("gb.received_done")
            }
            .onFailure { message = env.refusalText(it) }
        busy = false
    }
}

/** One group buy order. **Complete the card hold** raises [onPay] (the app calls the pay operation and presents the sheet). */
@Composable
fun GroupBuyOrder(token: String, onPay: (token: String) -> Unit = {}, modifier: Modifier = Modifier, onError: ((SuperrouteException) -> Unit)? = null) {
    val s = superroute()
    val state = rememberLoaded(onError, token, create = { GroupBuyOrderState(it, token) }) { reload() }
    val scope = rememberCoroutineScope()
    SrFormFrame(state.loading, state.error, { scope.launch { state.reload() } }) {
        val o = state.order
        val currency = o["currency"]
        val place = o["place"] as? Map<*, *>
        val address = o["address"].obj()
        val locker = o["locker"] as? Map<*, *>
        Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(s.space("m"))) {
            SrNotice(state.message, "sr-gb-order-message")
            Text(o["campaign"].obj()["title"].text(), fontSize = s.size("headline"), fontWeight = FontWeight.SemiBold, color = s.color("onSurface"))
            SrMuted(s.t("gb.order_number", "number" to o["number"]))
            Spacer(Modifier.height(s.space("s")))
            SrBody(o["hold_label"].text(), Modifier.testTag("sr-gb-hold"), weight = FontWeight.SemiBold)
            if (o["hold_message"].text().isNotEmpty()) SrBody(o["hold_message"].text())
            SrTitle(if (place != null) s.t("gb.pickup") else s.t("gb.home"))
            if (place != null) {
                SrBody(listOf(place["name"].text(), place["address"].text(), place["notes"].text()).filter { it.isNotEmpty() }.joinToString("\n"))
            } else {
                val city = listOf(address["city"].text(), address["province"].text(), address["postcode"].text()).filter { it.isNotEmpty() }.joinToString(", ")
                SrBody(listOf(address["address_1"].text(), address["address_2"].text(), city).filter { it.isNotEmpty() }.joinToString("\n"))
            }
            if (locker != null) {
                SrTitle(s.t("gb.pickup_code"))
                Text(locker["pickup_code"].text(), modifier = Modifier.testTag("sr-gb-pickup-code"), fontSize = (s.theme.type["headline"] ?: 26.0).plus(6).sp,
                    fontWeight = FontWeight.Bold, letterSpacing = 4.sp, color = s.color("onSurface"))
                SrBody(listOf(locker["location"].text(), locker["compartment"].text()).filter { it.isNotEmpty() }.joinToString(" · "))
            }
            SrTitle(s.t("gb.items"))
            o["lines"].objs().forEach { l ->
                Row(Modifier.fillMaxWidth().padding(vertical = s.space("xs") / 2)) {
                    SrBody("${l["name"].text()} × ${l["qty"].text()}", Modifier.weight(1f))
                    SrBody(s.money(l["total"], currency))
                }
            }
            HorizontalDivider()
            SrAmount(s.t("cart.subtotal"), s.money(o["subtotal"], currency), "sr-gb-order-subtotal")
            if (centsOf(o["delivery_fee"]) != 0L) SrAmount(s.t("checkout.delivery_fee"), s.money(o["delivery_fee"], currency), "sr-gb-order-delivery-fee")
            SrAmount(s.t("sform.tax"), s.money(o["tax"] ?: 0, currency), "sr-gb-order-tax")
            SrAmount(s.t("rform.total"), s.money(o["total"], currency), "sr-gb-order-total", strong = true)
            Spacer(Modifier.height(s.space("l")))
            if (o["can_confirm_received"].isTrue()) SrPrimaryButton(s.t("gb.received"), "sr-gb-received", enabled = !state.busy) { scope.launch { state.received() } }
            if (o["actions"].obj()["can_pay"].isTrue()) {
                Spacer(Modifier.height(s.space("s")))
                SrOutlinedButton(s.t("gb.pay"), "sr-gb-pay", modifier = Modifier.fillMaxWidth()) { onPay(token) }
            }
        }
    }
}
