package ca.superroute.sapp.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.RadioButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import ca.superroute.sapp.SuperrouteException
import kotlinx.coroutines.launch
import java.util.Base64
import java.util.Locale

// UI-KIT-SPEC.md §Components (P3g): the guest quote and the guest shipping order. Every call is a guest operation on the
// app key, so nobody needs to be signed in. The flows are the sWidget `quote` and `order` (guest mode) widgets' own.

/** ISO country codes with their names in the kit's language (`Canada (CA)`), sorted by name. */
fun countryOptions(language: String): List<Pair<String, String>> {
    val locale = SrStrings(language).javaLocale
    return Locale.getISOCountries().map { code ->
        val name = Locale.Builder().setRegion(code).build().getDisplayCountry(locale)
        code to if (name.isBlank() || name == code) code else "$name ($code)"
    }.sortedBy { it.second }
}

/** The message of a failed guest call: the server's first field error, its `message` for a 4xx (not 401 / 403 / 429), else the code's string. */
internal fun guestFailure(env: SrEnv, error: Throwable): String {
    if (error is SuperrouteException) {
        val body = env.errorBody(error)
        body["errors"].obj().values.firstNotNullOfOrNull { v -> (if (v is List<*>) v.firstOrNull() else v)?.text()?.ifEmpty { null } }?.let { return it }
        val message = body["message"]
        if (message is String && message.isNotEmpty() && error.status in 400..499 && error.status !in setOf(401, 403, 429)) return message
    }
    return env.errorText(error)
}

private val QUOTE_LINES = listOf("delivery", "pickup", "p2p", "shipping", "express")

/** The state of [GuestQuote] (UI-KIT-SPEC.md §Guest quote). */
class GuestQuoteState(val env: SrEnv, val lines: List<String>? = null, val country: String? = null) {
    var loading by mutableStateOf(true)
        private set
    var loadError by mutableStateOf<Throwable?>(null)
        private set
    var schema by mutableStateOf<Obj?>(null)
        private set
    var lineKeys by mutableStateOf<List<String>>(emptyList())
        private set
    var line by mutableStateOf<String?>(null)
        private set

    /** The chosen origin's id, `custom` for another postcode, or null when the line has no origins. */
    var originId by mutableStateOf<String?>(null)
    var weightUnit by mutableStateOf(2)
    var dimensionUnit by mutableStateOf(2)
    val packages = mutableStateListOf(SrPackageInput())
    val text = mutableStateMapOf<String, String>()
    val errors = mutableStateMapOf<String, String>()

    var quote by mutableStateOf<Obj?>(null)
        private set
    var message by mutableStateOf<String?>(null)
        private set
    var failed by mutableStateOf(false)
        private set
    var busy by mutableStateOf(false)
        private set

    fun v(field: String): String = text[field]?.trim() ?: ""
    fun set(field: String, value: String) { text[field] = value }

    val currentLine: Obj get() = schema?.get("lines").obj()[line ?: ""].obj()
    val origins: List<Obj> get() = currentLine["origins"].objs()
    val customOrigin: Boolean get() = currentLine["custom_origin"].isTrue()
    val services: List<Obj> get() = currentLine["services"].objs()
    val maxPackages: Int get() = currentLine["max_package_count"].long()?.toInt()?.coerceAtLeast(1) ?: 1

    /** Whether the From postcode field shows: no origins, or Another postcode chosen. */
    val asksFromPostcode: Boolean get() = origins.isEmpty() || originId == "custom"

    fun units(kind: String): List<Pair<Int, String>> = schema?.get("units").obj()[kind].obj()["options"].obj().entries
        .mapNotNull { (k, v) -> k.toIntOrNull()?.let { it to unitSymbol(v) } }

    suspend fun load() {
        loading = true
        loadError = null
        env.attempt { env.api.partnerAppGuestQuoteSchema(locale = env.language).root()["schema"].obj() }
            .onSuccess { s ->
                schema = s
                val allowed = (lines ?: QUOTE_LINES).filter { it in QUOTE_LINES }
                val offered = s["lines"].obj().keys
                lineKeys = allowed.filter { it in offered }
                chooseLine(line?.takeIf { it in lineKeys } ?: lineKeys.firstOrNull())
                val units = s["units"].obj()
                weightUnit = units["weight"].obj()["default"].long()?.toInt() ?: 2
                dimensionUnit = units["dimension"].obj()["default"].long()?.toInt() ?: 2
                if (v("to_country").isEmpty()) text["to_country"] = country ?: s["country"].text().ifEmpty { "CA" }
            }
            .onFailure { loadError = it }
        loading = false
    }

    /** Chooses a line; the price is cleared and the origin set to the line's first. */
    fun chooseLine(key: String?) {
        line = key
        quote = null
        message = null
        failed = false
        originId = origins.firstOrNull()?.get("id")?.text() ?: if (origins.isEmpty()) null else "custom"
        text["shipping_service_id"] = services.firstOrNull()?.get("id").text()
        while (packages.size > maxPackages) packages.removeAt(packages.lastIndex)
    }

    fun addPackage() { if (packages.size < maxPackages) packages.add(SrPackageInput()) }
    fun removePackage(i: Int) { if (packages.size > 1) packages.removeAt(i) }

    fun validate(): Boolean {
        errors.clear()
        fun need(field: String) { if (v(field).isEmpty()) errors[field] = env.t("rform.required") }
        need("to_postcode")
        if (line == "p2p" && asksFromPostcode) need("from_postcode")
        if (line == "express") need("to_address_1")
        return errors.isEmpty()
    }

    fun body(): Obj = buildMap {
        put("to_postcode", v("to_postcode"))
        if (v("to_country").isNotEmpty()) put("to_country", v("to_country"))
        put("weight_unit", weightUnit)
        put("dimension_unit", dimensionUnit)
        put("packages", packages.map { p ->
            mapOf("weight" to number(p.weight), "length" to number(p.length), "width" to number(p.width), "height" to number(p.height),
                "qty" to (number(p.quantity)?.toInt()?.takeIf { it > 0 } ?: 1))
        })
        val origin = originId
        if (origin != null && origin != "custom") put("origin_id", origin.toLongOrNull() ?: origin)
        else if (v("from_postcode").isNotEmpty()) put("from_postcode", v("from_postcode"))
        if (line == "shipping") put("shipping_service_id", v("shipping_service_id").toLongOrNull())
        if (line == "express" || v("to_address_1").isNotEmpty()) put("to_address_1", v("to_address_1"))
    }

    /** Asks the price; answers the quote (for `onQuoted`), or null (not covered, refused or failed). */
    suspend fun ask(): Obj? {
        val key = line ?: return null
        if (busy || !validate()) return null
        busy = true
        message = null
        failed = false
        quote = null
        val result = attempt { env.api.partnerAppGuestQuote(key, body = body().json()).root() }
        result.onSuccess { answer ->
            val q = answer["quote"].obj()
            if (answer["result"].isTrue() && q["covered"] != false) quote = q else message = env.t("quote.not_covered")
        }.onFailure {
            // The core raises `{"result": false}` as a failure even on a 200: that is the line not covering the shipment.
            if (it is SuperrouteException && it.status in 200..299) {
                message = env.t("quote.not_covered")
            } else {
                env.report(it)
                message = guestFailure(env, it)
                failed = true
            }
        }
        busy = false
        return quote
    }
}

/** A quote on the service provider's public quote lines, without signing in. Raises [onQuoted] with the quote. */
@Composable
fun GuestQuote(lines: List<String>? = null, country: String? = null, onQuoted: (Obj) -> Unit = {}, modifier: Modifier = Modifier, onError: ((SuperrouteException) -> Unit)? = null) {
    val s = superroute()
    val state = rememberLoaded(onError, lines, country, create = { GuestQuoteState(it, lines, country) }) { load() }
    val scope = rememberCoroutineScope()
    SrFormFrame(state.loading && state.schema == null, if (state.schema == null) state.loadError else null, { scope.launch { state.load() } }) {
        if (state.lineKeys.isEmpty()) {
            SrMuted(s.t("quote.none"), Modifier.padding(s.space("l")).testTag("sr-gquote-none"))
            return@SrFormFrame
        }
        val e = state.errors
        @Composable fun field(name: String, label: String, required: Boolean = false, numeric: Boolean = false, m: Modifier = Modifier.fillMaxWidth()) =
            SrField(state.text[name] ?: "", { state.set(name, it) }, label, "sr-gquote-$name", required = required, error = e[name],
                keyboard = if (numeric) KeyboardType.Decimal else KeyboardType.Text, modifier = m)
        Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(s.space("m"))) {
            SrMuted(s.t("common.required_note"), Modifier.padding(bottom = s.space("s")))
            if (state.lineKeys.size > 1) {
                SrChoice(s.t("quote.line"), "sr-gquote-line", state.lineKeys.map { it to s.t("quote.line_$it") }, state.line, { state.chooseLine(it) })
            }
            val origins = state.origins
            if (origins.isNotEmpty()) {
                val choices = origins.map { it["id"].text() to listOf(it["name"].text(), it["postcode"].text()).filter(String::isNotEmpty).joinToString(" · ") } +
                    (if (state.customOrigin) listOf("custom" to s.t("quote.custom_origin")) else emptyList())
                SrChoice(s.t("quote.origin"), "sr-gquote-origin", choices, state.originId, { state.originId = it })
            }
            if (state.asksFromPostcode) field("from_postcode", s.t("quote.from_postcode"), required = state.line == "p2p")
            if (state.line == "shipping") {
                SrChoice(s.t("sform.service"), "sr-gquote-service", state.services.map { it["id"].text() to it["name"].text() },
                    state.v("shipping_service_id"), { state.set("shipping_service_id", it) })
            }
            if (state.line == "express") field("to_address_1", s.t("quote.to_address"), required = true)
            field("to_postcode", s.t("quote.to_postcode"), required = true)
            SrChoice(s.t("quote.to_country"), "sr-gquote-to_country", countryOptions(s.env.language), state.v("to_country"), { state.set("to_country", it) })
            val weightUnits = state.units("weight").ifEmpty { listOf(2 to "kg") }
            val dimensionUnits = state.units("dimension").ifEmpty { listOf(2 to "cm") }
            Row {
                SrChoice(s.t("sform.weight_unit"), "sr-gquote-weight_unit", weightUnits, state.weightUnit, { state.weightUnit = it }, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(s.space("s")))
                SrChoice(s.t("sform.dimension_unit"), "sr-gquote-dimension_unit", dimensionUnits, state.dimensionUnit, { state.dimensionUnit = it }, modifier = Modifier.weight(1f))
            }
            state.packages.forEachIndexed { i, p ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SrBody(s.t("sform.package", "n" to i + 1), Modifier.weight(1f), weight = FontWeight.SemiBold)
                    if (state.packages.size > 1) SrTextButton(s.t("sform.remove_package"), "sr-gquote-remove-$i") { state.removePackage(i) }
                }
                Row {
                    listOf("weight", "length", "width", "height", "quantity").forEachIndexed { k, n ->
                        if (k > 0) Spacer(Modifier.width(s.space("xs")))
                        SrField(p[n], { p[n] = it }, s.t(if (n == "quantity") "sform.quantity" else "sform.$n"), "sr-gquote-package.$i.$n",
                            keyboard = KeyboardType.Decimal, modifier = Modifier.weight(1f))
                    }
                }
            }
            if (state.packages.size < state.maxPackages) SrTextButton(s.t("sform.add_package"), "sr-gquote-add") { state.addPackage() }
            SrPrimaryButton(s.t("quote.get"), "sr-gquote-get", enabled = !state.busy) { scope.launch { state.ask()?.let(onQuoted) } }
            SrNotice(state.message, "sr-gquote-message", danger = state.failed)
            state.quote?.let { q ->
                val currency = q["currency"]
                Column(Modifier.fillMaxWidth().padding(top = s.space("m")).testTag("sr-gquote-result")) {
                    SrAmount(s.t("quote.pre_tax"), s.money(q["pre_tax"], currency), "sr-gquote-pre_tax")
                    SrAmount(s.t("quote.tax"), s.money(q["tax"], currency), "sr-gquote-tax")
                    SrAmount(s.t("quote.total"), s.money(q["total"], currency), "sr-gquote-total", strong = true)
                    if (q["valid_until"] != null) SrMuted(s.t("quote.valid_until", "date" to s.date(q["valid_until"])))
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------- guest order

internal val GUEST_SIDE_FIELDS = listOf(
    "name" to "rform.name", "telephone" to "rform.phone", "email" to "rform.email", "address" to "rform.address_1",
    "address_2" to "rform.address_2", "city" to "rform.city", "province" to "rform.province", "postcode" to "rform.postcode",
    "country" to "rform.country",
)
internal val GUEST_OPTIONAL = setOf("email", "address_2", "province")

/** A file the component hands to the app (the label). */
class SrGuestFile(val filename: String, val mimeType: String, val bytes: ByteArray)

/** The state of [GuestShippingOrder] (UI-KIT-SPEC.md §Guest shipping order). */
class GuestShippingOrderState(
    val env: SrEnv,
    val verificationChannel: String = "email",
    val country: String? = null,
    val guestOrderId: Long? = null,
    initialOrderToken: String? = null,
    private val now: () -> Long = System::currentTimeMillis,
) {
    /** `form`, `order` or `list`. */
    var view by mutableStateOf("form")
        private set
    val text = mutableStateMapOf<String, String>()
    val errors = mutableStateMapOf<String, String>()
    var weightUnit by mutableStateOf(2)
    var dimensionUnit by mutableStateOf(2)
    val packages = mutableStateListOf(SrPackageInput())

    var rates by mutableStateOf<List<Obj>?>(null)
        private set
    var rateId by mutableStateOf<String?>(null)
    var challenge by mutableStateOf<String?>(null)
        private set

    /** The confirmed contact: its token, the masked contact and when it runs out (epoch ms). */
    var contactToken by mutableStateOf<String?>(null)
        private set
    var contact by mutableStateOf<String?>(null)
        private set
    private var contactUntil = 0L

    var order by mutableStateOf<Obj?>(null)
        private set
    var orderToken by mutableStateOf(initialOrderToken)
        private set
    var orders by mutableStateOf<List<Obj>?>(null)
        private set
    var confirming by mutableStateOf(false)
        private set
    var message by mutableStateOf<String?>(null)
        private set
    var failed by mutableStateOf(false)
        private set
    var busy by mutableStateOf(false)
        private set

    val phone: Boolean get() = verificationChannel == "phone"
    val verified: Boolean get() = contactToken != null && contactUntil > now()

    fun v(field: String): String = text[field]?.trim() ?: ""
    fun set(field: String, value: String) { text[field] = value }

    /** Changes a package's measure; the prices are cleared. */
    fun editPackage(i: Int, name: String, value: String) { packages[i][name] = value; rates = null }
    fun addPackage() { if (packages.size < 20) { packages.add(SrPackageInput()); rates = null } }
    fun removePackage(i: Int) { if (packages.size > 1) { packages.removeAt(i); rates = null } }

    fun statusText(status: Any?): String {
        val key = "guest.status_${status.text()}"
        return if (env.strings.has(key)) env.t(key) else status.text()
    }

    suspend fun load() {
        for (side in listOf("from", "to")) if (v("${side}_country").isEmpty()) text["${side}_country"] = country ?: "CA"
        val id = guestOrderId ?: return
        view = "order"
        run { order = fetch(id) }
    }

    private suspend fun run(block: suspend () -> Unit): Boolean {
        if (busy) return false
        busy = true
        message = null
        failed = false
        val result = env.attempt { block() }
        result.onFailure { message = guestFailure(env, it); failed = true }
        busy = false
        return result.isSuccess
    }

    private fun tokens(): Pair<String?, String?> = if (orderToken != null) orderToken to null else null to contactToken

    private suspend fun fetch(id: Long): Obj {
        val (o, c) = tokens()
        return env.api.platformAppGuestShipment(id, locale = env.language, guestOrderToken = o, guestContactToken = c).root()["guest_order"].obj()
    }

    fun shipment(): Obj {
        val body = linkedMapOf<String, Any?>()
        for (side in listOf("from", "to")) {
            for ((f, _) in GUEST_SIDE_FIELDS) {
                val value = v("${side}_$f").ifEmpty { if (f == "country") country ?: "CA" else "" }
                if (value.isNotEmpty()) body["${side}_$f"] = value
            }
        }
        body["packages"] = packages.map { p ->
            mapOf("weight" to number(p.weight), "length" to number(p.length), "width" to number(p.width), "height" to number(p.height),
                "weight_unit" to weightUnit, "dimension_unit" to dimensionUnit)
        }
        return body
    }

    fun validate(): Boolean {
        errors.clear()
        for (side in listOf("from", "to")) for ((f, _) in GUEST_SIDE_FIELDS) {
            if (f !in GUEST_OPTIONAL && f != "country" && v("${side}_$f").isEmpty()) errors["${side}_$f"] = env.t("rform.required")
        }
        packages.forEachIndexed { i, p -> if ((number(p.weight)?.signum() ?: 0) <= 0) errors["package.$i.weight"] = env.t("rform.required") }
        return errors.isEmpty()
    }

    suspend fun getRates() {
        if (busy || !validate()) return
        run {
            val answer = env.api.platformAppGuestShipmentRate(body = (shipment() + ("locale" to env.language)).json()).root()
            val list = answer["rates"].objs()
            rates = list
            rateId = list.firstOrNull()?.get("rate_id")?.text()
            if (list.isEmpty()) message = env.t("guest.no_rates")
        }
    }

    suspend fun sendCode() {
        if (v("contact").isEmpty()) { errors["contact"] = env.t("rform.required"); return }
        errors.remove("contact")
        run {
            val answer = env.api.platformAppGuestVerifyRequest(body = body("contact" to v("contact"), "locale" to env.language)).root()
            challenge = answer["challenge_id"].text()
            message = env.t("guest.code_sent", "contact" to (answer["contact"]?.text()?.ifEmpty { null } ?: v("contact")))
        }
    }

    suspend fun confirmCode() {
        val id = challenge ?: return
        run {
            val answer = env.api.platformAppGuestVerifyComplete(body = body("challenge_id" to id, "code" to v("code"), "locale" to env.language)).root()
            contactToken = answer["contact_token"].text()
            contact = answer["contact"].text()
            contactUntil = now() + (answer["expires_in"].long() ?: 900L) * 1000L
            challenge = null
            text["code"] = ""
            if (view == "list") orders = loadOrders()
        }
    }

    /** Places the shipment; answers the guest order and its order token (for `onCreated`), or null. */
    suspend fun submit(): Pair<Obj, String?>? {
        val rate = rateId ?: return null
        if (!verified) return null
        var created: Pair<Obj, String?>? = null
        run {
            val body = shipment() + mapOf("rate_id" to rate, "locale" to env.language) + (if (v("note").isNotEmpty()) mapOf("note" to v("note")) else emptyMap())
            val answer = env.api.platformAppGuestShipmentSubmit(body = body.json(), guestContactToken = contactToken).root()
            order = answer["guest_order"].obj()
            orderToken = answer["order_token"]?.text()?.ifEmpty { null }
            view = "order"
            created = order!! to orderToken
        }
        return created
    }

    suspend fun refresh() {
        val id = order?.get("id").long() ?: return
        run { order = fetch(id) }
    }

    private suspend fun loadOrders(): List<Obj> =
        env.api.platformAppGuestShipments(locale = env.language, guestContactToken = contactToken).root()["items"].objs()

    /** My shipments: the list once the contact is confirmed, else the code step. */
    suspend fun showList() {
        view = "list"
        order = null
        orderToken = null
        confirming = false
        message = null
        if (verified) run { orders = loadOrders() }
    }

    suspend fun open(id: Long) {
        orderToken = null
        run {
            order = fetch(id)
            view = "order"
        }
    }

    fun askCancel() { confirming = true; message = null }
    fun back() { confirming = false }

    /** Cancels after the question was confirmed; answers the cancelled guest order (for `onCancelled`), or null. */
    suspend fun cancel(): Obj? {
        val id = order?.get("id").long() ?: return null
        confirming = false
        var cancelled: Obj? = null
        run {
            val (o, c) = tokens()
            order = env.api.platformAppGuestShipmentCancel(id, guestOrderToken = o, guestContactToken = c).root()["guest_order"].obj()
            message = env.t("guest.cancel_done")
            cancelled = order
        }
        return cancelled
    }

    /** The label as a file (for `onFile`), or null (the reason shown). */
    suspend fun label(): SrGuestFile? {
        val id = order?.get("id").long() ?: return null
        var file: SrGuestFile? = null
        run {
            val (o, c) = tokens()
            val data = env.api.platformAppGuestShipmentLabel(id, guestOrderToken = o, guestContactToken = c).root()["pdf_data"].text()
            if (data.isEmpty()) {
                message = env.t("common.error")
                failed = true
            } else {
                file = SrGuestFile("label-$id.pdf", "application/pdf", Base64.getMimeDecoder().decode(data))
            }
        }
        return file
    }

    fun newShipment() {
        order = null
        orderToken = null
        rates = null
        rateId = null
        view = "form"
        confirming = false
        message = null
        failed = false
    }

    /** Whether the label can be downloaded. */
    val labelReady: Boolean get() = order?.let { it["kind"] == "label" && it["status"] == "placed" } == true
    val trackingNumbers: List<String>
        get() = order?.get("order").obj()["packages"].objs().mapNotNull { (it["tracking_number"] ?: it["external_tracking_number"])?.text()?.ifEmpty { null } }
}

/**
 * The guest shipping flow: addresses and packages → prices → a code to the person's email or phone → the shipment and
 * its payment page, which the app opens ([onOpenUrl]); the label is handed over as a file ([onFile]). Never navigates.
 */
@Composable
fun GuestShippingOrder(
    verificationChannel: String = "email",
    country: String? = null,
    guestOrderId: Long? = null,
    orderToken: String? = null,
    onCreated: (guestOrder: Obj, orderToken: String?) -> Unit = { _, _ -> },
    onCancelled: (Obj) -> Unit = {},
    onOpenUrl: (String) -> Unit = {},
    onFile: (filename: String, mimeType: String, bytes: ByteArray) -> Unit = { _, _, _ -> },
    modifier: Modifier = Modifier,
    onError: ((SuperrouteException) -> Unit)? = null,
) {
    val s = superroute()
    val state = rememberLoaded(onError, verificationChannel, country, guestOrderId, orderToken,
        create = { GuestShippingOrderState(it, verificationChannel, country, guestOrderId, orderToken) }) { load() }
    val scope = rememberCoroutineScope()
    val d = state.busy
    val e = state.errors
    @Composable fun field(name: String, label: String, required: Boolean = false, keyboard: KeyboardType = KeyboardType.Text, m: Modifier = Modifier.fillMaxWidth()) =
        SrField(state.text[name] ?: "", { state.set(name, it) }, label, "sr-guest-$name", required = required, error = e[name], keyboard = keyboard, modifier = m)
    @Composable fun contactStep() {
        field("contact", s.t(if (state.phone) "guest.contact_phone" else "guest.contact_email"), required = true,
            keyboard = if (state.phone) KeyboardType.Phone else KeyboardType.Email)
        SrOutlinedButton(s.t("guest.send_code"), "sr-guest-send", enabled = !d) { scope.launch { state.sendCode() } }
        if (state.challenge != null) {
            field("code", s.t("guest.code"), required = true, keyboard = KeyboardType.Number)
            SrPrimaryButton(s.t("guest.confirm_code"), "sr-guest-confirm", enabled = !d) { scope.launch { state.confirmCode() } }
        }
    }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(s.space("m"))) {
        val order = state.order
        when {
            state.view == "order" && order != null -> {
                SrTitle("${s.t("guest.shipment", "id" to order["id"])} · ${state.statusText(order["status"])}")
                SrAmount(s.t("order.total"), s.money(order["amount"], order["currency"]), "sr-guest-total", strong = true)
                order["pay_url"]?.text()?.ifEmpty { null }?.let { url ->
                    SrPrimaryButton(s.t("guest.pay", "amount" to s.money(order["amount"], order["currency"])), "sr-guest-pay", enabled = !d) { onOpenUrl(url) }
                    if (order["pay_before"] != null) SrMuted(s.t("guest.pay_before", "date" to s.date(order["pay_before"])))
                    SrOutlinedButton(s.t("guest.refresh"), "sr-guest-refresh", enabled = !d) { scope.launch { state.refresh() } }
                }
                state.trackingNumbers.forEach { SrBody(s.t("guest.tracking", "number" to it)) }
                if (state.confirming) {
                    SrBody(s.t("guest.cancel_confirm"), Modifier.padding(top = s.space("m")).testTag("sr-guest-cancel-question"))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SrPrimaryButton(s.t("guest.cancel"), "sr-guest-cancel-confirm", enabled = !d, modifier = Modifier.weight(1f)) {
                            scope.launch { state.cancel()?.let(onCancelled) }
                        }
                        Spacer(Modifier.width(s.space("s")))
                        SrTextButton(s.t("common.back"), "sr-guest-cancel-back", enabled = !d) { state.back() }
                    }
                } else {
                    if (state.labelReady) SrPrimaryButton(s.t("guest.label"), "sr-guest-label", enabled = !d) {
                        scope.launch { state.label()?.let { onFile(it.filename, it.mimeType, it.bytes) } }
                    }
                    if (order["can_cancel"].isTrue()) SrOutlinedButton(s.t("guest.cancel"), "sr-guest-cancel", enabled = !d) { state.askCancel() }
                }
                SrNotice(state.message, "sr-guest-message", danger = state.failed)
                Row {
                    SrTextButton(s.t("guest.new"), "sr-guest-new") { state.newShipment() }
                    SrTextButton(s.t("guest.my_orders"), "sr-guest-list") { scope.launch { state.showList() } }
                }
            }
            state.view == "list" -> {
                SrTitle(s.t("guest.my_orders"))
                val orders = state.orders
                when {
                    !state.verified -> {
                        SrBody(s.t("guest.my_orders_hint"))
                        SrMuted(s.t("common.required_note"))
                        contactStep()
                    }
                    orders != null && orders.isEmpty() -> SrMuted(s.t("guest.no_orders"), Modifier.testTag("sr-guest-no-orders"))
                    orders != null -> orders.forEach { o ->
                        Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("sr-guest-order-${o["id"].text()}"), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                SrBody("${s.t("guest.shipment", "id" to o["id"])} · ${state.statusText(o["status"])}")
                                SrMuted(s.date(o["created_at"]), small = true)
                            }
                            SrBody(s.money(o["amount"], o["currency"]))
                            SrTextButton(s.t("guest.open"), "sr-guest-open-${o["id"].text()}", enabled = !d) {
                                o["id"].long()?.let { id -> scope.launch { state.open(id) } }
                            }
                        }
                    }
                }
                SrNotice(state.message, "sr-guest-message", danger = state.failed)
                SrTextButton(s.t("guest.new"), "sr-guest-new") { state.newShipment() }
            }
            else -> {
                Row(Modifier.fillMaxWidth()) {
                    Spacer(Modifier.weight(1f))
                    SrTextButton(s.t("guest.my_orders"), "sr-guest-list") { scope.launch { state.showList() } }
                }
                SrMuted(s.t("common.required_note"))
                for ((side, title) in listOf("from" to "sform.sender", "to" to "sform.recipient")) {
                    SrTitle(s.t(title))
                    GUEST_SIDE_FIELDS.forEach { (f, label) ->
                        if (f == "country") {
                            SrChoice(s.t(label), "sr-guest-${side}_country", countryOptions(s.env.language), state.v("${side}_country"),
                                { state.set("${side}_country", it) }, required = true)
                        } else {
                            field("${side}_$f", s.t(label), required = f !in GUEST_OPTIONAL,
                                keyboard = when (f) { "email" -> KeyboardType.Email; "telephone" -> KeyboardType.Phone; else -> KeyboardType.Text })
                        }
                    }
                }
                Row {
                    SrChoice(s.t("sform.weight_unit"), "sr-guest-weight_unit", listOf(2 to "kg", 4 to "lb"), state.weightUnit, { state.weightUnit = it }, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(s.space("s")))
                    SrChoice(s.t("sform.dimension_unit"), "sr-guest-dimension_unit", listOf(2 to "cm", 4 to "in"), state.dimensionUnit, { state.dimensionUnit = it }, modifier = Modifier.weight(1f))
                }
                state.packages.forEachIndexed { i, p ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SrBody(s.t("sform.package", "n" to i + 1), Modifier.weight(1f), weight = FontWeight.SemiBold)
                        if (state.packages.size > 1) SrTextButton(s.t("sform.remove_package"), "sr-guest-remove-$i") { state.removePackage(i) }
                    }
                    Row {
                        listOf("weight", "length", "width", "height").forEachIndexed { k, n ->
                            if (k > 0) Spacer(Modifier.width(s.space("xs")))
                            SrField(p[n], { state.editPackage(i, n, it) }, s.t("sform.$n"), "sr-guest-package.$i.$n", required = n == "weight",
                                error = e["package.$i.$n"], keyboard = KeyboardType.Decimal, modifier = Modifier.weight(1f))
                        }
                    }
                }
                if (state.packages.size < 20) SrTextButton(s.t("sform.add_package"), "sr-guest-add") { state.addPackage() }
                SrPrimaryButton(s.t("guest.rates"), "sr-guest-rates", enabled = !d) { scope.launch { state.getRates() } }
                val rates = state.rates
                if (!rates.isNullOrEmpty()) {
                    SrTitle(s.t("sform.service"))
                    Column(Modifier.selectableGroup()) {
                        rates.forEach { r ->
                            val id = r["rate_id"].text()
                            val name = listOf(r["carrier_name"].text(), r["service_name"].text()).filter(String::isNotEmpty).joinToString(" · ")
                                .ifEmpty { s.t("sform.service") }
                            Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).selectable(state.rateId == id, role = Role.RadioButton) { state.rateId = id }
                                .testTag("sr-guest-rate-$id"), verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = state.rateId == id, onClick = null)
                                Column(Modifier.weight(1f).padding(start = s.space("s"))) {
                                    SrBody(name)
                                    if (r["transit_days"] != null) SrMuted(s.t("guest.transit", "days" to r["transit_days"]), small = true)
                                }
                                SrBody(s.money(r["shipping_price"], r["currency"]))
                            }
                        }
                    }
                    if (state.verified) {
                        SrBody(s.t("guest.verified", "contact" to state.contact), Modifier.testTag("sr-guest-verified"), color = s.color("success"))
                        field("note", s.t("sform.note"))
                        SrPrimaryButton(s.t("guest.submit"), "sr-guest-submit", enabled = !d) {
                            scope.launch { state.submit()?.let { (o, t) -> onCreated(o, t) } }
                        }
                    } else {
                        contactStep()
                    }
                }
                SrNotice(state.message, "sr-guest-message", danger = state.failed)
            }
        }
    }
}

