package ca.superroute.sapp.ui

import ca.superroute.sapp.PartnerApi
import ca.superroute.sapp.PartnerClient
import ca.superroute.sapp.SuperrouteException
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import java.math.BigInteger
import java.text.DateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** The kit's 14 languages (UI-KIT-SPEC.md §Rules). */
val UI_LANGUAGES: List<String> = listOf("en", "chs", "cht", "de", "es", "fr", "it", "nl", "pt", "sr", "hu", "pl", "sk", "cs")

/** Parsed once: language → key → text. */
internal val uiStrings: Map<String, Map<String, String>> by lazy {
    UiStringTables.json.mapValues { (_, text) ->
        (Json.parseToJsonElement(text) as JsonObject).mapValues { (it.value as JsonPrimitive).content }
    }
}

/** The kit's strings in one language, falling back to English (as the Flutter kit's `SuperrouteScope.t`). */
class SrStrings(locale: String?) {
    val language: String = if (locale != null && uiStrings.containsKey(locale)) locale else "en"

    /** The string for [key] with `:name` placeholders filled; the key itself when no language has it. */
    fun t(key: String, params: Map<String, Any?> = emptyMap()): String {
        var text = uiStrings[language]?.get(key) ?: uiStrings["en"]?.get(key) ?: key
        params.forEach { (name, value) -> text = text.replace(":$name", value.text()) }
        return text
    }

    fun t(key: String, vararg params: Pair<String, Any?>): String = t(key, mapOf(*params))

    /** Whether a string exists for [key]. */
    fun has(key: String): Boolean = uiStrings["en"]?.containsKey(key) == true

    /** A Java locale for dates. */
    val javaLocale: Locale
        get() = when (language) {
            "chs" -> Locale.SIMPLIFIED_CHINESE
            "cht" -> Locale.TRADITIONAL_CHINESE
            else -> Locale.forLanguageTag(language)
        }
}

/**
 * What every component's state holder needs: the client, the strings and the session callback. Kept free of Compose so
 * every state holder runs in a plain JVM test.
 */
class SrEnv(
    val client: PartnerClient,
    locale: String? = null,
    @Volatile var onSignInRequired: (() -> Unit)? = null,
) {
    val strings: SrStrings = SrStrings(locale ?: client.locale)
    val api: PartnerApi get() = client.api
    val language: String get() = strings.language

    /**
     * Called once with every failed call of a component that uses this environment (UI-KIT-SPEC.md §Errors), in
     * addition to what the component shows. Set on the scope's environment by `SuperrouteScope(onError = …)` and on a
     * component's own environment by the component's `onError`.
     */
    @Volatile var onError: ((SuperrouteException) -> Unit)? = null

    /** The scope's environment when this one belongs to one component. */
    private var parent: SrEnv? = null

    /** An environment for one component below this one: its own [onError], the rest (and this one's [onError]) shared. */
    fun component(): SrEnv = SrEnv(client, strings.language).also { it.parent = this }

    /**
     * Hands a failed call to [onError] here and on every environment above (the component's, then the scope's). A
     * failure that is not the SDK's error is passed as one with status 0 and code `unknown_error`. Cancellation is not
     * a failure and is never reported.
     */
    fun report(error: Throwable) {
        if (error is kotlinx.coroutines.CancellationException) return
        val sdk = error as? SuperrouteException ?: SuperrouteException(0, "unknown_error", error.message)
        var env: SrEnv? = this
        while (env != null) {
            env.onError?.let { callback -> runCatching { callback(sdk) } }
            env = env.parent
        }
    }

    fun t(key: String, params: Map<String, Any?> = emptyMap()): String = strings.t(key, params)
    fun t(key: String, vararg params: Pair<String, Any?>): String = strings.t(key, mapOf(*params))

    /** The string for a failed call (UI-KIT-SPEC.md §Errors). Raises onSignInRequired when the session ended. */
    fun errorText(error: Throwable, signingIn: Boolean = false): String {
        if (error !is SuperrouteException) return t("common.error")
        if (error.code == "network_error") return t("common.error_network")
        if (signingIn && error.code == "access_denied") return t("sign_in.error_credentials")
        if (error.code == "interaction_required") return t("sign_in.error_two_step")
        if (error.signInRequired) {
            (onSignInRequired ?: parent?.onSignInRequired)?.invoke()
            return t("common.error_signed_out")
        }
        if (error.status == 403 || error.code == "insufficient_scope") return t("common.error_not_allowed")
        return t("common.error")
    }

    /** The answer's error body of a failed call, as plain values. */
    fun errorBody(error: SuperrouteException): Obj = error.body.plain().obj()

    /** The server's `message` of a refusal, else the error's string. */
    fun refusal(error: Throwable): String {
        if (error is SuperrouteException) {
            val message = errorBody(error)["message"]
            if (message is String && message.isNotEmpty() && error.status in 400..499 && error.status != 401 && error.status != 403) return message
        }
        return errorText(error)
    }

    /** Money with two decimals and the currency code. */
    fun money(amount: Any?, currency: Any?): String = formatMoney(amount, currency as? String)

    fun date(iso: Any?): String = formatDate(iso, strings.javaLocale)
}

/**
 * Money from the API's decimal string, always with two decimals and the currency code (`12.50 CAD`), never through a
 * floating-point number; half up on the decimal digits themselves (as `formatMoney` in the Flutter kit's scope.dart).
 */
fun formatMoney(amount: Any?, currency: String?): String {
    var text = (amount ?: "0").text().trim()
    val negative = text.startsWith("-")
    if (negative || text.startsWith("+")) text = text.substring(1)
    val parts = text.split('.')
    val whole = parts[0].ifEmpty { "0" }
    var fraction = if (parts.size > 1) parts[1] else ""
    val tail = if (currency == null) "" else " $currency"
    if (fraction.length > 2) {
        val cents = BigInteger(whole + fraction.substring(0, 2)) + if (fraction[2].digitToInt() >= 5) BigInteger.ONE else BigInteger.ZERO
        val s = cents.toString().padStart(3, '0')
        return "${if (negative) "-" else ""}${s.substring(0, s.length - 2)}.${s.substring(s.length - 2)}$tail"
    }
    fraction = fraction.padEnd(2, '0')
    return "${if (negative) "-" else ""}$whole.$fraction$tail"
}

private val ISO = Regex("""^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d+))?)?)?\s*(Z|[+-]\d{2}:?\d{2})?$""")

/** Parses an ISO 8601 date-time from the API (offset or `Z`; without one, the device's time zone). */
fun parseIsoDate(iso: Any?): Date? {
    val m = ISO.matchEntire((iso as? String)?.trim() ?: return null) ?: return null
    val g = m.groupValues
    val zone = when {
        g[8].isEmpty() -> TimeZone.getDefault()
        g[8] == "Z" -> TimeZone.getTimeZone("UTC")
        else -> TimeZone.getTimeZone("GMT" + g[8].let { if (it.contains(':')) it else it.substring(0, 3) + ":" + it.substring(3) })
    }
    val calendar = Calendar.getInstance(zone).apply {
        clear()
        set(g[1].toInt(), g[2].toInt() - 1, g[3].toInt(), g[4].ifEmpty { "0" }.toInt(), g[5].ifEmpty { "0" }.toInt(), g[6].ifEmpty { "0" }.toInt())
        set(Calendar.MILLISECOND, g[7].padEnd(3, '0').take(3).ifEmpty { "0" }.toInt())
    }
    return calendar.time
}

/** A date from the API in the device's time zone: the locale's medium date and short time. Empty when unreadable. */
fun formatDate(iso: Any?, locale: Locale = Locale.getDefault()): String {
    val date = parseIsoDate(iso) ?: return ""
    return DateFormat.getDateInstance(DateFormat.MEDIUM, locale).format(date) + " " + DateFormat.getTimeInstance(DateFormat.SHORT, locale).format(date)
}
