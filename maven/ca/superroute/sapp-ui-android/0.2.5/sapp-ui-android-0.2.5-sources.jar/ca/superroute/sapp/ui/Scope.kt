package ca.superroute.sapp.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ExposedDropdownMenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ca.superroute.sapp.PartnerClient
import ca.superroute.sapp.SuperrouteException
import ca.superroute.sapp.ThemeTokens
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject

/** What a component reads from [SuperrouteScope]: the environment and the theme tokens. */
class SrScope(val env: SrEnv, val theme: ThemeTokens, val image: SrImageContent? = null, val dark: Boolean = false) {
    fun t(key: String, vararg params: Pair<String, Any?>): String = env.t(key, mapOf(*params))

    /** The palette components draw with: the theme's dark palette when [dark], else its light one. */
    val colors: Map<String, String> get() = theme.colorsFor(dark)

    fun color(name: String): Color = parseColor(colors[name] ?: "#000000")
    fun radius(name: String): Dp = (theme.radius[name] ?: 8.0).dp
    fun space(name: String): Dp = (theme.spacing[name] ?: 8.0).dp
    fun size(name: String): TextUnit = (theme.type[name] ?: 15.0).sp
    fun money(amount: Any?, currency: Any?): String = env.money(amount, currency)
    fun date(iso: Any?): String = env.date(iso)

    companion object {
        fun parseColor(hex: String): Color = Color(("FF" + hex.removePrefix("#")).toLong(16))
    }
}

/**
 * Draws a picture from a URL. The kit adds no image-loading dependency: the app passes its own (Coil, Glide, …) to
 * [SuperrouteScope]; without one, pictures leave their space empty.
 */
typealias SrImageContent = @Composable (url: String, modifier: Modifier) -> Unit

val LocalSuperroute = staticCompositionLocalOf<SrScope?> { null }

/** The scope every component reads; components need a [SuperrouteScope] above them. */
@Composable
fun superroute(): SrScope = checkNotNull(LocalSuperroute.current) { "Superroute components need a SuperrouteScope above them." }

/**
 * Puts the client, the theme tokens and the language in reach of every component below it (UI-KIT-SPEC.md §Rules),
 * with a Material theme built from the tokens. Replacing [client] reloads every component.
 *
 * The theme's mode decides light or dark (`auto` follows the device); dark draws with the theme's dark palette and a
 * dark Material colour scheme. [onError] gets every failed call of every component below, in addition to the
 * component's own `onError`.
 */
@Composable
fun SuperrouteScope(
    client: PartnerClient,
    theme: ThemeTokens = remember { ThemeTokens(JsonObject(emptyMap())) },
    locale: String? = null,
    onSignInRequired: (() -> Unit)? = null,
    image: SrImageContent? = null,
    onError: ((SuperrouteException) -> Unit)? = null,
    content: @Composable () -> Unit,
) {
    val env = remember(client, locale ?: client.locale) { SrEnv(client, locale) }
    env.onSignInRequired = onSignInRequired
    env.onError = onError
    val dark = theme.isDark(isSystemInDarkTheme())
    val scope = remember(env, theme, image, dark) { SrScope(env, theme, image, dark) }
    val colors = if (dark) darkColorScheme(
        primary = scope.color("primary"),
        onPrimary = scope.color("onPrimary"),
        primaryContainer = scope.color("primaryContainer"),
        onPrimaryContainer = scope.color("onPrimaryContainer"),
        secondaryContainer = scope.color("primaryContainer"),
        onSecondaryContainer = scope.color("onPrimaryContainer"),
        surface = scope.color("surface"),
        onSurface = scope.color("onSurface"),
        background = scope.color("surface"),
        onBackground = scope.color("onSurface"),
        error = scope.color("danger"),
    ) else lightColorScheme(
        primary = scope.color("primary"),
        onPrimary = scope.color("onPrimary"),
        primaryContainer = scope.color("primaryContainer"),
        onPrimaryContainer = scope.color("onPrimaryContainer"),
        secondaryContainer = scope.color("primaryContainer"),
        onSecondaryContainer = scope.color("onPrimaryContainer"),
        surface = scope.color("surface"),
        onSurface = scope.color("onSurface"),
        background = scope.color("surface"),
        onBackground = scope.color("onSurface"),
        error = scope.color("danger"),
    )
    MaterialTheme(colorScheme = colors) {
        CompositionLocalProvider(LocalSuperroute provides scope, content = content)
    }
}

/**
 * The environment of one component: the scope's, with the component's own [onError] (the scope's is called too).
 * Kept while the scope's environment stays.
 */
@Composable
internal fun rememberComponentEnv(onError: ((SuperrouteException) -> Unit)?): SrEnv {
    val parent = superroute().env
    val env = remember(parent) { parent.component() }
    env.onError = onError
    return env
}

/** A state holder kept for one client and loaded when it is first shown and whenever the client changes. */
@Composable
internal fun <T : Any> rememberLoaded(onError: ((SuperrouteException) -> Unit)?, vararg keys: Any?, create: (SrEnv) -> T, load: suspend T.() -> Unit): T {
    val env = rememberComponentEnv(onError)
    val state = remember(env, *keys) { create(env) }
    LaunchedEffect(state) { state.load() }
    return state
}

// ---------------------------------------------------------------------------------------------------------- pieces

@Composable
internal fun SrTitle(text: String, modifier: Modifier = Modifier) {
    val s = superroute()
    Text(text, modifier = modifier.padding(top = s.space("l"), bottom = s.space("s")), fontSize = s.size("title"), fontWeight = FontWeight.SemiBold, color = s.color("onSurface"))
}

@Composable
internal fun SrMuted(text: String, modifier: Modifier = Modifier, small: Boolean = false) {
    val s = superroute()
    Text(text, modifier = modifier, color = s.color("muted"), fontSize = if (small) s.size("small") else s.size("body"))
}

@Composable
internal fun SrBody(text: String, modifier: Modifier = Modifier, weight: FontWeight? = null, color: Color? = null, size: TextUnit? = null, strike: Boolean = false) {
    val s = superroute()
    Text(text, modifier = modifier, fontSize = size ?: s.size("body"), fontWeight = weight, color = color ?: s.color("onSurface"),
        textDecoration = if (strike) TextDecoration.LineThrough else null)
}

@Composable
internal fun SrDanger(text: String, modifier: Modifier = Modifier) {
    val s = superroute()
    Text(text, modifier = modifier, color = s.color("danger"), fontSize = s.size("small"))
}

/** A text the component shows after an action (a success or a refusal). */
@Composable
internal fun SrNotice(text: String?, tag: String, danger: Boolean = false) {
    if (text.isNullOrEmpty()) return
    val s = superroute()
    Text(text, modifier = Modifier.fillMaxWidth().padding(vertical = s.space("s")).testTag(tag),
        color = if (danger) s.color("danger") else s.color("onSurface"), fontSize = s.size("body"))
}

@Composable
internal fun SrPrimaryButton(text: String, tag: String, enabled: Boolean = true, modifier: Modifier = Modifier.fillMaxWidth(), onClick: () -> Unit) {
    val s = superroute()
    Button(
        onClick = onClick, enabled = enabled,
        modifier = modifier.heightIn(min = 48.dp).testTag(tag),
        shape = RoundedCornerShape(s.radius("medium")),
        colors = ButtonDefaults.buttonColors(containerColor = s.color("primary"), contentColor = s.color("onPrimary")),
    ) { Text(text) }
}

@Composable
internal fun SrOutlinedButton(text: String, tag: String, enabled: Boolean = true, danger: Boolean = false, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val s = superroute()
    OutlinedButton(
        onClick = onClick, enabled = enabled, modifier = modifier.heightIn(min = 48.dp).testTag(tag),
        shape = RoundedCornerShape(s.radius("medium")),
        colors = if (danger) ButtonDefaults.outlinedButtonColors(contentColor = s.color("danger")) else ButtonDefaults.outlinedButtonColors(),
    ) { Text(text) }
}

@Composable
internal fun SrTextButton(text: String, tag: String, enabled: Boolean = true, modifier: Modifier = Modifier, onClick: () -> Unit) {
    TextButton(onClick = onClick, enabled = enabled, modifier = modifier.heightIn(min = 44.dp).testTag(tag)) { Text(text) }
}

/** The loading / error / empty frame every list shares. */
@Composable
internal fun SrStateView(loading: Boolean, error: Throwable?, empty: Boolean, emptyText: String, onRetry: () -> Unit, content: @Composable () -> Unit) {
    val s = superroute()
    when {
        loading && empty -> Box(Modifier.fillMaxWidth().padding(s.space("l")), contentAlignment = Alignment.Center) {
            val label = s.t("common.loading")
            CircularProgressIndicator(Modifier.semantics { contentDescription = label }.testTag("sr-loading"))
        }
        error != null && empty -> Column(Modifier.fillMaxWidth().padding(s.space("l")), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(s.env.errorText(error), modifier = Modifier.testTag("sr-error"), textAlign = TextAlign.Center, color = s.color("onSurface"), fontSize = s.size("body"))
            Spacer(Modifier.padding(s.space("s")))
            SrOutlinedButton(s.t("common.retry"), "sr-retry", onClick = onRetry)
        }
        empty -> Box(Modifier.fillMaxWidth().padding(s.space("l")), contentAlignment = Alignment.Center) {
            Text(emptyText, modifier = Modifier.testTag("sr-empty"), color = s.color("muted"), fontSize = s.size("body"))
        }
        else -> content()
    }
}

/** **Load more** while the list has more pages. */
@Composable
internal fun SrLoadMore(list: SrPagedList, after: suspend () -> Unit = {}) {
    if (!list.hasMore || list.items.isEmpty()) return
    val s = superroute()
    val scope = rememberCoroutineScope()
    SrTextButton(s.t("common.load_more"), "sr-load-more", enabled = !list.loading) { scope.launch { list.next(); after() } }
}

/** A label and a value on one row. */
@Composable
internal fun SrLine(label: String, value: String, tag: String? = null) {
    val s = superroute()
    Row(Modifier.fillMaxWidth().padding(vertical = s.space("s"))) {
        Text(label, modifier = Modifier.width(120.dp), color = s.color("muted"), fontSize = s.size("body"))
        Text(value, modifier = Modifier.weight(1f).let { if (tag != null) it.testTag(tag) else it }, fontSize = s.size("body"), color = s.color("onSurface"))
    }
}

/** An amount row: the label left, the money right. */
@Composable
internal fun SrAmount(label: String, amount: String, tag: String, strong: Boolean = false, color: Color? = null) {
    val s = superroute()
    val weight = if (strong) FontWeight.SemiBold else null
    Row(Modifier.fillMaxWidth().padding(vertical = s.space("xs") / 2), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), fontWeight = weight, fontSize = s.size("body"), color = s.color("onSurface"))
        Text(amount, modifier = Modifier.testTag(tag), fontWeight = weight, fontSize = s.size("body"), color = color ?: s.color("onSurface"))
    }
}

/** A text field bound to a state holder's value. */
@Composable
internal fun SrField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    tag: String,
    required: Boolean = false,
    error: String? = null,
    hint: String? = null,
    multiline: Boolean = false,
    keyboard: KeyboardType = KeyboardType.Text,
    password: Boolean = false,
    enabled: Boolean = true,
    modifier: Modifier = Modifier.fillMaxWidth(),
) {
    val s = superroute()
    OutlinedTextField(
        value = value, onValueChange = onChange, enabled = enabled,
        modifier = modifier.padding(bottom = s.space("s")).testTag(tag),
        label = { Text(if (required) "$label *" else label) },
        placeholder = hint?.let { { Text(it) } },
        isError = !error.isNullOrEmpty(),
        supportingText = if (error.isNullOrEmpty()) null else ({ Text(error, modifier = Modifier.testTag("$tag-error")) }),
        singleLine = !multiline, minLines = if (multiline) 3 else 1,
        keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else keyboard),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
    )
}

/** One choice from a list (a drop-down field). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun <T> SrChoice(
    label: String,
    tag: String,
    options: List<Pair<T, String>>,
    value: T?,
    onChange: (T) -> Unit,
    required: Boolean = false,
    error: String? = null,
    modifier: Modifier = Modifier.fillMaxWidth(),
) {
    val s = superroute()
    var open by remember { mutableStateOf(false) }
    val shown = options.firstOrNull { it.first == value }?.second ?: ""
    ExposedDropdownMenuBox(expanded = open, onExpandedChange = { open = it }, modifier = modifier.padding(bottom = s.space("s"))) {
        OutlinedTextField(
            value = shown, onValueChange = {}, readOnly = true,
            modifier = Modifier.fillMaxWidth().menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable).testTag(tag),
            label = { Text(if (required) "$label *" else label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = open) },
            isError = !error.isNullOrEmpty(),
            supportingText = if (error.isNullOrEmpty()) null else ({ Text(error, modifier = Modifier.testTag("$tag-error")) }),
        )
        ExposedDropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEachIndexed { i, (v, text) ->
                DropdownMenuItem(text = { Text(text) }, modifier = Modifier.testTag("$tag-option-$i"), onClick = { open = false; onChange(v) })
            }
        }
    }
}

/** Chips of which any number may be chosen (or one, when [onToggle] replaces the choice). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun SrChips(options: List<Pair<String, String>>, selected: (String) -> Boolean, tag: String, onToggle: (String) -> Unit) {
    val s = superroute()
    FlowRow(horizontalArrangement = Arrangement.spacedBy(s.space("xs")), modifier = Modifier.fillMaxWidth()) {
        options.forEach { (key, label) ->
            FilterChip(selected = selected(key), onClick = { onToggle(key) }, label = { Text(label) }, modifier = Modifier.heightIn(min = 44.dp).testTag("$tag-$key"))
        }
    }
}

/** A label with a switch. */
@Composable
internal fun SrSwitch(label: String, checked: Boolean, tag: String, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    val s = superroute()
    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), fontSize = s.size("body"), color = s.color("onSurface"))
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled, modifier = Modifier.testTag(tag).semantics { contentDescription = label })
    }
}

/** A row of a confirm action and **Cancel**: confirm first (left), cancel second (right), on every form and dialog. */
@Composable
internal fun SrConfirmRow(confirm: String, confirmTag: String, enabled: Boolean = true, cancelTag: String? = null, onCancel: (() -> Unit)? = null, cancelEnabled: Boolean = true, onConfirm: () -> Unit) {
    val s = superroute()
    Row(Modifier.fillMaxWidth().padding(top = s.space("l")), verticalAlignment = Alignment.CenterVertically) {
        SrPrimaryButton(confirm, confirmTag, enabled = enabled, modifier = Modifier.weight(1f), onClick = onConfirm)
        if (onCancel != null) {
            Spacer(Modifier.width(s.space("s")))
            SrTextButton(s.t("common.cancel"), cancelTag ?: "$confirmTag-cancel", enabled = cancelEnabled, onClick = onCancel)
        }
    }
}

/**
 * A confirmation dialog: the confirm button first (left), Cancel second (right). Material's own confirm / dismiss slots
 * put the dismiss button first, so both buttons sit in one row of the confirm slot.
 */
@Composable
internal fun SrConfirmDialog(text: String, confirm: String, confirmTag: String, onConfirm: () -> Unit, onDismiss: () -> Unit, extra: (@Composable () -> Unit)? = null) {
    val s = superroute()
    AlertDialog(
        onDismissRequest = onDismiss,
        text = {
            Column {
                Text(text, fontSize = s.size("body"), modifier = Modifier.testTag("sr-dialog-text"))
                extra?.invoke()
            }
        },
        confirmButton = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = onConfirm, modifier = Modifier.heightIn(min = 44.dp).testTag(confirmTag),
                    colors = ButtonDefaults.buttonColors(containerColor = s.color("primary"), contentColor = s.color("onPrimary"))) { Text(confirm) }
                Spacer(Modifier.width(s.space("s")))
                TextButton(onClick = onDismiss, modifier = Modifier.heightIn(min = 44.dp).testTag("sr-dialog-cancel")) { Text(s.t("common.cancel")) }
            }
        },
    )
}

/** A pending confirmation: a text, the confirm label and what runs when confirmed. */
internal class SrAsk(val text: String, val confirm: String, val tag: String, val reason: Boolean = false, val run: suspend (reason: String) -> Unit)

/** Shows [ask] while it is set; the reason field when it asks for one. */
@Composable
internal fun SrAskDialog(ask: SrAsk?, scope: CoroutineScope, reasonLabel: String? = null, onClose: () -> Unit) {
    if (ask == null) return
    var reason by remember(ask) { mutableStateOf("") }
    SrConfirmDialog(
        text = ask.text, confirm = ask.confirm, confirmTag = ask.tag,
        onConfirm = { onClose(); scope.launch { ask.run(reason.trim()) } },
        onDismiss = onClose,
        extra = if (!ask.reason) null else ({
            OutlinedTextField(value = reason, onValueChange = { if (it.length <= 500) reason = it }, label = { Text(reasonLabel ?: "") },
                modifier = Modifier.fillMaxWidth().testTag("${ask.tag}-reason"))
        }),
    )
}

/** The common text style of large figures. */
internal fun SrScope.figureStyle(color: Color? = null) = TextStyle(fontSize = size("title"), fontWeight = FontWeight.SemiBold, color = color ?: color("onSurface"))

@Composable
internal fun SrPage(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val s = superroute()
    Column(modifier.fillMaxSize().padding(s.space("l"))) { content() }
}

/** A picture of [size] (or [modifier]'s size) from the app's image loader; an empty space without one or without a URL. */
@Composable
internal fun SrImage(url: Any?, modifier: Modifier) {
    val s = superroute()
    val link = url.text()
    Box(modifier) { if (link.isNotEmpty()) s.image?.invoke(link, Modifier.fillMaxSize()) }
}
