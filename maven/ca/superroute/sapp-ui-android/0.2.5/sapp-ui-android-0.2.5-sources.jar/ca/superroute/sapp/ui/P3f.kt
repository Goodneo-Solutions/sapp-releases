package ca.superroute.sapp.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ca.superroute.sapp.SuperrouteException
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonElement

/** Shares a leader's link: the answer's `share` (`{url, title, channels, links}`, may be null) and the link. The share sheet is the app's. */
typealias OnShare = (share: Obj?, url: String) -> Unit

/** A leader's link as text, with **Share** when the app shares it (UI-KIT-SPEC.md §P3f). */
@Composable
private fun LeaderLink(url: String, share: Any?, onShare: OnShare?) {
    val s = superroute()
    SrTitle(s.t("lead.link"))
    SelectionContainer { SrBody(url, Modifier.testTag("sr-lead-link")) }
    if (onShare != null) {
        Spacer(Modifier.height(s.space("s")))
        SrOutlinedButton(s.t("lead.share"), "sr-lead-share") { onShare(share as? Map<String, Any?>, url) }
    }
}

private val LEADER_FIELDS = listOf("pickup_name", "address", "address_2", "city", "province", "postcode", "phone", "pickup_notes")
private val LEADER_REQUIRED = setOf("pickup_name", "address", "postcode")

/** The state of [GroupBuyLead] (UI-KIT-SPEC.md §Lead a group buy). */
class GroupBuyLeadState(env: SrEnv, val initialCode: String) : SrDriverState(env) {
    var data by mutableStateOf<Obj>(emptyMap())
        private set
    /** The campaign shown: the given one, or the one started from a self-pick plan. */
    var code by mutableStateOf(initialCode)
        private set
    val text = mutableStateMapOf<String, String>()
    val errors = mutableStateMapOf<String, String>()
    val items = mutableStateListOf<Long>()
    var busy by mutableStateOf(false)
        private set
    /** The success notice after an action (`lead.saved`, `lead.opened`, `lead.started`). */
    var notice by mutableStateOf<String?>(null)
        private set

    fun v(f: String): String = text[f]?.trim() ?: ""

    private fun take(answer: JsonElement) {
        data = answer.data()
        code = data["campaign"].obj()["code"]?.text() ?: code
        val leader = data["leader"].obj()
        LEADER_FIELDS.forEach { text[it] = leader[it].text() }
        items.clear()
        items.addAll(data["self_pick"].obj()["items"].objs().mapNotNull { it["id"].long() })
        errors.clear()
        message = null
    }

    override suspend fun fetch() {
        code = initialCode
        take(env.api.platformAppGroupBuyLead(code))
    }

    val campaign: Obj get() = data["campaign"].obj()
    val currency: String? get() = data["currency"] as? String
    val leader: Obj? get() = data["leader"] as? Map<String, Any?>
    val group: Obj? get() = data["group"] as? Map<String, Any?>
    val selfPick: Obj? get() = data["self_pick"] as? Map<String, Any?>
    val status: String get() = leader?.get("status").text()
    val canApply: Boolean get() = data["can_apply"] != false && status != "disabled"
    val canOpen: Boolean get() = data["may_lead"].isTrue() && group == null && selfPick == null
    val rates: List<Obj> get() = data["commission_rates"].objs()

    /** A commission rate: `lead.per_unit` with the money (fixed) or `lead.percent` (percentage). */
    fun rate(r: Obj): String = if (r["commission_mode"] == "fixed") env.t("lead.per_unit", "amount" to formatMoney(r["commission_value"], currency))
    else env.t("lead.percent", "value" to r["commission_value"].text().replaceFirst(Regex("\\.0+$"), ""))

    fun label(f: String): String = when (f) {
        "pickup_name" -> env.t("lead.pickup_name")
        "pickup_notes" -> env.t("lead.pickup_notes")
        "address" -> env.t("rform.address_1")
        else -> env.t("rform.$f")
    }

    private suspend fun send(done: String, call: suspend () -> JsonElement): Boolean {
        busy = true
        message = null
        notice = null
        errors.clear()
        val result = env.attempt { call() }
        result.onSuccess {
            take(it)
            notice = env.t(done)
        }.onFailure { e ->
            if (e is SuperrouteException) env.errorBody(e)["errors"].obj().forEach { (k, v) -> errors[k] = if (v is List<*> && v.isNotEmpty()) v.first().text() else v.text() }
            message = env.refusalText(e)
        }
        busy = false
        return result.isSuccess
    }

    /** **Apply to lead** / **Save details**. */
    suspend fun apply(): Boolean {
        errors.clear()
        LEADER_REQUIRED.filter { v(it).isEmpty() }.forEach { errors[it] = env.t("rform.required") }
        if (errors.isNotEmpty()) {
            message = null
            return false
        }
        return send("lead.saved") { env.api.platformAppGroupBuyLeadApply(code, body = LEADER_FIELDS.filter { v(it).isNotEmpty() }.associateWith { v(it) }.json()) }
    }

    /** **Open my group**. */
    suspend fun open(): Boolean = send("lead.opened") { env.api.platformAppGroupBuyLeadOpen(code) }

    fun toggle(itemId: Long) { if (itemId in items) items.remove(itemId) else items.add(itemId) }

    /** **Start** a campaign from the self-pick plan; answers the new campaign's code. */
    suspend fun start(): String? {
        errors.clear()
        if (items.isEmpty()) errors["item_ids"] = env.t("lead.items_required")
        if (v("cutoff_at").isEmpty()) errors["cutoff_at"] = env.t("rform.required")
        if (errors.isNotEmpty()) {
            message = null
            return null
        }
        fun at(f: String) = v(f).replaceFirst(' ', 'T')
        val request = buildMap<String, Any?> {
            put("item_ids", items.toList())
            put("cutoff_at", at("cutoff_at"))
            if (v("expected_delivery_at").isNotEmpty()) put("expected_delivery_at", at("expected_delivery_at"))
            if (v("title").isNotEmpty()) put("title", v("title"))
        }
        return if (send("lead.started") { env.api.platformAppGroupBuyLeadStart(code, body = request.json()) }) code else null
    }
}

/** Applying to lead a campaign, opening the group, or starting a campaign from a self-pick plan. */
@Composable
fun GroupBuyLead(code: String, onShare: OnShare? = null, onStarted: (code: String) -> Unit = {}, modifier: Modifier = Modifier, onError: ((SuperrouteException) -> Unit)? = null) {
    val s = superroute()
    val state = rememberLoaded(onError, code, create = { GroupBuyLeadState(it, code) }) { reload() }
    val scope = rememberCoroutineScope()
    SrFormFrame(state.loading, state.error, { scope.launch { state.reload() } }) {
        val campaign = state.campaign
        val currency = state.currency
        val leader = state.leader
        val e = state.errors
        @Composable fun field(f: String, label: String, required: Boolean = false, hint: String? = null) =
            SrField(state.text[f] ?: "", { state.text[f] = it }, label, "sr-lead-$f", required = required, error = e[f], hint = hint)
        Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(s.space("m"))) {
            SrNotice(state.notice, "sr-lead-notice")
            Text(campaign["title"].text(), fontSize = s.size("headline"), fontWeight = FontWeight.SemiBold, color = s.color("onSurface"))
            if (campaign["cutoff_at"] != null) SrMuted(s.t("gb.cutoff", "date" to s.date(campaign["cutoff_at"])))
            if (state.data["leader_policy"] == "approved") SrBody(s.t("lead.policy_approved"), Modifier.padding(top = s.space("s")))
            if (leader != null && state.status.isNotEmpty()) {
                val color = when (state.status) { "approved" -> s.color("success"); "pending" -> null; else -> s.color("danger") }
                SrBody(s.t("lead.status_${state.status}"), Modifier.padding(top = s.space("s")).testTag("sr-lead-status"), weight = FontWeight.SemiBold, color = color)
            }
            leader?.get("decision_note")?.text()?.takeIf { it.isNotEmpty() }?.let { SrBody(s.t("lead.note", "note" to it)) }
            if (!state.canApply && leader == null) SrDanger(s.t("lead.status_disabled"), Modifier.padding(top = s.space("s")))
            if (state.rates.isNotEmpty()) {
                SrTitle(s.t("lead.commission"))
                state.rates.forEach { r ->
                    Row(Modifier.fillMaxWidth().padding(vertical = s.space("xs") / 2).testTag("sr-lead-rate-${r["id"].text()}")) {
                        SrBody("${r["name"].text()} · ${s.money(r["group_price"], currency)}", Modifier.weight(1f))
                        SrBody(state.rate(r))
                    }
                }
            }
            if (state.canApply) {
                SrTitle(s.t("lead.details"))
                LEADER_FIELDS.forEach { field(it, state.label(it), it in LEADER_REQUIRED) }
                SrPrimaryButton(s.t(if (leader == null) "lead.apply" else "lead.save"), "sr-lead-apply", enabled = !state.busy) { scope.launch { state.apply() } }
            }
            if (state.canOpen) {
                Spacer(Modifier.height(s.space("m")))
                SrPrimaryButton(s.t("lead.open"), "sr-lead-open", enabled = !state.busy) { scope.launch { state.open() } }
            }
            state.group?.let { g -> g["share_url"].text().takeIf { it.isNotEmpty() }?.let { LeaderLink(it, g["share"], onShare) } }
            state.selfPick?.let { plan ->
                SrTitle(s.t("lead.self_pick"))
                SrBody(s.t("lead.range", "from" to plan["earliest_cutoff"].text().replaceFirst('T', ' '), "to" to plan["latest_cutoff"].text().replaceFirst('T', ' '),
                    "timezone" to plan["timezone"].text()))
                plan["items"].objs().forEach { item ->
                    val id = item["id"].long() ?: 0
                    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { state.toggle(id) }.testTag("sr-lead-item-$id"), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = id in state.items, onCheckedChange = { state.toggle(id) })
                        Column {
                            SrBody(item["name"].text())
                            SrMuted(s.money(item["group_price"], currency), small = true)
                        }
                    }
                }
                e["item_ids"]?.let { SrDanger(it, Modifier.testTag("sr-lead-items-error")) }
                Spacer(Modifier.height(s.space("s")))
                field("cutoff_at", s.t("lead.cutoff_at"), true, plan["earliest_cutoff"].text().replaceFirst('T', ' '))
                field("expected_delivery_at", s.t("lead.delivery_at"))
                field("title", s.t("lead.campaign_title"))
                SrPrimaryButton(s.t("lead.start"), "sr-lead-start", enabled = !state.busy) { scope.launch { state.start()?.let(onStarted) } }
            }
            state.message?.let { SrDanger(it, Modifier.padding(top = s.space("s")).testTag("sr-lead-message")) }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------- leading

/** The state of [GroupBuyLeading] (UI-KIT-SPEC.md §Groups I lead). */
class GroupBuyLeadingState(env: SrEnv) : SrDriverState(env) {
    var data by mutableStateOf<Obj>(emptyMap())
        private set

    override suspend fun fetch() { data = env.api.platformAppGroupBuyLeading().data() }

    val groups: List<Obj> get() = data["groups"].objs()
    val plans: List<Obj> get() = data["templates"].objs()

    fun details(g: Obj): String = listOf(g["status_label"].text(), env.t("lead.counts", "orders" to (g["orders"] ?: 0), "units" to (g["units"] ?: 0)))
        .filter { it.isNotEmpty() }.joinToString(" · ")
}

/** The groups the customer leads and the self-pick plans it may start. [onOpen] gets a group's id, [onOpenPlan] a plan's code. */
@Composable
fun GroupBuyLeading(onOpen: (groupId: Long) -> Unit = {}, onOpenPlan: (code: String) -> Unit = {}, modifier: Modifier = Modifier, onError: ((SuperrouteException) -> Unit)? = null) {
    val s = superroute()
    val state = rememberLoaded(onError, create = ::GroupBuyLeadingState) { reload() }
    val scope = rememberCoroutineScope()
    SrStateView(state.loading, state.error, state.groups.isEmpty() && state.plans.isEmpty(), s.t("lead.groups_empty"), { scope.launch { state.reload() } }) {
        LazyColumn(modifier.fillMaxSize()) {
            items(state.groups) { g ->
                Column(Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { onOpen(g["id"].long() ?: 0) }.padding(horizontal = s.space("m"), vertical = s.space("s"))
                    .testTag("sr-lead-group-${g["id"].text()}")) {
                    SrBody(g["campaign"].obj()["title"].text())
                    SrMuted(state.details(g), small = true)
                }
                HorizontalDivider()
            }
            if (state.plans.isNotEmpty()) item { Column(Modifier.padding(horizontal = s.space("m"))) { SrTitle(s.t("lead.plans")) } }
            items(state.plans) { p ->
                Column(Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { onOpenPlan(p["code"].text()) }.padding(horizontal = s.space("m"), vertical = s.space("s"))
                    .testTag("sr-lead-plan-${p["code"].text()}")) {
                    SrBody(p["title"].text())
                    if (p["cutoff_at"] != null) SrMuted(s.t("gb.cutoff", "date" to s.date(p["cutoff_at"])), small = true)
                }
                HorizontalDivider()
            }
        }
    }
}

/** The state of [GroupBuyLeadingGroup] (UI-KIT-SPEC.md §A group I lead). */
class GroupBuyLeadingGroupState(env: SrEnv, val groupId: Long) : SrDriverState(env) {
    var data by mutableStateOf<Obj>(emptyMap())
        private set
    var busy by mutableStateOf<Long?>(null)
        private set

    override suspend fun fetch() { data = env.api.platformAppGroupBuyLeadingGroup(groupId).data() }

    val group: Obj get() = data["group"].obj()
    val totals: Obj get() = data["totals"].obj()
    val currency: String? get() = data["currency"] as? String
    val households: List<Obj> get() = data["households"].objs()
    val counts: String get() = env.t("lead.counts", "orders" to (totals["orders"] ?: 0), "units" to (totals["units"] ?: 0))
    val commission: String get() = formatMoney(totals["commission"] ?: 0, currency)

    fun confirmText(h: Obj): String = env.t("lead.mark_confirm", "number" to h["number"])

    /** **Mark collected** (after the leader confirmed); the answer is the group. */
    suspend fun mark(h: Obj) {
        val id = h["id"].long() ?: return
        busy = id
        message = null
        env.attempt { env.api.platformAppGroupBuyLeadingCollected(groupId, id).data() }
            .onSuccess {
                data = data + it
                message = env.t("lead.marked")
            }
            .onFailure { message = env.refusalText(it) }
        busy = null
    }
}

/** One group the customer leads: its households, what each bought, and marking a household collected (asked first). */
@Composable
fun GroupBuyLeadingGroup(groupId: Long, onShare: OnShare? = null, modifier: Modifier = Modifier, onError: ((SuperrouteException) -> Unit)? = null) {
    val s = superroute()
    val state = rememberLoaded(onError, groupId, create = { GroupBuyLeadingGroupState(it, groupId) }) { reload() }
    val scope = rememberCoroutineScope()
    var ask by remember { mutableStateOf<SrAsk?>(null) }
    SrAskDialog(ask, scope) { ask = null }
    SrFormFrame(state.loading, state.error, { scope.launch { state.reload() } }) {
        val group = state.group
        val currency = state.currency
        Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(s.space("m"))) {
            SrNotice(state.message, "sr-lead-message")
            Text(state.data["campaign"].obj()["title"].text(), fontSize = s.size("headline"), fontWeight = FontWeight.SemiBold, color = s.color("onSurface"))
            SrMuted(listOf(group["status_label"].text(), group["pickup_name"].text()).filter { it.isNotEmpty() }.joinToString(" · "))
            group["share_url"].text().takeIf { it.isNotEmpty() }?.let { LeaderLink(it, group["share"], onShare) }
            Spacer(Modifier.height(s.space("m")))
            SrBody(state.counts, Modifier.testTag("sr-lead-counts"))
            SrAmount(s.t("lead.commission"), state.commission, "sr-lead-commission", strong = true)
            SrTitle(s.t("lead.households"))
            if (state.households.isEmpty()) SrMuted(s.t("lead.households_empty"))
            state.households.forEach { h ->
                val id = h["id"].text()
                Card(Modifier.fillMaxWidth().padding(bottom = s.space("s")).testTag("sr-lead-household-$id"), shape = RoundedCornerShape(s.radius("medium"))) {
                    Column(Modifier.padding(s.space("m"))) {
                        Row {
                            SrBody(listOf(s.t("gb.order_number", "number" to h["number"]), h["name"].text()).filter { it.isNotEmpty() }.joinToString(" · "), Modifier.weight(1f), weight = FontWeight.SemiBold)
                            SrBody(s.money(h["commission"] ?: 0, currency))
                        }
                        SrMuted(listOf(if (h["delivery"] == "home") s.t("gb.home") else s.t("gb.pickup"), h["hold_label"].text()).filter { it.isNotEmpty() }.joinToString(" · "))
                        h["lines"].objs().forEach { SrBody("${it["name"].text()} × ${it["qty"].text()}") }
                        if (h["collected_at"] != null) SrBody(s.t("lead.collected", "date" to s.date(h["collected_at"])), color = s.color("success"))
                        if (h["can_mark_collected"].isTrue()) {
                            Spacer(Modifier.height(s.space("s")))
                            SrOutlinedButton(s.t("lead.mark"), "sr-lead-mark-$id", enabled = state.busy == null) {
                                ask = SrAsk(state.confirmText(h), s.t("lead.mark"), "sr-lead-confirm") { state.mark(h) }
                            }
                        }
                    }
                }
            }
        }
    }
}
