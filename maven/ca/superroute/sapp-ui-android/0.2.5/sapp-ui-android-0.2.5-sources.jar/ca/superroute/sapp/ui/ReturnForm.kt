package ca.superroute.sapp.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ca.superroute.sapp.SuperrouteException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** A file the app picked (the kit never opens a file picker or a camera itself). */
class SrPickedFile(val name: String, val bytes: ByteArray, val contentType: String? = null)

private const val B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

/** Standard base64 with padding (java.util.Base64 needs Android 8; the kit runs from Android 7). */
fun base64(bytes: ByteArray): String {
    val out = StringBuilder((bytes.size + 2) / 3 * 4)
    var i = 0
    while (i < bytes.size) {
        val b0 = bytes[i].toInt() and 0xFF
        val b1 = if (i + 1 < bytes.size) bytes[i + 1].toInt() and 0xFF else -1
        val b2 = if (i + 2 < bytes.size) bytes[i + 2].toInt() and 0xFF else -1
        out.append(B64[b0 shr 2])
        out.append(B64[((b0 and 3) shl 4) or (if (b1 < 0) 0 else b1 shr 4)])
        out.append(if (b1 < 0) '=' else B64[((b1 and 15) shl 2) or (if (b2 < 0) 0 else b2 shr 6)])
        out.append(if (b2 < 0) '=' else B64[b2 and 63])
        i += 3
    }
    return out.toString()
}

/** The rules of a return, read from the configuration answer (UI-KIT-SPEC.md §Return form); every decision testable on its own. */
class SrReturnRules(val config: Obj) {
    val types: List<Obj> get() = config["return_types"].objs()
    val reasons: List<Obj> get() = config["reasons"].objs()
    val other: Obj get() = config["other_channel"].obj()
    val uploadedLabel: Obj get() = config["uploaded_label"].obj()
    val contact: Obj get() = config["contact"].obj()

    private fun allows(source: Obj, type: Int) = source["allowed_return_types"].list().any { it.text() == "$type" }

    /** The channels offered for [type]: those allowing it, without a required form file field. */
    fun channelsFor(type: Int): List<Obj> = config["channels"].objs().filter { c ->
        allows(c, type) && formFields(c).none { it["type"] == "file" && it["required"].isTrue() }
    }

    fun otherAllowed(type: Int): Boolean = other["available"].isTrue() && allows(other, type)

    /** Types 1 and 2 must name a channel; 3 and 4 may. */
    fun channelRequired(type: Int): Boolean = type == 1 || type == 2

    fun channel(id: Any?): Obj? = if (id is Long) config["channels"].objs().firstOrNull { it["id"].text() == "$id" } else null

    fun formFields(channel: Obj?): List<Obj> = channel?.get("form").obj()["fields"].objs()

    /** The rules that apply: the channel's, the other carrier's, or the uploaded label's without a channel. */
    fun source(type: Int?, channelId: Any?): Obj {
        if (channelId == "other") return other
        channel(channelId)?.let { return it }
        return if (type == 3 || type == 4) uploadedLabel else emptyMap()
    }

    fun reasonRequired(type: Int?, channelId: Any?): Boolean = source(type, channelId)["requires_return_reason"].isTrue()

    /** 1 required, 2 optional, 3 not asked; a home pickup makes the address required. */
    fun pickupMode(type: Int?, channelId: Any?, homePickup: Boolean = false): Int =
        if (homePickup) 1 else source(type, channelId)["pickup_address_mode"].long()?.toInt() ?: 1

    /** 1 required, 2 optional, 3 not asked. */
    fun fileMode(type: Int?, channelId: Any?): Int {
        if (type == 3) return 1
        if (type != 4) return 3
        return channel(channelId)?.get("return_code_upload_mode").long()?.toInt() ?: 1
    }

    val acceptedExtensions: List<String>
        get() = (uploadedLabel["accepted_extensions"] as? List<*>)?.map { it.text().lowercase() } ?: listOf("pdf", "png", "jpg", "jpeg")

    /** Whether a file's name and size are accepted by `uploaded_label`. */
    fun fileAccepted(file: SrPickedFile): Boolean {
        val ext = if (file.name.contains('.')) file.name.substringAfterLast('.').lowercase() else ""
        val maxKb = uploadedLabel["max_size_kb"].decimal()
        return ext in acceptedExtensions && (maxKb == null || file.bytes.size.toBigDecimal() <= maxKb * 1024.toBigDecimal())
    }
}

private val PICKUP_FIELDS = listOf("pickup_address_1", "pickup_address_2", "pickup_city", "pickup_province", "pickup_country", "pickup_postcode")
private val OTHER_FIELDS = listOf("return_name", "return_address_1", "return_address_2", "return_city", "return_province", "return_country", "return_postcode")
internal val FIELD_LABELS = mapOf(
    "pickup_name" to "rform.name", "return_name" to "rform.name",
    "pickup_address_1" to "rform.address_1", "return_address_1" to "rform.address_1",
    "pickup_address_2" to "rform.address_2", "return_address_2" to "rform.address_2",
    "pickup_city" to "rform.city", "return_city" to "rform.city",
    "pickup_province" to "rform.province", "return_province" to "rform.province",
    "pickup_country" to "rform.country", "return_country" to "rform.country",
    "pickup_postcode" to "rform.postcode", "return_postcode" to "rform.postcode",
    "pickup_telephone" to "rform.phone", "email" to "rform.email",
)
private val OPTIONAL = setOf("pickup_address_2", "pickup_province", "return_address_2", "return_province")

/** Whether a form answer is given. */
internal fun answered(v: Any?): Boolean = v != null && !(v is String && v.isBlank()) && !(v is List<*> && v.isEmpty())

/** Places a server's 422 `errors` beside their fields; answers the text to show at the top, if any. */
internal fun placeErrors(env: SrEnv, e: SuperrouteException, errors: MutableMap<String, String>, skip: Set<String> = emptySet()): String {
    val body = env.errorBody(e)
    var placed = false
    body["errors"].obj().forEach { (field, value) ->
        val text = if (value is List<*>) value.joinToString(" ") { it.text() } else value.text()
        if (text.isNotEmpty() && field !in skip) {
            errors[field] = text
            placed = true
        }
    }
    val message = body["message"] as? String
    return if (!placed || message != null) message ?: env.t("common.error") else ""
}

/** The state of [ReturnForm] (UI-KIT-SPEC.md §Return form). */
class ReturnFormState(val env: SrEnv, val originalOrderId: Long? = null) {
    var loading by mutableStateOf(true)
        private set
    var loadError by mutableStateOf<Throwable?>(null)
        private set
    var rules by mutableStateOf<SrReturnRules?>(null)
        private set

    var type by mutableStateOf<Int?>(null)
        private set
    /** The chosen channel: its id (Long), `"other"`, or null. */
    var channelId by mutableStateOf<Any?>(null)
        private set
    var addressId by mutableStateOf<Long?>(null)
    var reasonId by mutableStateOf<Long?>(null)
    var homePickup by mutableStateOf(false)
        private set
    var file by mutableStateOf<SrPickedFile?>(null)
        private set
    val formData = mutableStateMapOf<String, Any?>()
    val text = mutableStateMapOf<String, String>()
    val errors = mutableStateMapOf<String, String>()

    var quote by mutableStateOf<Obj?>(null)
        private set
    var message by mutableStateOf<String?>(null)
        private set
    var sending by mutableStateOf(false)
        private set
    var created by mutableStateOf<Obj?>(null)
        private set

    fun v(field: String): String = text[field]?.trim() ?: ""
    fun set(field: String, value: String) { text[field] = value }

    val channel: Obj? get() = rules?.channel(channelId)

    suspend fun load() {
        loading = true
        loadError = null
        env.attempt {
            val r = SrReturnRules(env.api.platformAppReturnConfiguration().data())
            rules = r
            type = if (r.types.size == 1) r.types.first()["id"].long()?.toInt() else null
            channelId = null
            addressId = null
            reasonId = null
            homePickup = false
            file = null
            formData.clear()
            quote = null
            created = null
            if (v("pickup_name").isEmpty()) text["pickup_name"] = r.contact["name"].text()
        }.onFailure { loadError = it }
        loading = false
    }

    fun chooseType(type: Int) {
        val r = rules ?: return
        this.type = type
        chooseChannel(null)
        val channels = r.channelsFor(type)
        if (r.channelRequired(type) && channels.size == 1 && !r.otherAllowed(type)) chooseChannel(channels.first()["id"].long())
    }

    fun chooseChannel(id: Any?) {
        channelId = id
        formData.clear()
        homePickup = false
        quote = null
        val addresses = rules?.channel(id)?.get("addresses").objs()
        addressId = if (addresses?.size == 1) addresses.first()["id"].long() else null
        errors.clear()
    }

    fun chooseHomePickup(on: Boolean) {
        homePickup = on
        errors.remove("home_pickup")
    }

    /** What the fee quote depends on; null when the channel has no fee (§Return form 7). */
    val quoteInputs: List<Any?>?
        get() {
            val c = channel ?: return null
            if (c["fee"] == null) return null
            return listOf(c["id"], v("coupon_code"), homePickup, if (homePickup) v("pickup_postcode") else null, if (homePickup) v("pickup_country") else null)
        }

    /** Asks the fee quote for the current inputs (the composable asks a moment after the last change). */
    suspend fun askQuote() {
        val c = channel
        if (c == null || c["fee"] == null) {
            quote = null
            return
        }
        val request = buildMap<String, Any?> {
            put("return_channel_id", c["id"])
            if (v("coupon_code").isNotEmpty()) put("coupon_code", v("coupon_code"))
            if (homePickup) put("home_pickup", true)
            if (homePickup && v("pickup_postcode").isNotEmpty()) put("pickup_postcode", v("pickup_postcode"))
            if (homePickup && v("pickup_country").isNotEmpty()) put("pickup_country", v("pickup_country"))
        }.json()
        // The quote only informs; the create call decides and answers its own errors.
        val q = attempt { env.api.platformAppReturnFeeQuote(request).data() }.getOrNull() ?: return
        quote = q
        val home = q["home_pickup"]
        if (homePickup && home is Map<*, *> && home["available"] == false) {
            homePickup = false
            errors["home_pickup"] = home["message"].text()
        } else {
            errors.remove("home_pickup")
        }
        val status = q["coupon_status"]
        if (v("coupon_code").isNotEmpty() && status != null && status != "applied") errors["coupon_code"] = env.t("returns.coupon_invalid")
        else errors.remove("coupon_code")
    }

    /** Takes a picked file when `uploaded_label` accepts it. */
    fun pick(picked: SrPickedFile?) {
        picked ?: return
        if (rules?.fileAccepted(picked) == true) {
            file = picked
            errors.remove("self_label_file")
        } else {
            file = null
            errors["self_label_file"] = env.t("rform.file_invalid")
        }
    }

    val reason: Obj? get() = rules?.reasons?.firstOrNull { it["id"].text() == reasonId.text() && reasonId != null }

    /** Checks what the rules require; fills [errors] and answers whether the form may be sent. */
    fun validate(): Boolean {
        val r = rules ?: return false
        val type = type
        errors.clear()
        fun need(field: String, missing: Boolean) { if (missing) errors[field] = env.t("rform.required") }
        need("return_type", type == null)
        if (type == null) return false
        need("return_channel_id", r.channelRequired(type) && channelId == null)
        val c = channel
        if (c != null) {
            need("return_address_id", type <= 2 && addressId == null)
            if (c["reference_number_enabled"].isTrue() && type != 3) {
                need("reference_number", c["reference_number_required"].isTrue() && v("reference_number").isEmpty())
            }
            for (f in r.formFields(c)) {
                if (!f["required"].isTrue() || f["type"] == "file") continue
                need("form.${f["code"].text()}", !answered(formData[f["code"].text()]))
            }
        }
        if (channelId == "other") {
            need("custom_channel_name", v("custom_channel_name").isEmpty())
            OTHER_FIELDS.filter { it !in OPTIONAL }.forEach { need(it, v(it).isEmpty()) }
        }
        if (type == 3) {
            need("self_label_channel_name", v("self_label_channel_name").isEmpty())
            need("reference_number", v("reference_number").isEmpty())
        }
        if (r.fileMode(type, channelId) == 1) need("self_label_file", file == null)
        if (r.reasonRequired(type, channelId)) {
            need("return_reason_id", reasonId == null)
            if (reason?.get("requires_description").isTrue()) need("return_description", v("return_description").isEmpty())
        }
        need("pickup_name", v("pickup_name").isEmpty())
        if (r.pickupMode(type, channelId, homePickup) == 1) PICKUP_FIELDS.filter { it !in OPTIONAL }.forEach { need(it, v(it).isEmpty()) }
        return errors.isEmpty()
    }

    /** The create body. */
    fun body(): Obj {
        val r = rules!!
        val type = type!!
        val c = channel
        val pickupMode = r.pickupMode(type, channelId, homePickup)
        val body = linkedMapOf<String, Any?>("return_type" to type)
        if (originalOrderId != null) body["original_order_id"] = originalOrderId
        if (channelId != null) body["return_channel_id"] = channelId
        if (c != null && addressId != null) body["return_address_id"] = addressId
        body["pickup_name"] = v("pickup_name")
        if (v("pickup_telephone").isNotEmpty()) body["pickup_telephone"] = v("pickup_telephone")
        if (v("email").isNotEmpty()) body["email"] = v("email")
        if (homePickup) body["home_pickup"] = true
        if (pickupMode != 3) PICKUP_FIELDS.forEach { if (v(it).isNotEmpty()) body[it] = v(it) }
        if (v("reference_number").isNotEmpty() && (type == 3 || c?.get("reference_number_enabled").isTrue())) body["reference_number"] = v("reference_number")
        if (c != null && formData.isNotEmpty()) body["form_data"] = formData.toMap()
        if (channelId == "other") {
            body["custom_channel_name"] = v("custom_channel_name")
            OTHER_FIELDS.forEach { if (v(it).isNotEmpty()) body[it] = v(it) }
        }
        if (type == 3) body["self_label_channel_name"] = v("self_label_channel_name")
        val f = file
        if (f != null && r.fileMode(type, channelId) != 3) {
            body["self_label_file_base64"] = base64(f.bytes)
            body["self_label_file_name"] = f.name
        }
        if (r.reasonRequired(type, channelId)) {
            body["return_reason_id"] = reasonId
            if (v("return_description").isNotEmpty()) body["return_description"] = v("return_description")
        }
        if (c?.get("fee") != null && v("coupon_code").isNotEmpty()) body["coupon_code"] = v("coupon_code")
        return body
    }

    val currency: String?
        get() = ((quote?.get("fee") ?: channel?.get("fee")) as? Map<*, *>)?.get("currency") as? String

    /** Sends the return; answers the created return, or null (the errors are shown). */
    suspend fun submit(): Obj? {
        message = null
        if (!validate()) return null
        sending = true
        val result = env.attempt { env.api.platformAppCreateReturn(body().json()).data() }
        result.onSuccess { created = it }.onFailure { e ->
            if (e !is SuperrouteException || e.status != 422) {
                message = env.errorText(e)
                return@onFailure
            }
            val b = env.errorBody(e)
            when (b["code"] ?: e.code) {
                "INSUFFICIENT_BALANCE" -> message = env.t("returns.short_balance", "amount" to formatMoney(b["errors"].obj()["shortfall"], currency))
                "COUPON_INVALID" -> errors["coupon_code"] = env.t("returns.coupon_invalid")
                else -> message = placeErrors(env, e, errors, skip = setOf("reason")).ifEmpty { null }
            }
        }
        sending = false
        return result.getOrNull()
    }
}

/** Shows one custom form field (`text`, `textarea`, `number`, `email`, `date`, `select` / `radio`, `multiselect` / `checkbox`). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun SrCustomField(
    field: Obj,
    key: String,
    label: String,
    required: Boolean,
    tagPrefix: String,
    formData: MutableMap<String, Any?>,
    text: MutableMap<String, String>,
    errors: Map<String, String>,
    optionLabel: (Obj) -> String = { (it["name"] ?: it["value"]).text() },
    textTypes: Set<String> = setOf("text", "textarea", "number", "email", "date"),
) {
    val s = superroute()
    val options = field["options"].objs().map { it["value"].text() to optionLabel(it) }
    val errorKey = "form.$key"
    when (val type = field["type"]) {
        "select", "radio" -> SrChoice(label, "$tagPrefix-$errorKey", options, formData[key] as? String, { formData[key] = it }, required = required, error = errors[errorKey])
        "multiselect", "checkbox" -> {
            @Suppress("UNCHECKED_CAST") val chosen = (formData[key] as? List<String>) ?: emptyList()
            Column(Modifier.fillMaxWidth().padding(bottom = s.space("s"))) {
                SrMuted(if (required) "$label *" else label, small = true)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(s.space("xs"))) {
                    options.forEach { (value, name) ->
                        FilterChip(selected = value in chosen, label = { Text(name) }, modifier = Modifier.heightIn(min = 44.dp).testTag("$tagPrefix-$errorKey-$value"),
                            onClick = { formData[key] = if (value in chosen) chosen - value else chosen + value })
                    }
                }
                errors[errorKey]?.let { SrDanger(it) }
            }
        }
        else -> if (type in textTypes) {
            SrField(
                text["form.$key"] ?: "", { text["form.$key"] = it; formData[key] = it.trim() }, label, "$tagPrefix-$errorKey",
                required = required, error = errors[errorKey], multiline = type == "textarea",
                keyboard = when (type) { "number" -> KeyboardType.Decimal; "email" -> KeyboardType.Email; else -> KeyboardType.Text },
            )
        }
    }
}

/** The loading and load-error frame of a form. */
@Composable
internal fun SrFormFrame(loading: Boolean, error: Throwable?, onRetry: () -> Unit, content: @Composable () -> Unit) {
    val s = superroute()
    when {
        loading -> Column(Modifier.fillMaxWidth().padding(s.space("l")), horizontalAlignment = Alignment.CenterHorizontally) { CircularProgressIndicator(Modifier.testTag("sr-loading")) }
        error != null -> Column(Modifier.fillMaxWidth().padding(s.space("l")), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(s.env.errorText(error), modifier = Modifier.testTag("sr-error"), textAlign = TextAlign.Center)
            SrTextButton(s.t("common.retry"), "sr-retry", onClick = onRetry)
        }
        else -> content()
    }
}

/** Starts a return. Raises [onCreated] with the created return and [onCancel] for **Cancel**; never navigates. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReturnForm(
    originalOrderId: Long? = null,
    pickFile: (suspend () -> SrPickedFile?)? = null,
    onCreated: (Obj) -> Unit = {},
    onCancel: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    onError: ((SuperrouteException) -> Unit)? = null,
) {
    val s = superroute()
    val state = rememberLoaded(onError, originalOrderId, create = { ReturnFormState(it, originalOrderId) }) { load() }
    val scope = rememberCoroutineScope()
    val inputs = state.quoteInputs
    LaunchedEffect(state, inputs) {
        if (inputs == null) { state.askQuote(); return@LaunchedEffect }
        delay(400)
        state.askQuote()
    }
    SrFormFrame(state.loading, state.loadError, { scope.launch { state.load() } }) {
        val created = state.created
        if (created != null) {
            val code = created["return_code"]
            Text(
                if (code == null || code.text().isEmpty()) s.t("returns.awaiting_approval") else s.t("returns.created", "code" to code),
                modifier = Modifier.fillMaxWidth().padding(s.space("l")).testTag("sr-rform-created"), textAlign = TextAlign.Center, fontSize = s.size("title"),
            )
            return@SrFormFrame
        }
        val r = state.rules ?: return@SrFormFrame
        val type = state.type
        val channel = state.channel
        val e = state.errors
        @Composable fun field(name: String, label: String, required: Boolean = false, hint: String? = null, multiline: Boolean = false) =
            SrField(state.text[name] ?: "", { state.set(name, it) }, label, "sr-rform-$name", required = required, error = e[name], hint = hint, multiline = multiline)
        Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(s.space("m"))) {
            SrNotice(state.message, "sr-rform-message", danger = true)
            SrTitle(s.t("rform.type"))
            SrChips(r.types.map { it["id"].text() to (it["name"] ?: it["code"]).text() }, { it == type?.toString() }, "sr-rform-type") { state.chooseType(it.toInt()) }
            e["return_type"]?.let { SrDanger(it) }
            if (type != null) {
                val channels = r.channelsFor(type)
                if (channels.isNotEmpty() || r.otherAllowed(type)) {
                    SrTitle((r.config["guide"].obj()["platform"].obj()["title"] ?: s.t("rform.channel")).text())
                    val options = buildList<Pair<Any, String>> {
                        if (!r.channelRequired(type)) add("" to s.t("rform.none"))
                        channels.forEach { add((it["id"].long() ?: 0L) to it["name"].text()) }
                        if (r.otherAllowed(type)) add("other" to s.t("rform.other_channel"))
                    }
                    SrChoice(s.t("rform.channel"), "sr-rform-return_channel_id", options, state.channelId ?: if (r.channelRequired(type)) null else "",
                        { state.chooseChannel(if (it == "") null else it) }, required = r.channelRequired(type), error = e["return_channel_id"])
                }
                if (channel != null) {
                    val addresses = channel["addresses"].objs()
                    if (type <= 2 && addresses.size > 1) {
                        SrChoice(s.t("rform.return_address"), "sr-rform-return_address_id", addresses.map { (it["id"].long() ?: 0L) to it["name"].text() }, state.addressId,
                            { state.addressId = it }, required = true, error = e["return_address_id"])
                    }
                    if (channel["reference_number_enabled"].isTrue() && type != 3) {
                        field("reference_number", s.t("rform.reference"), channel["reference_number_required"].isTrue(), channel["reference_number_description"] as? String)
                    }
                    r.formFields(channel).forEach { f ->
                        val code = f["code"].text()
                        SrCustomField(f, code, (f["name"] ?: code).text(), f["required"].isTrue(), "sr-rform", state.formData, state.text, e)
                    }
                }
                if (state.channelId == "other") {
                    field("custom_channel_name", s.t("rform.carrier_name"), true)
                    SrTitle(s.t("rform.return_address"))
                    OTHER_FIELDS.forEach { field(it, s.t(FIELD_LABELS.getValue(it)), it !in OPTIONAL) }
                }
                if (type == 3) {
                    field("self_label_channel_name", s.t("rform.carrier_name"), true)
                    field("reference_number", s.t("rform.tracking_number"), true)
                }
                if (r.fileMode(type, state.channelId) != 3) {
                    SrTitle(s.t(if (type == 3) "rform.label_file" else "rform.code_file"))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SrOutlinedButton(s.t("rform.choose_file"), "sr-rform-pick", enabled = pickFile != null) { scope.launch { state.pick(pickFile?.invoke()) } }
                        Spacer(Modifier.width(s.space("s")))
                        Text(state.file?.name ?: "", modifier = Modifier.weight(1f).testTag("sr-rform-file-name"), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    val maxKb = r.uploadedLabel["max_size_kb"].decimal()
                    SrMuted(s.t("rform.file_hint", "types" to r.acceptedExtensions.joinToString(", "),
                        "size" to (maxKb?.divide(1024.toBigDecimal(), 0, java.math.RoundingMode.HALF_UP)?.toPlainString() ?: "10")), small = true)
                    e["self_label_file"]?.let { SrDanger(it, Modifier.testTag("sr-rform-file-error")) }
                }
                if (r.reasonRequired(type, state.channelId)) {
                    SrTitle(s.t("rform.reason"))
                    SrChoice(s.t("rform.reason"), "sr-rform-return_reason_id", r.reasons.map { (it["id"].long() ?: 0L) to it["name"].text() }, state.reasonId,
                        { state.reasonId = it }, required = true, error = e["return_reason_id"])
                    if (state.reason?.get("requires_description").isTrue()) field("return_description", s.t("rform.description"), true, multiline = true)
                }
                SrTitle(s.t("rform.pickup"))
                field("pickup_name", s.t("rform.name"), true)
                if (channel?.get("home_pickup") != null) {
                    SrSwitch(s.t("rform.home_pickup"), state.homePickup, "sr-rform-home_pickup") { state.chooseHomePickup(it) }
                    e["home_pickup"]?.takeIf { it.isNotEmpty() }?.let { SrDanger(it, Modifier.testTag("sr-rform-home-message")) }
                }
                val pickupMode = r.pickupMode(type, state.channelId, state.homePickup)
                if (pickupMode != 3) PICKUP_FIELDS.forEach { field(it, s.t(FIELD_LABELS.getValue(it)), pickupMode == 1 && it !in OPTIONAL) }
                field("pickup_telephone", s.t("rform.phone"), hint = r.contact["telephone"] as? String)
                field("email", s.t("rform.email"), hint = r.contact["email"] as? String)
                if (channel?.get("fee") != null) {
                    val fee = (state.quote?.get("fee") ?: channel["fee"]).obj()
                    val currency = fee["currency"]
                    SrTitle(s.t("rform.fee"))
                    SrAmount(s.t("rform.fee"), s.money(fee["amount"], currency), "sr-rform-fee-amount")
                    val discount = fee["discount"]
                    if (discount != null && (discount.decimal()?.signum() ?: 0) != 0) {
                        SrAmount(listOfNotNull(s.t("rform.discount"), fee["promotion_name"]?.text()).joinToString(" · "), s.money("-${discount.text()}", currency), "sr-rform-fee-discount")
                    }
                    val home = state.quote?.get("home_pickup")
                    if (state.homePickup && home is Map<*, *> && home["fee"] != null) SrAmount(s.t("rform.pickup_fee"), s.money(home["fee"], currency), "sr-rform-fee-pickup")
                    SrAmount(s.t("rform.total"), s.money(state.quote?.get("total") ?: fee["total"], currency), "sr-rform-fee-total", strong = true)
                    state.quote?.get("balance")?.let { SrAmount(s.t("rform.balance"), s.money(it, currency), "sr-rform-fee-balance") }
                    Spacer(Modifier.padding(s.space("xs")))
                    field("coupon_code", s.t("rform.coupon"))
                }
            }
            SrConfirmRow(s.t("rform.submit"), "sr-rform-submit", enabled = !state.sending && type != null, cancelTag = "sr-rform-cancel",
                onCancel = onCancel, cancelEnabled = !state.sending) {
                scope.launch { state.submit()?.let(onCreated) }
            }
        }
    }
}
