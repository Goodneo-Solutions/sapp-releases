package ca.superroute.sapp.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ca.superroute.sapp.SuperrouteException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.math.BigDecimal

/** A unit's symbol from its name in the configuration (`weight_kg` → kg, `dimension_inch` → in). */
fun unitSymbol(name: Any?): String = name.text().replaceFirst(Regex("^(weight|dimension)_"), "").let { if (it == "inch") "in" else it }

/** One package of the shipping order form, as typed. */
class SrPackageInput {
    var weight by mutableStateOf("")
    var length by mutableStateOf("")
    var width by mutableStateOf("")
    var height by mutableStateOf("")
    var quantity by mutableStateOf("1")
    var contents by mutableStateOf("")
    var value by mutableStateOf("")

    operator fun get(name: String): String = when (name) {
        "weight" -> weight; "length" -> length; "width" -> width; "height" -> height
        "quantity" -> quantity; "description" -> contents; "value" -> value; else -> ""
    }

    operator fun set(name: String, text: String) {
        when (name) {
            "weight" -> weight = text; "length" -> length = text; "width" -> width = text; "height" -> height = text
            "quantity" -> quantity = text; "description" -> contents = text; "value" -> value = text
        }
    }
}

/** A typed number (a decimal comma is read), or null. */
internal fun number(text: String): BigDecimal? = text.trim().replace(',', '.').toBigDecimalOrNull()

private fun positive(text: String) = (number(text)?.signum() ?: 0) > 0

/** The rules of a shipping order, read from the service configuration (UI-KIT-SPEC.md §Shipping order form). */
class SrShippingRules(val config: Obj) {
    val service: Obj get() = config["service"].obj()
    val warehouses: List<Obj> get() = config["warehouses"].objs()
    val addressBook: List<Obj> get() = config["address_book"].objs()
    val formBindings: List<Obj> get() = config["form_bindings"].objs()
    val offersWarehouse: Boolean get() = service["allow_warehouse_delivery"].isTrue()
    val offersPickup: Boolean get() = service["offer_pickup"].isTrue()
    val multiPackage: Boolean get() = service["support_multi_package"].isTrue()

    /** 0 actual, 1 volumetric, 2 billable; null when the service has no price plan (the weight is asked). */
    val weightMode: Int? get() = (service["weight_mode"] as? Number)?.toInt()
    val needsWeight: Boolean get() = weightMode != 1
    val needsDimensions: Boolean get() = weightMode == 1

    fun units(key: String): Map<Int, String> = config[key].obj().entries.mapNotNull { (k, v) ->
        k.toIntOrNull()?.let { it to unitSymbol(if (v is Map<*, *>) v["name"] else v) }
    }.toMap()

    fun defaultUnit(key: String, fallback: Int): Int = (config[key] as? Number)?.toInt() ?: fallback

    /** Whether a package carries the measures the price plan needs. */
    fun packageComplete(p: SrPackageInput): Boolean {
        if (needsWeight && !positive(p.weight)) return false
        if (needsDimensions && !(positive(p.length) && positive(p.width) && positive(p.height))) return false
        return true
    }
}

private val ADDRESS_FIELDS = listOf("name", "telephone", "email", "address_1", "address_2", "city", "province", "country", "postcode")
private val OPTIONAL_ADDRESS = setOf("email", "address_2")
private val ADDRESS_LABELS = mapOf(
    "name" to "rform.name", "telephone" to "rform.phone", "email" to "rform.email", "address_1" to "rform.address_1",
    "address_2" to "rform.address_2", "city" to "rform.city", "province" to "rform.province", "country" to "rform.country",
    "postcode" to "rform.postcode",
)
private val SUPPORTED = setOf("text", "textarea", "number", "email", "date", "datetime", "select", "radio", "multiselect", "checkbox")

/** The state of [ShippingOrderForm] (UI-KIT-SPEC.md §Shipping order form). */
class ShippingOrderFormState(val env: SrEnv, val initialServiceCode: String? = null) {
    var loading by mutableStateOf(true)
        private set
    var loadError by mutableStateOf<Throwable?>(null)
        private set
    var services by mutableStateOf<List<Obj>>(emptyList())
        private set
    var serviceCode by mutableStateOf<String?>(null)
        private set
    var rules by mutableStateOf<SrShippingRules?>(null)
        private set

    var origin by mutableStateOf<String?>(null)
    var warehouseId by mutableStateOf<Long?>(null)
    var weightUnit by mutableStateOf(2)
    var dimensionUnit by mutableStateOf(2)
    val packages = mutableStateListOf<SrPackageInput>()
    val text = mutableStateMapOf<String, String>()
    val formData = mutableStateMapOf<String, Any?>()
    val errors = mutableStateMapOf<String, String>()

    var estimate by mutableStateOf<Obj?>(null)
        private set
    var message by mutableStateOf<String?>(null)
        private set
    var sending by mutableStateOf(false)
        private set
    var created by mutableStateOf<Obj?>(null)
        private set

    fun v(field: String): String = text[field]?.trim() ?: ""
    fun set(field: String, value: String) { text[field] = value }

    /** A service's name in the app's language, else English. */
    fun serviceName(service: Obj): String = service["name"].obj().let { (it[env.language] ?: it["en"] ?: service["service_code"]).text() }

    /** A field's or option's label: `display_name` in the app's language, else `name`. */
    fun label(item: Obj): String = item["display_name"].obj().let { (it[env.language] ?: it["en"] ?: item["name"] ?: item["value"] ?: item["code"]).text() }

    suspend fun load() {
        loading = true
        loadError = null
        rules = null
        created = null
        env.attempt {
            var code = initialServiceCode
            if (code == null) {
                services = env.api.customerShippingOrderServices().data()["services"].objs()
                if (services.size == 1) code = services.first()["service_code"].text()
            }
            if (code != null) loadService(code)
        }.onFailure { loadError = it }
        loading = false
    }

    suspend fun chooseService(code: String) {
        loading = true
        env.attempt { loadService(code) }.onFailure { loadError = it }
        loading = false
    }

    private suspend fun loadService(code: String) {
        val r = SrShippingRules(env.api.customerShippingOrderServiceConfig(code).data())
        serviceCode = code
        rules = r
        origin = when {
            r.offersWarehouse && !r.offersPickup -> "warehouse"
            r.offersPickup && !r.offersWarehouse -> "pickup"
            else -> null
        }
        warehouseId = if (r.warehouses.size == 1) r.warehouses.first()["id"].long() else null
        weightUnit = r.defaultUnit("default_weight_unit", 2)
        dimensionUnit = r.defaultUnit("default_dimension_unit", 2)
        packages.clear()
        packages.add(SrPackageInput())
        formData.clear()
        val saved = r.config["saved_form_answers"].obj()
        for (b in r.formBindings) {
            val id = b["form_id"].text()
            saved[id].obj().forEach { (code, value) ->
                formData["$id.$code"] = value
                if (value is String) text["form.$id.$code"] = value
            }
        }
        estimate = null
        errors.clear()
    }

    /** Fills the sender or recipient from a saved address. */
    fun useSaved(side: String, entry: Obj) {
        ADDRESS_FIELDS.forEach { text["${side}_$it"] = entry[it].text() }
    }

    fun addPackage() { packages.add(SrPackageInput()) }
    fun removePackage(i: Int) { packages.removeAt(i) }

    val estimateReady: Boolean
        get() {
            val r = rules ?: return false
            if (origin == null) return false
            if (origin == "warehouse" && warehouseId == null) return false
            if (v("delivery_postcode").isEmpty() || v("delivery_country").isEmpty()) return false
            return packages.isNotEmpty() && packages.all(r::packageComplete)
        }

    private fun pkg(p: SrPackageInput, forCreate: Boolean = false): Obj = buildMap {
        put("weight", number(p.weight) ?: BigDecimal.ZERO)
        number(p.length)?.let { put("length", it) }
        number(p.width)?.let { put("width", it) }
        number(p.height)?.let { put("height", it) }
        put("weight_unit", weightUnit)
        put("dimension_unit", dimensionUnit)
        put("quantity", (number(p.quantity) ?: BigDecimal.ONE).toInt())
        if (forCreate && p.contents.isNotBlank()) put("description", p.contents.trim())
        if (forCreate) number(p.value)?.let { put("value", it) }
    }

    /** The estimate request, or null while the inputs are not complete (§Shipping order form 6). */
    fun estimateRequest(): Obj? {
        if (!estimateReady) return null
        return buildMap {
            put("origin_type", origin)
            if (origin == "warehouse") put("warehouse_id", warehouseId)
            if (origin == "pickup" && v("pickup_postcode").isNotEmpty()) put("pickup_postcode", v("pickup_postcode"))
            if (origin == "pickup" && v("pickup_country").isNotEmpty()) put("pickup_country", v("pickup_country"))
            put("delivery_postcode", v("delivery_postcode"))
            put("delivery_country", v("delivery_country"))
            put("packages", packages.map { pkg(it) })
            if (v("coupon_code").isNotEmpty()) put("coupon_code", v("coupon_code"))
        }
    }

    /** Asks the estimate for [request] (the composable asks a moment after the last change). */
    suspend fun askEstimate(request: Obj? = estimateRequest()) {
        if (request == null) {
            estimate = null
            return
        }
        val code = serviceCode ?: return
        // The estimate only informs; the create call decides and answers its own errors.
        val e = attempt { env.api.customerShippingOrderEstimatePrice(code, request.json()).data() }.getOrNull() ?: return
        estimate = e
        val promotion = e["promotion"]
        if (v("coupon_code").isNotEmpty() && (promotion !is Map<*, *> || promotion["auto_applied"] == true)) errors["coupon_code"] = env.t("returns.coupon_invalid")
        else errors.remove("coupon_code")
    }

    val refused: Boolean get() = estimate?.get("refused").isTrue()

    /** Whether a binding asks its required fields: when required, or once any of its fields is answered. */
    fun bindingRequired(b: Obj): Boolean {
        val id = b["form_id"].text()
        return b["is_required"].isTrue() || b["fields"].objs().any { answered(formData["$id.${it["code"].text()}"]) }
    }

    fun validate(): Boolean {
        val r = rules ?: return false
        errors.clear()
        fun need(field: String, missing: Boolean) { if (missing) errors[field] = env.t("rform.required") }
        need("origin_type", origin == null)
        if (origin == "warehouse") need("warehouse_id", warehouseId == null)
        for (side in listOfNotNull(if (origin == "pickup") "pickup" else null, "delivery")) {
            ADDRESS_FIELDS.filter { it !in OPTIONAL_ADDRESS }.forEach { need("${side}_$it", v("${side}_$it").isEmpty()) }
        }
        packages.forEachIndexed { i, p ->
            if (r.needsWeight) need("package.$i.weight", !positive(p.weight))
            if (r.needsDimensions) listOf("length", "width", "height").forEach { need("package.$i.$it", !positive(p[it])) }
        }
        for (b in r.formBindings) {
            if (!bindingRequired(b)) continue
            val id = b["form_id"].text()
            for (f in b["fields"].objs()) {
                if (f["required"].isTrue() && f["type"] in SUPPORTED) need("form.$id.${f["code"].text()}", !answered(formData["$id.${f["code"].text()}"]))
            }
        }
        return errors.isEmpty()
    }

    fun body(): Obj {
        val r = rules!!
        val body = linkedMapOf<String, Any?>("origin_type" to origin)
        if (origin == "warehouse") body["warehouse_id"] = warehouseId
        for (side in listOfNotNull(if (origin == "pickup") "pickup" else null, "delivery")) {
            ADDRESS_FIELDS.forEach { if (v("${side}_$it").isNotEmpty()) body["${side}_$it"] = v("${side}_$it") }
        }
        body["package"] = packages.map { pkg(it, forCreate = true) }
        if (v("reference").isNotEmpty()) body["reference"] = v("reference")
        if (v("note").isNotEmpty()) body["note"] = v("note")
        if (v("coupon_code").isNotEmpty()) body["coupon_code"] = v("coupon_code")
        val forms = linkedMapOf<String, MutableMap<String, Any?>>()
        for (b in r.formBindings) {
            val id = b["form_id"].text()
            for (f in b["fields"].objs()) {
                val value = formData["$id.${f["code"].text()}"]
                if (answered(value)) forms.getOrPut(id) { linkedMapOf() }[f["code"].text()] = value
            }
        }
        if (forms.isNotEmpty()) body["form_data"] = forms
        return body
    }

    /** Places the order (one press sends one order); answers it, or null (the errors are shown). */
    suspend fun submit(): Obj? {
        if (sending) return null
        message = null
        if (!validate()) return null
        val code = serviceCode ?: return null
        sending = true
        val result = env.attempt { env.api.customerShippingOrderCreate(code, body().json()).data() }
        result.onSuccess { created = it }.onFailure { e ->
            message = if (e is SuperrouteException && e.status == 422) placeErrors(env, e, errors).ifEmpty { null } else env.errorText(e)
        }
        sending = false
        return result.getOrNull()
    }
}

/** Places a shipping order. Raises [onCreated] with the order (`id`, `status`, `total_price`, `tracking_number`); paying is the app's step. */
@Composable
fun ShippingOrderForm(serviceCode: String? = null, onCreated: (Obj) -> Unit = {}, onCancel: (() -> Unit)? = null, modifier: Modifier = Modifier, onError: ((SuperrouteException) -> Unit)? = null) {
    val s = superroute()
    val state = rememberLoaded(onError, serviceCode, create = { ShippingOrderFormState(it, serviceCode) }) { load() }
    val scope = rememberCoroutineScope()
    val request = state.estimateRequest()
    LaunchedEffect(state, request) {
        if (request != null) delay(400)
        state.askEstimate(request)
    }
    SrFormFrame(state.loading, state.loadError, { scope.launch { state.load() } }) {
        state.created?.let { created ->
            Text(s.t("sform.created", "id" to created["id"]), modifier = Modifier.fillMaxWidth().padding(s.space("l")).testTag("sr-sform-created"),
                textAlign = TextAlign.Center, fontSize = s.size("title"))
            return@SrFormFrame
        }
        val r = state.rules
        if (r == null) {
            if (state.services.isEmpty()) {
                SrBody(s.t("sform.no_services"), Modifier.padding(s.space("l")).testTag("sr-sform-no-services"))
                return@SrFormFrame
            }
            Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(s.space("m"))) {
                SrTitle(s.t("sform.service"))
                state.services.forEach { service ->
                    val code = service["service_code"].text()
                    SrBody(state.serviceName(service), Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { scope.launch { state.chooseService(code) } }
                        .padding(vertical = s.space("m")).testTag("sr-sform-service-$code"))
                }
            }
            return@SrFormFrame
        }
        val e = state.errors
        @Composable fun field(name: String, label: String, required: Boolean = false, multiline: Boolean = false, numeric: Boolean = false, m: Modifier = Modifier.fillMaxWidth()) =
            SrField(state.text[name] ?: "", { state.set(name, it) }, label, "sr-sform-$name", required = required, error = e[name], multiline = multiline,
                keyboard = if (numeric) KeyboardType.Decimal else KeyboardType.Text, modifier = m)
        @Composable fun address(side: String) {
            if (r.addressBook.isNotEmpty()) {
                SrChoice(s.t("sform.saved_address"), "sr-sform-$side-saved", r.addressBook.mapIndexed { i, a -> i to (a["label"] ?: a["name"]).text() }, null,
                    { state.useSaved(side, r.addressBook[it]) })
            }
            ADDRESS_FIELDS.forEach { field("${side}_$it", s.t(ADDRESS_LABELS.getValue(it)), it !in OPTIONAL_ADDRESS) }
        }
        val weightUnits = r.units("weight_units")
        val dimensionUnits = r.units("dimension_units")
        Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(s.space("m"))) {
            SrNotice(state.message, "sr-sform-message", danger = true)
            SrTitle(s.t("sform.origin"))
            SrChips(
                listOfNotNull(
                    if (r.offersWarehouse) "warehouse" to s.t("sform.origin_warehouse") else null,
                    if (r.offersPickup) "pickup" to s.t("sform.origin_pickup") else null,
                ),
                { it == state.origin }, "sr-sform-origin",
            ) { state.origin = it }
            e["origin_type"]?.let { SrDanger(it) }
            if (state.origin == "warehouse" && r.warehouses.size > 1) {
                SrChoice(s.t("sform.warehouse"), "sr-sform-warehouse_id", r.warehouses.map { (it["id"].long() ?: 0L) to it["name"].text() }, state.warehouseId,
                    { state.warehouseId = it }, required = true, error = e["warehouse_id"])
            }
            if (state.origin == "pickup") {
                SrTitle(s.t("sform.sender"))
                address("pickup")
            }
            SrTitle(s.t("sform.recipient"))
            address("delivery")
            SrTitle(s.t("sform.packages"))
            Row {
                SrChoice(s.t("sform.weight_unit"), "sr-sform-weight_unit", weightUnits.toList(), state.weightUnit, { state.weightUnit = it }, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(s.space("s")))
                SrChoice(s.t("sform.dimension_unit"), "sr-sform-dimension_unit", dimensionUnits.toList(), state.dimensionUnit, { state.dimensionUnit = it }, modifier = Modifier.weight(1f))
            }
            state.packages.forEachIndexed { i, p ->
                @Composable fun measure(name: String, label: String, required: Boolean, numeric: Boolean, m: Modifier) =
                    SrField(p[name], { p[name] = it }, label, "sr-sform-package.$i.$name", required = required, error = e["package.$i.$name"],
                        keyboard = if (numeric) KeyboardType.Decimal else KeyboardType.Text, modifier = m)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SrBody(s.t("sform.package", "n" to i + 1), Modifier.weight(1f), weight = FontWeight.SemiBold)
                    if (r.multiPackage && state.packages.size > 1) SrTextButton(s.t("sform.remove_package"), "sr-sform-remove-$i") { state.removePackage(i) }
                }
                Row {
                    measure("weight", "${s.t("sform.weight")} (${weightUnits[state.weightUnit] ?: ""})", r.needsWeight, true, Modifier.weight(1f))
                    Spacer(Modifier.width(s.space("s")))
                    measure("quantity", s.t("sform.quantity"), false, true, Modifier.weight(1f))
                }
                Row {
                    listOf("length", "width", "height").forEachIndexed { k, n ->
                        if (k > 0) Spacer(Modifier.width(s.space("s")))
                        measure(n, "${s.t("sform.$n")} (${dimensionUnits[state.dimensionUnit] ?: ""})", r.needsDimensions, true, Modifier.weight(1f))
                    }
                }
                Row {
                    measure("description", s.t("sform.contents"), false, false, Modifier.weight(1f))
                    Spacer(Modifier.width(s.space("s")))
                    measure("value", s.t("sform.value"), false, true, Modifier.weight(1f))
                }
            }
            if (r.multiPackage) SrTextButton(s.t("sform.add_package"), "sr-sform-add") { state.addPackage() }
            r.formBindings.forEach { b ->
                SrTitle(b["form_name"].text())
                val required = state.bindingRequired(b)
                val id = b["form_id"].text()
                b["fields"].objs().forEach { f ->
                    if (f["type"] in SUPPORTED) {
                        SrCustomField(f, "$id.${f["code"].text()}", state.label(f), required && f["required"].isTrue(), "sr-sform", state.formData, state.text, e,
                            optionLabel = state::label, textTypes = setOf("text", "textarea", "number", "email", "date", "datetime"))
                    }
                }
            }
            Spacer(Modifier.padding(s.space("xs")))
            field("reference", s.t("sform.reference"))
            field("note", s.t("sform.note"), multiline = true)
            SrTitle(s.t("sform.estimate"))
            val est = state.estimate
            if (est == null) {
                SrMuted(s.t("sform.estimate_hint"), Modifier.testTag("sr-sform-estimate-hint"))
            } else {
                val currency = est["currency"]
                val promotion = est["promotion"] as? Map<*, *>
                if (est["refused"].isTrue()) SrDanger((est["refusal_message"] ?: s.t("sform.refused")).text(), Modifier.testTag("sr-sform-refused"))
                if (est["needs_manual_quote"].isTrue()) SrBody(s.t("sform.manual_quote"), Modifier.testTag("sr-sform-manual"))
                SrAmount(s.t("sform.shipping_fee"), s.money(est["shipping_fee_total"] ?: est["shipping_fee"], currency), "sr-sform-shipping")
                if (est["pickup_fee"] != null) SrAmount(s.t("sform.pickup_fee"), s.money(est["pickup_fee"], currency), "sr-sform-pickup")
                val surcharges = est["surcharges_total"]
                if (surcharges != null && (surcharges.decimal()?.signum() ?: 1) != 0) SrAmount(s.t("sform.surcharges"), s.money(surcharges, currency), "sr-sform-surcharges")
                SrAmount(s.t("sform.tax"), s.money(est["tax"].obj()["total_tax"] ?: 0, currency), "sr-sform-tax")
                if (promotion != null && promotion["total_discount"] != null) {
                    SrAmount(listOfNotNull(s.t("rform.discount"), promotion["promotion_name"]?.text()).joinToString(" · "),
                        s.money("-${promotion["total_discount"].text()}", currency), "sr-sform-discount")
                }
                SrAmount(s.t("rform.total"), s.money(promotion?.get("new_total_with_tax") ?: est["total"], currency), "sr-sform-total", strong = true)
            }
            Spacer(Modifier.padding(s.space("xs")))
            field("coupon_code", s.t("rform.coupon"))
            SrConfirmRow(s.t("sform.submit"), "sr-sform-submit", enabled = !state.sending && !state.refused, cancelTag = "sr-sform-cancel",
                onCancel = onCancel, cancelEnabled = !state.sending) {
                scope.launch { state.submit()?.let(onCreated) }
            }
        }
    }
}
