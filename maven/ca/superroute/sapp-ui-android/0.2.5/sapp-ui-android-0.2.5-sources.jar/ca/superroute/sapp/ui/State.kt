package ca.superroute.sapp.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.serialization.json.JsonElement

/** Rethrows cancellation; answers every other failure. */
internal inline fun <T> attempt(block: () -> T): Result<T> = try {
    Result.success(block())
} catch (e: CancellationException) {
    throw e
} catch (e: Throwable) {
    Result.failure(e)
}

/** As [attempt], and a failure is reported to the component's host ([SrEnv.report]) once. */
internal inline fun <T> SrEnv.attempt(block: () -> T): Result<T> = ca.superroute.sapp.ui.attempt(block).onFailure { report(it) }

/** A paged list whose failed loads are reported through this environment. */
internal fun SrEnv.pagedList(itemsKey: String = "items", load: suspend (page: Long) -> JsonElement): SrPagedList =
    SrPagedList(itemsKey, load).also { it.reportTo = this }

/** Pages of a list answer (`data.items` + `pagination.has_more`, or `current_page < last_page`). */
class SrPagedList(private val itemsKey: String = "items", private val load: suspend (page: Long) -> JsonElement) {
    val items = mutableStateListOf<Obj>()
    var data: Obj by mutableStateOf(emptyMap())
    var page: Long = 0
        private set
    var hasMore by mutableStateOf(true)
        private set
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<Throwable?>(null)
        private set

    /** Where a failed load is reported (the component's environment), or nowhere. */
    internal var reportTo: SrEnv? = null

    suspend fun next() {
        if (loading || !hasMore) return
        loading = true
        error = null
        attempt {
            val body = load(page + 1).data()
            data = body
            items.addAll(body[itemsKey].objs())
            page++
            val pagination = body["pagination"].obj()
            val current = pagination["current_page"].long()
            val last = pagination["last_page"].long()
            hasMore = pagination["has_more"].isTrue() || (current != null && last != null && current < last)
        }.onFailure { error = it; reportTo?.report(it) }
        loading = false
    }

    suspend fun reset() {
        items.clear()
        data = emptyMap()
        page = 0
        hasMore = true
        loading = false
        next()
    }

    /** Replaces the row with [id] (`id` compared as text). */
    fun replace(id: Any?, change: (Obj) -> Obj) {
        val i = items.indexOfFirst { it["id"].text() == id.text() }
        if (i >= 0) items[i] = change(items[i])
    }
}

/** One answer's `data`, loaded and reloaded (the shared frame of detail components). */
open class SrOneAnswer(protected val fetch: suspend () -> JsonElement) {
    /** As the primary constructor; a failed load is reported through [env]. */
    internal constructor(env: SrEnv, fetch: suspend () -> JsonElement) : this(fetch) {
        reportTo = env
    }

    /** Where a failed load is reported (the component's environment), or nowhere. */
    internal var reportTo: SrEnv? = null

    var data by mutableStateOf<Obj?>(null)
    var error by mutableStateOf<Throwable?>(null)
        protected set
    var loading by mutableStateOf(true)
        protected set

    open suspend fun reload() {
        loading = true
        error = null
        attempt { data = fetch().data() }.onFailure { error = it; reportTo?.report(it) }
        loading = false
    }
}
