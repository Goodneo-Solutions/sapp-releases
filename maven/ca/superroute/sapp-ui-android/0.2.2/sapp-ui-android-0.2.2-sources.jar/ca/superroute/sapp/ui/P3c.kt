package ca.superroute.sapp.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ca.superroute.sapp.SuperrouteException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.DateFormat

/** An amount from the API in whole cents, read from its decimal text (never through floating-point arithmetic). */
fun centsOf(amount: Any?): Long {
    var text = (amount ?: 0).text().trim()
    val negative = text.startsWith("-")
    if (negative) text = text.substring(1)
    val parts = text.split('.')
    val whole = parts[0].ifEmpty { "0" }.toLongOrNull() ?: 0
    val fraction = if (parts.size > 1) parts[1] else ""
    var cents = whole * 100 + (fraction.padEnd(2, '0').substring(0, 2).toLongOrNull() ?: 0)
    if (fraction.length > 2 && (fraction[2].digitToIntOrNull() ?: 0) >= 5) cents++
    return if (negative) -cents else cents
}

/** Cents back as the decimal text [formatMoney] takes. */
fun centsText(cents: Long): String {
    val abs = kotlin.math.abs(cents)
    return "${if (cents < 0) "-" else ""}${abs / 100}.${(abs % 100).toString().padStart(2, '0')}"
}

/** A store's rating line (`mall.reviews`), hidden at 0 reviews. */
private fun SrEnv.rating(store: Obj): String? {
    val count = store["rating_count"].long() ?: 0
    return if (count > 0) t("mall.reviews", "rating" to store["rating_avg"], "count" to count) else null
}

private fun place(item: Obj): String = listOf(item["address"].text(), item["city"].text()).filter { it.isNotEmpty() }.joinToString(", ")

@Composable
private fun Price(item: Obj, tag: String? = null) {
    val s = superroute()
    val currency = item["currency"]
    Row(horizontalArrangement = Arrangement.spacedBy(s.space("xs"))) {
        SrBody(s.money(item["price"], currency), if (tag != null) Modifier.testTag(tag) else Modifier, weight = FontWeight.SemiBold)
        if (item["on_sale"].isTrue() && item["list_price"] != null) SrBody(s.money(item["list_price"], currency), color = s.color("muted"), strike = true)
    }
}

/** Chips on one scrolling row, **All** first. */
@Composable
private fun <T> ChipRow(options: List<Pair<T?, String>>, selected: T?, tag: (T?) -> String, onChoose: (T?) -> Unit) {
    val s = superroute()
    LazyRow(Modifier.fillMaxWidth().height(56.dp), horizontalArrangement = Arrangement.spacedBy(s.space("xs")), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = s.space("m"))) {
        items(options) { (value, label) ->
            FilterChip(selected = selected == value, onClick = { onChoose(value) }, label = { Text(label) }, modifier = Modifier.heightIn(min = 44.dp).testTag(tag(value)))
        }
    }
}

/** A search field that asks [onSearch] when the person stops typing or submits. */
@Composable
private fun SearchField(value: String, onValue: (String) -> Unit, hint: String, tag: String, onSearch: suspend () -> Unit) {
    val s = superroute()
    val scope = rememberCoroutineScope()
    var typed by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(typed) {
        if (typed == null) return@LaunchedEffect
        delay(400)
        onSearch()
    }
    OutlinedTextField(
        value = value, onValueChange = { onValue(it); typed = it }, singleLine = true, label = { Text(hint) },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { typed = null; scope.launch { onSearch() } }),
        modifier = Modifier.fillMaxWidth().padding(s.space("m")).testTag(tag),
    )
}

// ---------------------------------------------------------------------------------------------------------- directory

/** The state of [StoreDirectory] (UI-KIT-SPEC.md §Store directory). */
class StoreDirectoryState(val env: SrEnv) {
    var search by mutableStateOf("")
    var type by mutableStateOf<String?>(null)
        private set
    var types by mutableStateOf<List<Obj>>(emptyList())
        private set
    var list by mutableStateOf(newList())
        private set

    private fun newList(): SrPagedList {
        val q = search.trim().ifEmpty { null }
        val t = type
        return SrPagedList("stores") { page -> env.api.platformAppMallStores(q = q, type = t, page = page) }
    }

    suspend fun reload() {
        list = newList()
        list.reset()
        val facets = list.data["facets"].obj()["types"].objs()
        if (facets.isNotEmpty()) types = facets
    }

    suspend fun choose(type: String?) {
        this.type = type
        reload()
    }

    /** The second line of a store: type, rating and address. */
    fun details(store: Obj): String = listOfNotNull(store["store_type_label"].text().ifEmpty { null }, env.rating(store), place(store).ifEmpty { null }).joinToString("\n")
}

/** The mall's store directory. [onOpen] gets a store's slug. */
@Composable
fun StoreDirectory(onOpen: (slug: String) -> Unit = {}, modifier: Modifier = Modifier) {
    val s = superroute()
    val state = rememberLoaded(create = ::StoreDirectoryState) { reload() }
    val scope = rememberCoroutineScope()
    val list = state.list
    val listState = rememberLazyListState()
    val nearEnd by remember { derivedStateOf { listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index?.let { it >= listState.layoutInfo.totalItemsCount - 3 } == true } }
    LaunchedEffect(nearEnd, list) { if (nearEnd && list.hasMore && !list.loading && list.items.isNotEmpty()) list.next() }
    Column(modifier.fillMaxSize()) {
        SearchField(state.search, { state.search = it }, s.t("mall.search"), "sr-mall-search") { state.reload() }
        if (state.types.isNotEmpty()) {
            ChipRow(listOf<Pair<String?, String>>(null to s.t("mall.all")) + state.types.map { it["type"].text() to (it["label"] ?: it["type"]).text() },
                state.type, { "sr-mall-type-${it ?: "all"}" }) { scope.launch { state.choose(it) } }
        }
        SrStateView(list.loading, list.error, list.items.isEmpty(), s.t("mall.empty"), { scope.launch { state.reload() } }) {
            LazyColumn(Modifier.fillMaxSize(), state = listState) {
                items(list.items) { store ->
                    Row(
                        Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { onOpen(store["slug"].text()) }.padding(horizontal = s.space("m"), vertical = s.space("s"))
                            .testTag("sr-store-${store["slug"].text()}"),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        SrImage(store["logo_url"], Modifier.size(48.dp))
                        Spacer(Modifier.width(s.space("m")))
                        Column(Modifier.weight(1f)) {
                            SrBody(store["name"].text())
                            state.details(store).takeIf { it.isNotEmpty() }?.let { SrMuted(it, small = true) }
                        }
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------- store page

/** The state of [StorePage] (UI-KIT-SPEC.md §Store page). */
class StorePageState(val env: SrEnv, val slug: String) {
    var loading by mutableStateOf(true)
        private set
    var error by mutableStateOf<Throwable?>(null)
        private set
    var data by mutableStateOf<Obj>(emptyMap())
        private set
    var cart by mutableStateOf<Obj?>(null)
        private set
    var category by mutableStateOf<Long?>(null)
        private set
    var search by mutableStateOf("")

    suspend fun reload() {
        loading = true
        error = null
        attempt { data = env.api.platformAppStore(slug, q = search.trim().ifEmpty { null }, cat = category).data() }.onFailure { error = it }
        // Without a cart the page still shows; the bar stays hidden.
        cart = attempt { env.api.platformAppStoreCart(slug).data() }.getOrNull()
        loading = false
    }

    suspend fun choose(category: Long?) {
        this.category = category
        reload()
    }

    val store: Obj get() = data["store"].obj()
    val closed: Boolean get() = data["accepting_orders"] == false
    val categories: List<Obj> get() = data["categories"].objs().filter { it["parent_id"] == null }
    val sections: List<Obj> get() = data["sections"].objs()
    val cartCount: Long get() = cart?.get("count").long() ?: 0
    val cartLabel: String get() = env.t("store.view_cart", "count" to cartCount, "amount" to formatMoney(cart?.get("subtotal"), cart?.get("currency") as? String))
}

/** One store's page: its menu, search, categories and the cart bar. */
@Composable
fun StorePage(slug: String, onOpenProduct: (slug: String, productId: Long) -> Unit = { _, _ -> }, onOpenCart: (slug: String) -> Unit = {}, modifier: Modifier = Modifier) {
    val s = superroute()
    val state = rememberLoaded(slug, create = { StorePageState(it, slug) }) { reload() }
    val scope = rememberCoroutineScope()
    SrStateView(state.loading, state.error, state.data.isEmpty(), "", { scope.launch { state.reload() } }) {
        val store = state.store
        Column(modifier.fillMaxSize()) {
            LazyColumn(Modifier.weight(1f)) {
                item {
                    if (store["cover_url"].text().isNotEmpty()) SrImage(store["cover_url"], Modifier.fillMaxWidth().height(160.dp))
                    Row(Modifier.fillMaxWidth().padding(s.space("m")), verticalAlignment = Alignment.CenterVertically) {
                        SrImage(store["logo_url"], Modifier.size(48.dp))
                        Spacer(Modifier.width(s.space("m")))
                        Column(Modifier.weight(1f)) {
                            Text(store["name"].text(), style = s.figureStyle())
                            listOfNotNull(s.env.rating(store), place(store).ifEmpty { null }).joinToString("\n").takeIf { it.isNotEmpty() }?.let { SrMuted(it, small = true) }
                        }
                    }
                    if (state.closed) SrDanger(s.t("store.closed"), Modifier.padding(horizontal = s.space("m")).testTag("sr-store-closed"))
                    SearchField(state.search, { state.search = it }, s.t("store.search"), "sr-store-search") { state.reload() }
                    if (state.categories.isNotEmpty()) {
                        ChipRow(listOf<Pair<Long?, String>>(null to s.t("mall.all")) + state.categories.map { it["id"].long() to it["name"].text() },
                            state.category, { "sr-store-cat-${it ?: "all"}" }) { scope.launch { state.choose(it) } }
                    }
                }
                state.sections.forEach { section ->
                    item {
                        Text((section["label"] ?: s.t("store.other")).text(), style = s.figureStyle(),
                            modifier = Modifier.padding(start = s.space("m"), end = s.space("m"), top = s.space("l"), bottom = s.space("xs")))
                    }
                    items(section["items"].objs()) { item ->
                        val available = item["available"] != false
                        Row(
                            Modifier.fillMaxWidth().heightIn(min = 48.dp)
                                .let { if (available) it.clickable { onOpenProduct(slug, item["id"].long() ?: 0) } else it }
                                .padding(horizontal = s.space("m"), vertical = s.space("s")).testTag("sr-item-${item["id"].text()}"),
                        ) {
                            SrImage(item["image_url"], Modifier.size(56.dp))
                            Spacer(Modifier.width(s.space("m")))
                            Column(Modifier.weight(1f)) {
                                SrBody(item["name"].text(), color = if (available) null else s.color("muted"))
                                if (item["description"].text().isNotEmpty()) Text(item["description"].text(), maxLines = 2, overflow = TextOverflow.Ellipsis, color = s.color("muted"), fontSize = s.size("small"))
                                Price(item)
                                if (!available) SrDanger(s.t("store.unavailable"))
                            }
                        }
                    }
                }
            }
            if (state.cartCount > 0) Column(Modifier.padding(s.space("m"))) { SrPrimaryButton(state.cartLabel, "sr-store-cart") { onOpenCart(slug) } }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------- product

/** The buyer's choices on a product page and the rules they follow (UI-KIT-SPEC.md §Product detail). */
class SrProductChoice(val product: Obj) {
    var variantId by mutableStateOf<Long?>(null)
    var quantity by mutableStateOf(1)
    val chosen = mutableStateMapOf<String, List<Long>>()

    val variants: List<Obj> get() = product["variants"].objs()
    val groups: List<Obj> get() = product["option_groups"].objs()

    init {
        for (g in groups) {
            val defaults = g["values"].objs().filter { it["default"].isTrue() }.mapNotNull { it["id"].long() }
            if (defaults.isNotEmpty()) chosen[g["id"].text()] = if (isMulti(g)) defaults else listOf(defaults.first())
        }
    }

    fun toggle(group: Obj, valueId: Long) {
        val key = group["id"].text()
        val current = chosen[key] ?: emptyList()
        chosen[key] = if (isMulti(group)) {
            if (valueId in current) current - valueId else current + valueId
        } else {
            if (valueId in current && !group["required"].isTrue()) emptyList() else listOf(valueId)
        }
    }

    fun isChosen(group: Obj, valueId: Long): Boolean = chosen[group["id"].text()]?.contains(valueId) == true

    /** The rule a group's current choice breaks, as a string key with its parameters; null when it is satisfied. */
    fun problem(group: Obj): Pair<String, Map<String, Any?>>? {
        val count = chosen[group["id"].text()]?.size ?: 0
        val min = (group["min"] as? Number)?.toInt() ?: 0
        val max = (group["max"] as? Number)?.toInt()
        val required = group["required"].isTrue()
        if (!isMulti(group)) return if (required && count == 0) "product.choose_one" to emptyMap() else null
        val low = if (required && min < 1) 1 else min
        if (count < low || (max != null && count > max)) {
            return if (max == null) "product.choose_min" to mapOf("min" to low) else "product.choose_range" to mapOf("min" to low, "max" to max)
        }
        return null
    }

    val variantMissing: Boolean get() = variants.isNotEmpty() && variantId == null
    val complete: Boolean get() = !variantMissing && groups.all { problem(it) == null }

    /** One unit's price in cents: the variant's (else the product's) plus the chosen values' deltas. */
    val unitCents: Long
        get() {
            val variant = variants.firstOrNull { it["id"].text() == variantId.text() && variantId != null }
            var cents = centsOf(variant?.get("price") ?: product["price"])
            for (g in groups) for (v in g["values"].objs()) if (isChosen(g, v["id"].long() ?: -1)) cents += centsOf(v["delta"])
            return cents
        }

    val lineCents: Long get() = unitCents * quantity

    val body: Obj
        get() = buildMap {
            put("product_id", product["id"])
            variantId?.let { put("product_variant_id", it) }
            put("qty", quantity)
            if (chosen.values.any { it.isNotEmpty() }) put("options", chosen.filterValues { it.isNotEmpty() }.toMap())
        }

    companion object {
        fun isMulti(group: Obj): Boolean = group["type"] == "checkbox"
    }
}

/** The state of [ProductDetail] (UI-KIT-SPEC.md §Product detail). */
class ProductDetailState(val env: SrEnv, val slug: String, val productId: Long) {
    var loading by mutableStateOf(true)
        private set
    var error by mutableStateOf<Throwable?>(null)
        private set
    var choice by mutableStateOf<SrProductChoice?>(null)
        private set
    var tried by mutableStateOf(false)
        private set
    var sending by mutableStateOf(false)
        private set
    var message by mutableStateOf<String?>(null)
        private set

    suspend fun reload() {
        loading = true
        error = null
        attempt {
            choice = SrProductChoice(env.api.platformAppStoreProduct(slug, productId).data())
            tried = false
        }.onFailure { error = it }
        loading = false
    }

    val orderable: Boolean get() = choice?.product.let { it != null && it["available"] != false && it["accepting_orders"] != false }

    /** Adds the line; a missing choice marks its group and sends nothing. Answers the cart. */
    suspend fun add(): Obj? {
        val c = choice ?: return null
        tried = true
        message = null
        if (!c.complete || !orderable) return null
        sending = true
        val result = attempt { env.api.platformAppStoreCartAdd(slug, body = c.body.json()).data() }
        result.onSuccess { message = env.t("product.added") }.onFailure { e ->
            val m = (e as? SuperrouteException)?.let { env.errorBody(it)["message"] as? String }
            message = if (e is SuperrouteException && e.status == 422 && m != null) m else env.errorText(e)
        }
        sending = false
        return result.getOrNull()
    }
}

/** One product: variants, options, quantity and **Add to cart**. [onAdded] gets the cart the call answers. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProductDetail(slug: String, productId: Long, onAdded: (cart: Obj) -> Unit = {}, onOpenGroupBuy: (code: String) -> Unit = {}, modifier: Modifier = Modifier) {
    val s = superroute()
    val state = rememberLoaded(slug, productId, create = { ProductDetailState(it, slug, productId) }) { reload() }
    val scope = rememberCoroutineScope()
    SrFormFrame(state.loading, state.error, { scope.launch { state.reload() } }) {
        val choice = state.choice ?: return@SrFormFrame
        val p = choice.product
        val currency = p["currency"]
        val images = p["images"].list().map { it.text() }.filter { it.isNotEmpty() }
        Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(s.space("m"))) {
            if (images.isNotEmpty()) {
                LazyRow(Modifier.fillMaxWidth().height(220.dp), horizontalArrangement = Arrangement.spacedBy(s.space("xs"))) {
                    items(images) { SrImage(it, Modifier.fillParentMaxWidth().height(220.dp)) }
                }
            }
            Spacer(Modifier.height(s.space("m")))
            Text(p["name"].text(), fontSize = s.size("headline"), fontWeight = FontWeight.SemiBold, color = s.color("onSurface"))
            Price(p)
            if (p["description"].text().isNotEmpty()) SrBody(p["description"].text(), Modifier.padding(top = s.space("s")))
            val allergens = p["allergens"].objs()
            if (allergens.isNotEmpty()) SrMuted("${s.t("product.allergens")}: ${allergens.joinToString(", ") { (it["label"] ?: it["code"]).text() }}", Modifier.padding(top = s.space("s")))
            (p["group_buy"] as? Map<*, *>)?.let { gb ->
                AssistChip(onClick = { onOpenGroupBuy(gb["code"].text()) }, label = { Text(s.t("product.group_buy", "price" to s.money(gb["price"], currency))) },
                    modifier = Modifier.padding(top = s.space("s")).heightIn(min = 44.dp).testTag("sr-product-group-buy"))
            }
            if (choice.variants.isNotEmpty()) {
                Spacer(Modifier.height(s.space("l")))
                SrBody("${s.t("product.variant")} *", weight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(s.space("xs"))) {
                    choice.variants.forEach { v ->
                        val id = v["id"].long() ?: 0
                        FilterChip(selected = choice.variantId == id, onClick = { choice.variantId = id }, modifier = Modifier.heightIn(min = 44.dp).testTag("sr-variant-$id"),
                            label = { Text("${v["name"].text()} · ${s.money(v["price"], currency)}") })
                    }
                }
                if (state.tried && choice.variantMissing) SrDanger(s.t("product.choose_one"), Modifier.testTag("sr-variant-problem"))
            }
            choice.groups.forEach { g ->
                Spacer(Modifier.height(s.space("l")))
                SrBody("${g["label"].text()}${if (g["required"].isTrue()) " *" else ""}", weight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(s.space("xs"))) {
                    g["values"].objs().forEach { v ->
                        val id = v["id"].long() ?: 0
                        val label = if (centsOf(v["delta"]) == 0L) v["label"].text() else "${v["label"].text()} +${s.money(v["delta"], currency)}"
                        FilterChip(selected = choice.isChosen(g, id), onClick = { choice.toggle(g, id) }, label = { Text(label) },
                            modifier = Modifier.heightIn(min = 44.dp).testTag("sr-option-${g["id"].text()}-$id"))
                    }
                }
                val problem = choice.problem(g)
                if (state.tried && problem != null) SrDanger(s.env.t(problem.first, problem.second), Modifier.testTag("sr-option-problem-${g["id"].text()}"))
            }
            Spacer(Modifier.height(s.space("l")))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Stepper(choice.quantity, "sr-qty", minusEnabled = choice.quantity > 1, onMinus = { choice.quantity-- }, onPlus = { choice.quantity++ })
                Spacer(Modifier.weight(1f))
                Text(formatMoney(centsText(choice.lineCents), currency as? String), style = s.figureStyle(), modifier = Modifier.testTag("sr-line-price"))
            }
            SrNotice(state.message, "sr-product-message")
            SrPrimaryButton(s.t("product.add"), "sr-product-add", enabled = !state.sending && state.orderable) { scope.launch { state.add()?.let(onAdded) } }
        }
    }
}

/** A quantity stepper: − n +, each a 48 dp target with a label. */
@Composable
internal fun Stepper(value: Int, tag: String, minusEnabled: Boolean = true, plusEnabled: Boolean = true, onMinus: () -> Unit, onPlus: () -> Unit) {
    val s = superroute()
    Row(verticalAlignment = Alignment.CenterVertically) {
        androidx.compose.material3.OutlinedButton(onClick = onMinus, enabled = minusEnabled, modifier = Modifier.size(48.dp).testTag("$tag-minus").semantics { contentDescription = "−" },
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)) { Text("−") }
        Text("$value", modifier = Modifier.width(40.dp).testTag(tag), textAlign = TextAlign.Center, fontSize = s.size("body"))
        androidx.compose.material3.OutlinedButton(onClick = onPlus, enabled = plusEnabled, modifier = Modifier.size(48.dp).testTag("$tag-plus").semantics { contentDescription = "+" },
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)) { Text("+") }
    }
}

// ---------------------------------------------------------------------------------------------------------- cart

/** The state of [Cart] (UI-KIT-SPEC.md §Cart). */
class CartState(val env: SrEnv, val slug: String) {
    var loading by mutableStateOf(true)
        private set
    var error by mutableStateOf<Throwable?>(null)
        private set
    var cart by mutableStateOf<Obj>(emptyMap())
        private set
    var busy by mutableStateOf(false)
        private set
    var message by mutableStateOf<String?>(null)
        private set

    val items: List<Obj> get() = cart["items"].objs()
    val currency: String? get() = cart["currency"] as? String

    suspend fun reload() {
        loading = true
        error = null
        apply { env.api.platformAppStoreCart(slug) }
        loading = false
    }

    /** Shows the cart a change answers. */
    private suspend fun apply(call: suspend () -> kotlinx.serialization.json.JsonElement) {
        busy = true
        message = null
        attempt { call().data() }.onSuccess {
            cart = it
            error = null
        }.onFailure { if (cart.isEmpty()) error = it else message = env.errorText(it) }
        busy = false
    }

    /** Sets a line's quantity; 0 removes it. */
    suspend fun setQuantity(line: Obj, qty: Long) = apply { env.api.platformAppStoreCartUpdate(slug, line["id"].long() ?: 0, body = body("qty" to qty)) }

    suspend fun remove(line: Obj) = apply { env.api.platformAppStoreCartRemove(slug, line["id"].long() ?: 0) }
}

/** One store's cart. **Checkout** raises [onCheckout]. */
@Composable
fun Cart(slug: String, onCheckout: (slug: String) -> Unit = {}, modifier: Modifier = Modifier) {
    val s = superroute()
    val state = rememberLoaded(slug, create = { CartState(it, slug) }) { reload() }
    val scope = rememberCoroutineScope()
    val items = state.items
    Column(modifier.fillMaxSize()) {
        SrNotice(state.message, "sr-cart-message", danger = true)
        Column(Modifier.weight(1f)) {
            SrStateView(state.loading, state.error, items.isEmpty(), s.t("cart.empty"), { scope.launch { state.reload() } }) {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(items) { line ->
                        val id = line["id"].text()
                        val qty = line["qty"].long() ?: 1
                        Row(Modifier.fillMaxWidth().padding(s.space("m")).testTag("sr-cart-line-$id"), verticalAlignment = Alignment.CenterVertically) {
                            SrImage(line["image_url"], Modifier.size(56.dp))
                            Spacer(Modifier.width(s.space("m")))
                            Column(Modifier.weight(1f)) {
                                SrBody(line["name"].text(), weight = FontWeight.SemiBold)
                                if (line["options_label"].text().isNotEmpty()) SrMuted(line["options_label"].text(), small = true)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Stepper(qty.toInt(), "sr-cart-qty-$id", minusEnabled = !state.busy, plusEnabled = !state.busy,
                                        onMinus = { scope.launch { state.setQuantity(line, qty - 1) } }, onPlus = { scope.launch { state.setQuantity(line, qty + 1) } })
                                    SrTextButton(s.t("sform.remove_package"), "sr-cart-remove-$id", enabled = !state.busy) { scope.launch { state.remove(line) } }
                                }
                            }
                            SrBody(s.money(line["total"], state.currency), Modifier.testTag("sr-cart-total-$id"))
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
        if (items.isNotEmpty()) {
            Column(Modifier.padding(s.space("m"))) {
                SrAmount(s.t("cart.subtotal"), s.money(state.cart["subtotal"], state.currency), "sr-cart-subtotal", strong = true)
                Spacer(Modifier.height(s.space("s")))
                SrPrimaryButton(s.t("cart.checkout"), "sr-cart-checkout", enabled = !state.busy) { onCheckout(slug) }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------- checkout

private val CHECKOUT_ADDRESS = listOf("address_1", "address_2", "city", "province", "country", "postcode")
private val CHECKOUT_LABELS = mapOf(
    "name" to "rform.name", "telephone" to "rform.phone", "email" to "rform.email", "address_1" to "rform.address_1", "address_2" to "rform.address_2",
    "city" to "rform.city", "province" to "rform.province", "country" to "rform.country", "postcode" to "rform.postcode",
)

/** A slot day (`2026-10-14`, the store's own date) as the medium date; the text as given when it is not a date. */
internal fun dayLabel(date: String, env: SrEnv): String =
    parseIsoDate(date)?.takeIf { date.length == 10 }?.let { DateFormat.getDateInstance(DateFormat.MEDIUM, env.strings.javaLocale).format(it) } ?: date

/** The state of [Checkout] (UI-KIT-SPEC.md §Checkout). */
class CheckoutState(val env: SrEnv, val slug: String) {
    var loading by mutableStateOf(true)
        private set
    var error by mutableStateOf<Throwable?>(null)
        private set
    var quote by mutableStateOf<Obj>(emptyMap())
        private set
    var type by mutableStateOf<String?>(null)
        private set
    var shelfId by mutableStateOf<Long?>(null)
        private set
    var day by mutableStateOf<String?>(null)
        private set
    /** The chosen slot; null = as soon as possible. */
    var slot by mutableStateOf<String?>(null)
        private set
    var method by mutableStateOf<String?>(null)
    val text = mutableStateMapOf<String, String>()
    val errors = mutableStateMapOf<String, String>()
    var messages by mutableStateOf<List<String>>(emptyList())
        private set
    var sending by mutableStateOf(false)
        private set
    var placed by mutableStateOf<Obj?>(null)
        private set
    private var asked: Obj? = null

    fun v(field: String): String = text[field]?.trim() ?: ""
    fun set(field: String, value: String) { text[field] = value }

    val requestedAt: String? get() = if (day != null && slot != null) "$day $slot" else null

    /** What the quote is asked with (§Checkout: the order type, the postcode, the time, the coupon, the locker). */
    val quoteRequest: Obj
        get() = buildMap {
            type?.let { put("order_type", it) }
            if (type == "delivery" && v("postcode").isNotEmpty()) put("postcode", v("postcode"))
            requestedAt?.let { put("requested_at", it) }
            if (v("coupon_code").isNotEmpty()) put("coupon_code", v("coupon_code"))
            if (type == "locker" && shelfId != null) put("shelf_id", shelfId)
        }

    suspend fun reload() {
        loading = true
        error = null
        placed = null
        attempt { ask(force = true) }.onFailure { error = it }
        loading = false
    }

    /** Asks the quote when its inputs changed since the last one. */
    suspend fun ask(force: Boolean = false) {
        val request = quoteRequest
        if (!force && request == asked) return
        asked = request
        val q = env.api.platformAppStoreCheckoutQuote(slug, body = request.json()).data()
        quote = q
        type = q["order_type"] as? String ?: type
        val methods = choosable
        if (method == null || method !in methods) method = methods.firstOrNull()
        val slots = this.slots
        if (!slots["asap"].isTrue() && slot == null) {
            slots["days"].objs().firstOrNull { it["slots"].list().isNotEmpty() }?.let {
                day = it["date"].text()
                slot = it["slots"].list().first().text()
            }
        }
        // The choices the answer made for the person (type, first slot) are not a change to quote again.
        asked = quoteRequest
    }

    suspend fun askQuietly() { attempt { ask() } }

    val wallet: Obj get() = quote["wallet"].obj()
    val methods: List<String> get() = quote["payment_methods"].list().map { it.text() }
    val choosable: List<String> get() = methods.filter { it != "wallet" || wallet["covers"].isTrue() }
    val types: List<String> get() = quote["order_types"].list().map { it.text() }
    val slots: Obj get() = quote["slots"].obj()[type ?: ""].obj()
    val days: List<Obj> get() = slots["days"].objs().filter { it["slots"].list().isNotEmpty() }
    val daySlots: List<String> get() = slots["days"].objs().firstOrNull { it["date"].text() == day }?.get("slots").list().map { it.text() }
    val cabinets: List<Obj> get() = quote["locker_cabinets"].objs().filter { it["covers_all"].isTrue() }
    val quoteErrors: List<String> get() = quote["errors"].list().map { it.text() }
    fun reason(code: String): String = quote["reasons"].obj()[code]?.text() ?: code
    val canPlace: Boolean get() = !sending && quoteErrors.isEmpty() && quote["ok"] != false

    fun chooseType(type: String) { this.type = type; day = null; slot = null }
    fun chooseCabinet(id: Long) { shelfId = id }
    fun chooseAsap() { day = null; slot = null }
    fun chooseDay(day: Obj) { this.day = day["date"].text(); slot = day["slots"].list().firstOrNull()?.text() }
    fun chooseSlot(slot: String) { this.slot = slot }

    fun methodLabel(m: String): String = when (m) {
        "stripe" -> env.t("checkout.pay_stripe")
        "offline" -> env.t("checkout.pay_offline")
        "wallet" -> env.t("checkout.pay_wallet", "amount" to formatMoney(wallet["balance"], quote["currency"] as? String))
        else -> m
    }

    fun validate(): Boolean {
        errors.clear()
        fun need(f: String, missing: Boolean) { if (missing) errors[f] = env.t("rform.required") }
        need("name", v("name").isEmpty())
        need("telephone", v("telephone").isEmpty())
        if (type == "delivery") CHECKOUT_ADDRESS.filter { it != "address_2" }.forEach { need(it, v(it).isEmpty()) }
        if (type == "locker") need("shelf_id", shelfId == null)
        need("payment_method", method == null)
        return errors.isEmpty()
    }

    fun body(): Obj = buildMap {
        put("order_type", type)
        listOf("name", "telephone", "email", "note", "coupon_code").forEach { if (v(it).isNotEmpty()) put(it, v(it)) }
        if (type == "delivery") {
            CHECKOUT_ADDRESS.forEach { if (v(it).isNotEmpty()) put(it, v(it)) }
            if (v("delivery_instruction").isNotEmpty()) put("delivery_instruction", v("delivery_instruction"))
        }
        if (type == "locker") put("shelf_id", shelfId)
        requestedAt?.let { put("requested_at", it) }
        put("payment_method", method)
    }

    /** What placing answered: the payment to present (stripe) or the placed order. */
    sealed class Outcome {
        class Payment(val payment: Obj, val order: Obj) : Outcome()
        class Placed(val order: Obj) : Outcome()
    }

    suspend fun place(): Outcome? {
        messages = emptyList()
        if (!validate()) return null
        sending = true
        val result = attempt {
            val data = env.api.platformAppStoreCheckoutPlace(slug, body = body().json()).data()
            val order = data["order"].obj()
            val payment = data["payment"].obj()
            if (payment["method"] == "stripe") Outcome.Payment(payment, order) else Outcome.Placed(order).also { placed = order }
        }
        result.onFailure { e ->
            val b = (e as? SuperrouteException)?.let { env.errorBody(it) } ?: emptyMap()
            val reasons = b["reasons"].obj()
            messages = if (reasons.isNotEmpty()) reasons.values.map { it.text() }
            else listOf(if (e is SuperrouteException && e.status == 422 && b["message"] is String) b["message"] as String else env.errorText(e))
        }
        sending = false
        return result.getOrNull()
    }
}

/** Prices the cart and places the order; card payment is the app's ([onPayment] with `client_secret` / `publishable_key`). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Checkout(slug: String, onPayment: (payment: Obj, order: Obj) -> Unit = { _, _ -> }, onPlaced: (order: Obj) -> Unit = {}, modifier: Modifier = Modifier) {
    val s = superroute()
    val state = rememberLoaded(slug, create = { CheckoutState(it, slug) }) { reload() }
    val scope = rememberCoroutineScope()
    val request = state.quoteRequest
    LaunchedEffect(state, request) {
        if (state.loading) return@LaunchedEffect
        delay(400)
        state.askQuietly()
    }
    SrFormFrame(state.loading, state.error, { scope.launch { state.reload() } }) {
        state.placed?.let {
            Text(s.t("checkout.placed", "code" to it["code"]), modifier = Modifier.fillMaxWidth().padding(s.space("l")).testTag("sr-checkout-placed"),
                textAlign = TextAlign.Center, fontSize = s.size("title"))
            return@SrFormFrame
        }
        val q = state.quote
        val currency = q["currency"]
        val e = state.errors
        @Composable fun field(f: String, label: String, required: Boolean = false, multiline: Boolean = false) =
            SrField(state.text[f] ?: "", { state.set(f, it) }, label, "sr-checkout-$f", required = required, error = e[f], multiline = multiline)
        @Composable fun chips(options: List<Pair<String, String>>, selected: String?, tag: String, enabled: (String) -> Boolean = { true }, onChoose: (String) -> Unit) =
            FlowRow(horizontalArrangement = Arrangement.spacedBy(s.space("xs"))) {
                options.forEach { (key, label) ->
                    FilterChip(selected = selected == key, enabled = enabled(key), onClick = { onChoose(key) }, label = { Text(label) },
                        modifier = Modifier.heightIn(min = 44.dp).testTag("$tag-$key"))
                }
            }
        Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(s.space("m"))) {
            state.messages.forEach { SrDanger(it, Modifier.testTag("sr-checkout-message")) }
            SrTitle(s.t("checkout.order_type"))
            chips(state.types.map { it to s.t("checkout.type_$it") }, state.type, "sr-checkout-type") { state.chooseType(it) }
            SrTitle(s.t("checkout.contact"))
            field("name", s.t("rform.name"), true)
            field("telephone", s.t("rform.phone"), true)
            field("email", s.t("rform.email"))
            if (state.type == "delivery") {
                SrTitle(s.t("checkout.address"))
                CHECKOUT_ADDRESS.forEach { field(it, s.t(CHECKOUT_LABELS.getValue(it)), it != "address_2") }
                field("delivery_instruction", s.t("checkout.instruction"), multiline = true)
            }
            if (state.type == "locker") {
                SrTitle(s.t("checkout.cabinet"))
                chips(state.cabinets.map { it["shelf_id"].text() to listOf(it["code"].text(), it["address"].text()).filter { x -> x.isNotEmpty() }.joinToString(" · ") },
                    state.shelfId?.toString(), "sr-checkout-cabinet") { state.chooseCabinet(it.toLong()) }
                e["shelf_id"]?.let { SrDanger(it) }
            }
            if (state.slots.isNotEmpty()) {
                SrTitle(s.t("checkout.time"))
                val options = buildList {
                    if (state.slots["asap"].isTrue()) add("asap" to s.t("checkout.asap"))
                    state.days.forEach { add(it["date"].text() to dayLabel(it["date"].text(), s.env)) }
                }
                chips(options, if (state.slot == null) "asap" else state.day, "sr-checkout-day") { key ->
                    if (key == "asap") state.chooseAsap() else state.days.firstOrNull { it["date"].text() == key }?.let(state::chooseDay)
                }
                if (state.day != null) chips(state.daySlots.map { it to it }, state.slot, "sr-checkout-slot") { state.chooseSlot(it) }
            }
            Spacer(Modifier.height(s.space("m")))
            field("coupon_code", s.t("rform.coupon"))
            field("note", s.t("sform.note"), multiline = true)
            SrTitle(s.t("checkout.payment"))
            chips(state.methods.map { it to state.methodLabel(it) }, state.method, "sr-checkout-pay", enabled = { it != "wallet" || state.wallet["covers"].isTrue() }) { state.method = it }
            if (state.wallet.isNotEmpty() && !state.wallet["covers"].isTrue()) SrMuted(s.t("checkout.wallet_short"), Modifier.testTag("sr-checkout-wallet-short"))
            e["payment_method"]?.let { SrDanger(it) }
            Spacer(Modifier.height(s.space("m")))
            SrAmount(s.t("cart.subtotal"), s.money(q["subtotal"], currency), "sr-checkout-subtotal")
            if (centsOf(q["delivery_fee"]) != 0L) SrAmount(s.t("checkout.delivery_fee"), s.money(q["delivery_fee"], currency), "sr-checkout-delivery-fee")
            if (centsOf(q["discount"]) != 0L) SrAmount(s.t("rform.discount"), s.money("-${q["discount"].text()}", currency), "sr-checkout-discount")
            SrAmount(s.t("sform.tax"), s.money(q["tax"] ?: 0, currency), "sr-checkout-tax")
            SrAmount(s.t("rform.total"), s.money(q["total"], currency), "sr-checkout-total", strong = true)
            if (q["price_changed"].isTrue()) SrDanger(s.t("checkout.price_changed"), Modifier.testTag("sr-checkout-price-changed"))
            state.quoteErrors.forEach { SrDanger(state.reason(it), Modifier.testTag("sr-checkout-error-$it")) }
            Spacer(Modifier.height(s.space("l")))
            SrPrimaryButton(s.t("checkout.place"), "sr-checkout-place", enabled = state.canPlace) {
                scope.launch {
                    when (val outcome = state.place()) {
                        is CheckoutState.Outcome.Payment -> onPayment(outcome.payment, outcome.order)
                        is CheckoutState.Outcome.Placed -> onPlaced(outcome.order)
                        null -> {}
                    }
                }
            }
        }
    }
}
