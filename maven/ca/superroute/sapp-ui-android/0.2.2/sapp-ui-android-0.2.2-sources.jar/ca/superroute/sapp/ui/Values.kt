package ca.superroute.sapp.ui

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import java.math.BigDecimal

/** A JSON object as the kit reads it: plain Kotlin values, numbers kept as [BigDecimal] so money never meets a float. */
typealias Obj = Map<String, Any?>

/** Converts an API answer into plain values: objects → maps, arrays → lists, numbers → BigDecimal. */
fun JsonElement?.plain(): Any? = when (this) {
    null, JsonNull -> null
    is JsonObject -> LinkedHashMap<String, Any?>().also { map -> forEach { (k, v) -> map[k] = v.plain() } }
    is JsonArray -> map { it.plain() }
    is JsonPrimitive -> if (isString) content else booleanOrNull ?: content.toBigDecimalOrNull() ?: content
}

/** Converts plain values back into JSON for a request body. */
fun Any?.toJson(): JsonElement = when (this) {
    null -> JsonNull
    is JsonElement -> this
    is Map<*, *> -> JsonObject(entries.associate { (k, v) -> "$k" to v.toJson() })
    is Iterable<*> -> JsonArray(map { it.toJson() })
    is Boolean -> JsonPrimitive(this)
    is BigDecimal -> stripTrailingZeros().let { if (it.scale() <= 0 && it.abs() < BigDecimal(Long.MAX_VALUE)) JsonPrimitive(it.toLong()) else JsonPrimitive(toDouble()) }
    is Number -> JsonPrimitive(this)
    else -> JsonPrimitive(toString())
}

/** A request body from plain values. */
fun body(vararg pairs: Pair<String, Any?>): JsonObject = (mapOf(*pairs).toJson()) as JsonObject

internal fun Map<String, Any?>.json(): JsonObject = toJson() as JsonObject

/** The value as an object (empty when it is not one). */
@Suppress("UNCHECKED_CAST")
fun Any?.obj(): Obj = (this as? Map<String, Any?>) ?: emptyMap()

/** The value as a list of objects (non-objects left out). */
@Suppress("UNCHECKED_CAST")
fun Any?.objs(): List<Obj> = (this as? List<*>)?.filterIsInstance<Map<String, Any?>>() ?: emptyList()

/** The value as a list. */
fun Any?.list(): List<Any?> = (this as? List<*>) ?: emptyList()

/** The value as text, as Dart's `'${v ?? ''}'` would show it; numbers in plain notation. */
fun Any?.text(): String = when (this) {
    null -> ""
    is BigDecimal -> toPlainString()
    else -> toString()
}

/** The value as a whole number, or null. */
fun Any?.long(): Long? = when (this) {
    is BigDecimal -> runCatching { toLong() }.getOrNull()
    is Number -> toLong()
    is String -> trim().toLongOrNull()
    else -> null
}

/** The value as a decimal, or null. */
fun Any?.decimal(): BigDecimal? = when (this) {
    is BigDecimal -> this
    is Number -> toString().toBigDecimalOrNull()
    is String -> trim().replace(',', '.').toBigDecimalOrNull()
    else -> null
}

fun Any?.isTrue(): Boolean = this == true

/** The `data` object of an answer. */
fun JsonElement.data(): Obj = plain().obj()["data"].obj()

/** The answer as an object. */
fun JsonElement.root(): Obj = plain().obj()
