package ca.superroute.sapp.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.serialization.json.JsonElement

/** Rethrows cancellation; answers every other failure. */
internal inline fun <T> attempt(block: () -> T): Result<T> = try {
    Result.success(block())
} catch (e: CancellationException) {
    throw e
} catch (e: Throwable) {
    Result.failure(e)
}

/** Pages of a list answer (`data.items` + `pagination.has_more`, or `current_page < last_page`). */
class SrPagedList(private val itemsKey: String = "items", private val load: suspend (page: Long) -> JsonElement) {
    val items = mutableStateListOf<Obj>()
    var data: Obj by mutableStateOf(emptyMap())
    var page: Long = 0
        private set
    var hasMore by mutableStateOf(true)
        private set
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<Throwable?>(null)
        private set

    suspend fun next() {
        if (loading || !hasMore) return
        loading = true
        error = null
        attempt {
            val body = load(page + 1).data()
            data = body
            items.addAll(body[itemsKey].objs())
            page++
            val pagination = body["pagination"].obj()
            val current = pagination["current_page"].long()
            val last = pagination["last_page"].long()
            hasMore = pagination["has_more"].isTrue() || (current != null && last != null && current < last)
        }.onFailure { error = it }
        loading = false
    }

    suspend fun reset() {
        items.clear()
        data = emptyMap()
        page = 0
        hasMore = true
        loading = false
        next()
    }

    /** Replaces the row with [id] (`id` compared as text). */
    fun replace(id: Any?, change: (Obj) -> Obj) {
        val i = items.indexOfFirst { it["id"].text() == id.text() }
        if (i >= 0) items[i] = change(items[i])
    }
}

/** One answer's `data`, loaded and reloaded (the shared frame of detail components). */
open class SrOneAnswer(protected val fetch: suspend () -> JsonElement) {
    var data by mutableStateOf<Obj?>(null)
    var error by mutableStateOf<Throwable?>(null)
        protected set
    var loading by mutableStateOf(true)
        protected set

    open suspend fun reload() {
        loading = true
        error = null
        attempt { data = fetch().data() }.onFailure { error = it }
        loading = false
    }
}
