package ca.superroute.sapp.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import ca.superroute.sapp.SuperrouteException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ---------------------------------------------------------------------------------------------------------- order detail

/** The state of [OrderDetail] (UI-KIT-SPEC.md §Order detail). */
class OrderDetailState(val env: SrEnv, val type: String, val id: Long) : SrOneAnswer({ env.api.platformAppOrder(type, id) }) {
    val order: Obj get() = data?.get("order").obj()
    val reference: String get() = (order["reference"] ?: order["tracking_number"] ?: order["id"] ?: id).text()
    val trackingNumber: String? get() = order["tracking_number"]?.text()
}

/** One order. [onTrack] gets its tracking number. */
@Composable
fun OrderDetail(type: String, id: Long, onTrack: (trackingNumber: String) -> Unit = {}, modifier: Modifier = Modifier) {
    val s = superroute()
    val state = rememberLoaded(type, id, create = { OrderDetailState(it, type, id) }) { reload() }
    val scope = rememberCoroutineScope()
    SrStateView(state.loading, state.error, state.data == null, "", { scope.launch { state.reload() } }) {
        val o = state.order
        Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(s.space("l"))) {
            Text(s.t("orders.type_${(state.data?.get("type") ?: type).text()}"), style = s.figureStyle())
            SrLine(s.t("order.reference"), state.reference, "sr-order-reference")
            if (o["status_label"] != null) SrLine(s.t("order.status"), o["status_label"].text(), "sr-order-status")
            if (o["total"] != null) SrLine(s.t("order.total"), s.money(o["total"], o["currency"]), "sr-order-total")
            if (o["created_at"] != null) SrLine(s.t("order.created"), s.date(o["created_at"]))
            state.trackingNumber?.let { number ->
                Spacer(Modifier.height(s.space("l")))
                SrOutlinedButton(s.t("order.track"), "sr-order-track") { onTrack(number) }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------- tracking

/** The state of [Tracking] (UI-KIT-SPEC.md §Tracking). */
class TrackingState(val env: SrEnv, initialIdentifier: String? = null) {
    var identifier by mutableStateOf(initialIdentifier ?: "")
    var answer by mutableStateOf("")
    var result by mutableStateOf<Obj?>(null)
        private set
    var message by mutableStateOf<String?>(null)
        private set
    var busy by mutableStateOf(false)
        private set

    val tracking: Obj? get() = result?.get("tracking") as? Map<String, Any?>
    val canVerify: Boolean get() = result?.get("can_verify").isTrue() && !result?.get("verified").isTrue()

    /** Every event newest first, exactly as given. */
    val events: List<Obj> get() = tracking?.get("events").objs().sortedByDescending { it["occurred_at"].text() }

    /** `tracking.status_<code>`, else the code with `_` as spaces. */
    fun status(code: Any?): String {
        val key = "tracking.status_${code.text()}"
        return if (env.strings.has(key)) env.t(key) else code.text().replace('_', ' ')
    }

    suspend fun track(verify: Boolean = false) {
        val id = identifier.trim()
        if (id.isEmpty()) return
        busy = true
        message = null
        val request = buildMap<String, Any?> {
            put("identifier", id)
            if (verify) put("answer", answer.trim())
            put("locale", env.language)
        }.json()
        attempt {
            val signedIn = env.client.isSignedIn()
            val root = (if (signedIn) env.api.platformAppTrack(request) else env.api.platformAppGuestTrack(body = request)).root()
            if (root["result"] == false) {
                result = null
                message = env.t("tracking.not_found")
            } else {
                result = root["data"].obj()
            }
        }.onFailure {
            result = null
            // A 404, or an answer of result false (raised by the client even with status 200), is a number not found.
            val notFound = it is SuperrouteException &&
                (it.status == 404 || (it.status < 400 && (it.body as? kotlinx.serialization.json.JsonObject)?.get("result")?.toString() == "false"))
            message = if (notFound) env.t("tracking.not_found") else env.errorText(it)
        }
        busy = false
    }
}

/** Tracking a parcel by number or code; works signed in (platformAppTrack) or as a guest (platformAppGuestTrack). */
@Composable
fun Tracking(initialIdentifier: String? = null, modifier: Modifier = Modifier) {
    val s = superroute()
    val state = remember(s.env) { TrackingState(s.env, initialIdentifier) }
    val scope = rememberCoroutineScope()
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(s.space("l"))) {
        OutlinedTextField(
            value = state.identifier, onValueChange = { state.identifier = it }, label = { Text(s.t("tracking.identifier")) }, singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions(onSearch = { scope.launch { state.track() } }),
            modifier = Modifier.fillMaxWidth().testTag("sr-tracking-identifier"),
        )
        Spacer(Modifier.height(s.space("m")))
        SrPrimaryButton(s.t("tracking.search"), "sr-tracking-search", enabled = !state.busy) { scope.launch { state.track() } }
        SrNotice(state.message, "sr-tracking-message")
        val tracking = state.tracking ?: return@Column
        Spacer(Modifier.height(s.space("l")))
        SrMuted(s.t("tracking.current"))
        Text(state.status(tracking["current_status"]), style = s.figureStyle(), modifier = Modifier.testTag("sr-tracking-current"))
        if (state.canVerify) {
            Spacer(Modifier.height(s.space("m")))
            SrMuted(s.t("tracking.verify_hint"))
            SrField(state.answer, { state.answer = it }, s.t("tracking.answer"), "sr-tracking-answer")
            SrOutlinedButton(s.t("tracking.verify"), "sr-tracking-verify", enabled = !state.busy) { scope.launch { state.track(verify = true) } }
        }
        SrTitle(s.t("tracking.events"))
        state.events.forEach { e ->
            Column(Modifier.fillMaxWidth().padding(vertical = s.space("s"))) {
                SrBody(state.status(e["status_code"]))
                SrMuted(s.date(e["occurred_at"]), small = true)
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------- preferences

/** The state of [NotificationPreferences] (UI-KIT-SPEC.md §Notification preferences). */
class NotificationPreferencesState(val env: SrEnv) : SrOneAnswer({ env.api.platformAppNotificationPreferences() }) {
    var message by mutableStateOf<String?>(null)
        private set

    val channels: Obj get() = data?.get("channels").obj()
    val categories: Obj get() = data?.get("categories").obj()

    /** A category's label: `prefs.category_<key>`, else the key. */
    fun categoryLabel(key: String): String = "prefs.category_$key".let { if (env.strings.has(it)) env.t(it) else key }

    /** Saves the whole `channels` and `categories` at once; the answer is the effective state; a failure puts it back. */
    suspend fun set(group: String, key: String, value: Boolean) {
        val before = data ?: return
        val changed = before + (group to (before[group].obj() + (key to value)))
        data = changed
        message = null
        attempt { env.api.platformAppUpdateNotificationPreferences(body("channels" to changed["channels"].obj(), "categories" to changed["categories"].obj())).data() }
            .onSuccess { fresh ->
                if (fresh.isNotEmpty()) data = fresh
                message = env.t("prefs.saved")
            }
            .onFailure {
                data = before
                message = env.errorText(it)
            }
    }
}

/** The person's notification channels and categories. */
@Composable
fun NotificationPreferences(modifier: Modifier = Modifier) {
    val s = superroute()
    val state = rememberLoaded(create = ::NotificationPreferencesState) { reload() }
    val scope = rememberCoroutineScope()
    SrStateView(state.loading, state.error, state.data == null, "", { scope.launch { state.reload() } }) {
        Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(s.space("l"))) {
            SrNotice(state.message, "sr-prefs-message")
            Text(s.t("prefs.channels"), style = s.figureStyle())
            for (key in listOf("in_app", "push", "email", "sms")) {
                if (!state.channels.containsKey(key)) continue
                SrSwitch(s.t("prefs.channel_$key"), state.channels[key].isTrue(), "sr-prefs-channel-$key") { scope.launch { state.set("channels", key, it) } }
            }
            if (state.categories.isNotEmpty()) {
                SrTitle(s.t("prefs.categories"))
                for (key in state.categories.keys) {
                    SrSwitch(state.categoryLabel(key), state.categories[key].isTrue(), "sr-prefs-category-$key") { scope.launch { state.set("categories", key, it) } }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------- privacy

/** The state of [AccountPrivacy] (UI-KIT-SPEC.md §Account and privacy). */
class AccountPrivacyState(val env: SrEnv) : SrOneAnswer({ env.api.platformAppPrivacy() }) {
    var sessions by mutableStateOf<List<Obj>>(emptyList())
        private set
    var message by mutableStateOf<String?>(null)
        private set

    override suspend fun reload() {
        super.reload()
        if (error != null) return
        // The list of sign-ins exists on the partner surface only; without it the rest still shows.
        sessions = attempt { env.api.partnerAppSessions().data()["items"].objs() }.getOrElse { emptyList() }
    }

    val account: Obj get() = data?.get("account").obj()
    val legal: Obj get() = data?.get("legal").obj()
    val deletion: Obj? get() = data?.get("deletion_request") as? Map<String, Any?>
    val requestOpen: Boolean get() = deletion.let { it != null && it["status"] != "cancelled" && it["status"] != "rejected" }
    val canClose: Boolean get() = !requestOpen && account["can_request_deletion"].isTrue()

    /** Signs another sign-in out (after the person confirmed) and reloads. */
    suspend fun signOut(session: Obj) {
        message = null
        attempt { env.api.partnerAppRevokeSession(session["id"].text()) }.onSuccess { reload() }.onFailure { message = env.errorText(it) }
    }

    /** Requests the account's closure (after the person confirmed); answers whether it was requested. */
    suspend fun close(reason: String): Boolean {
        message = null
        val request = buildMap<String, Any?> {
            put("confirmation", true)
            if (reason.isNotBlank()) put("reason", reason.trim())
        }.json()
        return attempt { env.api.platformAppRequestAccountDeletion(request) }
            .onSuccess {
                message = env.t("privacy.delete_requested")
                reload()
            }
            .onFailure { message = env.errorText(it) }
            .isSuccess
    }
}

/** The account, its sign-ins to this app and account closure. */
@Composable
fun AccountPrivacy(onOpenLink: (url: String) -> Unit = {}, onClosureRequested: () -> Unit = {}, modifier: Modifier = Modifier) {
    val s = superroute()
    val state = rememberLoaded(create = ::AccountPrivacyState) { reload() }
    val scope = rememberCoroutineScope()
    var ask by remember { mutableStateOf<SrAsk?>(null) }
    SrAskDialog(ask, scope, reasonLabel = s.t("privacy.delete_reason")) { ask = null }
    SrStateView(state.loading, state.error, state.data == null, "", { scope.launch { state.reload() } }) {
        val account = state.account
        Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(s.space("l"))) {
            SrNotice(state.message, "sr-privacy-message")
            Text(account["name"].text(), style = s.figureStyle())
            SrMuted(account["email"].text())
            if (state.sessions.isNotEmpty()) {
                SrTitle(s.t("privacy.sessions"))
                state.sessions.forEach { session ->
                    val id = session["id"].text()
                    val current = session["current"].isTrue()
                    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("sr-session-$id"), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            SrBody((session["device_id"] ?: session["auth_method"]).text())
                            SrMuted(if (current) s.t("privacy.this_device") else s.date(session["last_seen_at"]), small = true)
                        }
                        if (!current && session["active"].isTrue()) {
                            SrTextButton(s.t("privacy.sign_out_session"), "sr-session-sign-out-$id") {
                                ask = SrAsk(s.t("privacy.sign_out_confirm"), s.t("privacy.sign_out_session"), "sr-privacy-confirm") { state.signOut(session) }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(s.space("l")))
            state.legal["privacy_url"]?.let { url -> SrTextButton(s.t("privacy.policy"), "sr-privacy-policy") { onOpenLink(url.text()) } }
            state.legal["terms_url"]?.let { url -> SrTextButton(s.t("privacy.terms"), "sr-privacy-terms") { onOpenLink(url.text()) } }
            Spacer(Modifier.height(s.space("l")))
            if (state.requestOpen) {
                SrBody(s.t("privacy.delete_pending", "date" to s.date(state.deletion?.get("requested_at"))), Modifier.testTag("sr-privacy-pending"))
            } else if (state.canClose) {
                SrOutlinedButton(s.t("privacy.delete"), "sr-privacy-delete", danger = true, modifier = Modifier.fillMaxWidth()) {
                    ask = SrAsk(s.t("privacy.delete_confirm"), s.t("privacy.delete"), "sr-privacy-confirm", reason = true) { reason ->
                        if (state.close(reason)) onClosureRequested()
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------- returns

/** The state of [ReturnList] (UI-KIT-SPEC.md §Return list). */
class ReturnListState(val env: SrEnv) {
    var list by mutableStateOf(newList())
        private set
    var message by mutableStateOf<String?>(null)
        private set

    private fun newList() = SrPagedList { page -> env.api.platformAppReturns(page = page, perPage = 20) }

    suspend fun reload() {
        list = newList()
        list.reset()
    }

    fun confirmText(item: Obj): String = env.t("returns.cancel_confirm", "code" to (item["return_code"] ?: item["id"]))

    /** Cancels the return (after the person confirmed), shows `returns.cancelled` and reloads. */
    suspend fun cancel(item: Obj) {
        message = null
        attempt { env.api.platformAppCancelReturn(item["id"].long() ?: 0) }
            .onSuccess {
                message = env.t("returns.cancelled")
                reload()
            }
            .onFailure { message = env.errorText(it) }
    }
}

/** The person's returns. [onOpen] gets a return's id; **Start a return** raises [onCreate] when given. */
@Composable
fun ReturnList(onOpen: (id: Long) -> Unit = {}, onCreate: (() -> Unit)? = null, modifier: Modifier = Modifier) {
    val s = superroute()
    val state = rememberLoaded(create = ::ReturnListState) { reload() }
    val scope = rememberCoroutineScope()
    var ask by remember { mutableStateOf<SrAsk?>(null) }
    SrAskDialog(ask, scope) { ask = null }
    val list = state.list
    Column(modifier.fillMaxSize()) {
        if (onCreate != null) Column(Modifier.padding(s.space("m"))) { SrPrimaryButton(s.t("returns.start"), "sr-return-start", onClick = onCreate) }
        SrNotice(state.message, "sr-return-message")
        SrStateView(list.loading, list.error, list.items.isEmpty(), s.t("returns.empty"), { scope.launch { state.reload() } }) {
            LazyColumn(Modifier.fillMaxSize()) {
                items(list.items) { r ->
                    val id = r["id"].text()
                    Row(
                        Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { onOpen(r["id"].long() ?: 0) }
                            .padding(horizontal = s.space("l"), vertical = s.space("s")).testTag("sr-return-$id"),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            SrBody((r["return_code"] ?: r["id"]).text())
                            SrMuted(r["status_name"].text(), small = true)
                        }
                        if (r["can_cancel"].isTrue()) {
                            SrTextButton(s.t("returns.cancel"), "sr-return-cancel-$id") {
                                ask = SrAsk(state.confirmText(r), s.t("returns.cancel"), "sr-return-confirm") { state.cancel(r) }
                            }
                        }
                    }
                    HorizontalDivider()
                }
                item { SrLoadMore(list) }
            }
        }
    }
}
