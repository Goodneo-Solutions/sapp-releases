package ca.superroute.sapp

import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject

/** How an operation authenticates (docs/PLATFORM-APP-SDK-DESIGN.md §8, §9). */
enum class OperationAuth { TOKEN, KEY, TOKEN_OR_KEY, NONE }

/** How an operation's body is sent. */
enum class OperationBody { NONE, JSON, FORM, MULTIPART }

/**
 * One operation of a generated API. [headers] are the header parameters it declares (`Idempotency-Key`,
 * `X-Guest-Order-Token`, …); their values travel in the parameter map under the header's own name.
 */
class Operation(
    val method: String,
    val path: String,
    val auth: OperationAuth,
    val query: List<String>,
    val body: OperationBody,
    val headers: List<String> = emptyList(),
)

/**
 * The key of the parameter map that carries a call's extra query: names the spec does not declare, appended after the
 * declared ones and never replacing one.
 */
const val EXTRA_QUERY_KEY: String = "extraQuery"


/** A file sent with a multipart operation (photos, signatures). */
class OperationFile(
    val field: String,
    val bytes: ByteArray,
    val filename: String,
    val contentType: String = "application/octet-stream",
)

/** What a generated API calls for each operation: the path, query and header values (the extra query under [EXTRA_QUERY_KEY]), the body and files. */
typealias OperationCall = suspend (Operation, Map<String, Any?>, JsonObject?, List<OperationFile>) -> JsonElement
