package ca.superroute.sapp

import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject

/** How an operation authenticates (docs/PLATFORM-APP-SDK-DESIGN.md §8, §9). */
enum class OperationAuth { TOKEN, KEY, TOKEN_OR_KEY, NONE }

/** How an operation's body is sent. */
enum class OperationBody { NONE, JSON, FORM, MULTIPART }

/** One operation of a generated API. */
class Operation(
    val method: String,
    val path: String,
    val auth: OperationAuth,
    val query: List<String>,
    val body: OperationBody,
)

/** A file sent with a multipart operation (photos, signatures). */
class OperationFile(
    val field: String,
    val bytes: ByteArray,
    val filename: String,
    val contentType: String = "application/octet-stream",
)

/** What a generated API calls for each operation: the path and query values, the body and files. */
typealias OperationCall = suspend (Operation, Map<String, Any?>, JsonObject?, List<OperationFile>) -> JsonElement
