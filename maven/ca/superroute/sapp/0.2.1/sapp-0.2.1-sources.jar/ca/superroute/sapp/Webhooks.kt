package ca.superroute.sapp

import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.doubleOrNull
import java.util.Base64
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

// Superroute webhook verification: Standard Webhooks, the native signatures each sender still sends, and
// CloudEvents envelopes. The same rules, error codes and test vectors (testdata/webhooks/vectors.json) in every
// language of sApp.

/**
 * A webhook that failed verification. [code] is one of `unknown_scheme`, `invalid_secret`, `missing_header`,
 * `invalid_timestamp`, `timestamp_out_of_tolerance`, `invalid_signature`, `invalid_payload`.
 */
class WebhookVerificationException(val code: String, message: String? = null) : Exception(message ?: code)

/** A verified webhook event. */
data class WebhookEvent(
    val id: String?,
    /** The Superroute event type, without the CloudEvents `ca.superroute.` prefix. */
    val type: String?,
    val time: String?,
    val subject: String?,
    val source: String?,
    /** The sending business (CloudEvents `srbusiness`). */
    val business: Long?,
    /** The delivery attempt (CloudEvents binary `ce-srattempt`). */
    val attempt: Long?,
    /** `native`, `ce_binary` or `ce_structured`. */
    val format: String,
    /** The event: the body, or a structured envelope's `data`. */
    val data: JsonElement,
    /** The whole parsed body. */
    val payload: JsonElement,
)

/** Verifies Superroute webhooks. */
object Webhooks {
    /** Seconds a signed timestamp may be away from now. */
    const val DEFAULT_TOLERANCE: Long = 300

    /**
     * Tenant webhooks sign the time the event was dispatched and keep it on every retry (5 tries over about 3 hours),
     * so their default tolerance covers the retries. Pair it with de-duplication on the event id.
     */
    const val TENANT_TOLERANCE: Long = 12600

    val SCHEMES: List<String> = listOf("standard", "tenant", "partner_locker", "tpd", "loading_plan", "open_platform", "dataset")

    private const val TYPE_PREFIX = "ca.superroute."
    private val BASE64 = Regex("^[A-Za-z0-9+/]*={0,2}$")
    private val DIGITS = Regex("^\\d+$")
    private val INTEGER = Regex("^-?\\d+$")

    /**
     * Verifies a webhook and answers its event. Pass the raw body exactly as received, the request headers, the
     * endpoint's secrets (a `whsec_…` secret or the plain secret; two during a rotation) and the scheme the endpoint
     * signs with: `standard` (Standard Webhooks, the default), `tenant`, `partner_locker`, `tpd`, `loading_plan`,
     * `open_platform` or `dataset`. [toleranceSeconds] defaults to 300 (tenant 12600).
     */
    fun verify(
        body: ByteArray,
        headers: Map<String, String>,
        secrets: List<String>,
        scheme: String = "standard",
        toleranceSeconds: Long? = null,
        nowSeconds: Long? = null,
    ): WebhookEvent {
        if (scheme !in SCHEMES) fail("unknown_scheme", "Unknown webhook scheme $scheme.")
        if (secrets.isEmpty()) fail("invalid_secret", "No webhook secret was given.")
        val keys = secrets.map(::keyOf)
        val lower = headers.entries.associate { it.key.lowercase() to it.value }
        val read: (String) -> String? = { lower[it.lowercase()] }
        val now = nowSeconds ?: (System.currentTimeMillis() / 1000)
        checkSignature(scheme, read, body, keys, now, toleranceSeconds ?: if (scheme == "tenant") TENANT_TOLERANCE else DEFAULT_TOLERANCE)
        val payload = try {
            json.parseToJsonElement(body.toString(Charsets.UTF_8))
        } catch (e: Exception) {
            fail("invalid_payload", "The webhook body is not JSON.")
        }
        return eventOf(read, payload)
    }

    /** The same, with the body as a string (its UTF-8 bytes are verified). */
    fun verify(
        body: String,
        headers: Map<String, String>,
        secrets: List<String>,
        scheme: String = "standard",
        toleranceSeconds: Long? = null,
        nowSeconds: Long? = null,
    ): WebhookEvent = verify(body.toByteArray(Charsets.UTF_8), headers, secrets, scheme, toleranceSeconds, nowSeconds)

    private fun fail(code: String, message: String): Nothing = throw WebhookVerificationException(code, message)

    private fun keyOf(secret: String): ByteArray {
        if (secret.isEmpty()) fail("invalid_secret", "The webhook secret is empty.")
        if (secret.startsWith("whsec_")) {
            val text = secret.substring(6)
            if (!BASE64.matches(text) || text.length % 4 != 0) fail("invalid_secret", "The whsec_ secret is not valid base64.")
            val key = Base64.getDecoder().decode(text)
            if (key.isEmpty()) fail("invalid_secret", "The whsec_ secret is not valid base64.")
            return key
        }
        return secret.toByteArray(Charsets.UTF_8)
    }

    private fun mac(key: ByteArray, data: ByteArray): ByteArray =
        Mac.getInstance("HmacSHA256").apply { init(SecretKeySpec(key, "HmacSHA256")) }.doFinal(data)

    private fun hex(bytes: ByteArray): String = bytes.joinToString("") { "%02x".format(it) }

    private fun b64(bytes: ByteArray): String = Base64.getEncoder().encodeToString(bytes)

    private fun sameText(a: String, b: String): Boolean =
        java.security.MessageDigest.isEqual(a.toByteArray(Charsets.UTF_8), b.toByteArray(Charsets.UTF_8))

    private fun need(read: (String) -> String?, name: String): String =
        read(name)?.takeIf { it.isNotEmpty() } ?: fail("missing_header", "The $name header is missing.")

    private fun checkTime(raw: String, now: Long, tolerance: Long): String {
        val t = raw.trim()
        val ts = if (DIGITS.matches(t)) t.toLongOrNull() else null
        if (ts == null) fail("invalid_timestamp", "The webhook timestamp is not a number of seconds.")
        if (Math.abs(now - ts) > tolerance) fail("timestamp_out_of_tolerance", "The webhook timestamp is outside the tolerance.")
        return t
    }

    private fun entries(header: String, prefix: String): List<String> =
        header.split(Regex("[ ,]+")).filter { it.startsWith(prefix) }.map { it.substring(prefix.length) }

    private fun checkSignature(scheme: String, read: (String) -> String?, body: ByteArray, keys: List<ByteArray>, now: Long, tolerance: Long) {
        fun join(head: String) = head.toByteArray(Charsets.UTF_8) + body
        val given: List<String>
        val expected: (ByteArray) -> String
        when (scheme) {
            "standard" -> {
                val id = need(read, "webhook-id")
                val ts = need(read, "webhook-timestamp")
                val header = need(read, "webhook-signature")
                val t = checkTime(ts, now, tolerance)
                given = header.split(' ').filter { it.startsWith("v1,") }.map { it.substring(3) }
                expected = { b64(mac(it, join("$id.$t."))) }
            }
            "tenant" -> {
                val ts = need(read, "X-Webhook-Timestamp")
                val header = need(read, "X-Webhook-Signature-V2")
                val t = checkTime(ts, now, tolerance)
                given = listOf(header.trim())
                expected = { hex(mac(it, join("$t."))) }
            }
            "partner_locker", "tpd" -> {
                val ts = need(read, "X-Webhook-Timestamp")
                val delivery = need(read, "X-Webhook-Delivery-Id")
                val header = need(read, "X-Webhook-Signature")
                val t = checkTime(ts, now, tolerance)
                given = entries(header, "v1=")
                expected = { b64(mac(it, join("$t\n$delivery\n"))) }
            }
            "loading_plan", "open_platform" -> {
                val prefix = if (scheme == "open_platform") "X-Open" else "X-Webhook"
                val ts = need(read, "$prefix-Timestamp")
                val header = need(read, "$prefix-Signature")
                val t = checkTime(ts, now, tolerance)
                given = entries(header, "v1=")
                expected = { hex(mac(it, join("$t."))) }
            }
            "dataset" -> {
                val header = need(read, "X-Webhook-Signature")
                // Sent but not signed: it still turns away a plain replay of an old request.
                read("X-Webhook-Timestamp")?.takeIf { it.isNotEmpty() }?.let { checkTime(it, now, tolerance) }
                given = listOf(header.trim())
                expected = { hex(mac(it, body)) }
            }
            else -> fail("unknown_scheme", "Unknown webhook scheme $scheme.")
        }
        for (key in keys) {
            val sig = expected(key)
            if (given.any { sameText(it, sig) }) return
        }
        fail("invalid_signature", "No signature matches the secret.")
    }

    private fun str(value: JsonElement?): String? =
        (value as? JsonPrimitive)?.takeIf { it.isString && it.content.isNotEmpty() }?.content

    private fun str(value: String?): String? = value?.takeIf { it.isNotEmpty() }

    private fun int(value: JsonElement?): Long? {
        val p = value as? JsonPrimitive ?: return null
        if (p is JsonNull) return null
        if (p.isString) return int(p.content)
        val d = p.doubleOrNull ?: return null
        return if (d % 1.0 == 0.0) p.content.toLongOrNull() ?: d.toLong() else null
    }

    private fun int(value: String?): Long? = value?.takeIf { INTEGER.matches(it) }?.toLongOrNull()

    private fun stripType(type: String?): String? = if (type != null && type.startsWith(TYPE_PREFIX)) type.substring(TYPE_PREFIX.length) else type

    private fun eventOf(read: (String) -> String?, payload: JsonElement): WebhookEvent {
        val obj = payload as? JsonObject ?: JsonObject(emptyMap())
        val contentType = (read("Content-Type") ?: "").lowercase()
        val spec = obj["specversion"]
        if (contentType.startsWith("application/cloudevents+json") ||
            (spec != null && spec !is JsonNull && obj.containsKey("data") && str(obj["type"]) != null && str(obj["id"]) != null)
        ) {
            return WebhookEvent(
                id = str(obj["id"]), type = stripType(str(obj["type"])), time = str(obj["time"]), subject = str(obj["subject"]),
                source = str(obj["source"]), business = int(obj["srbusiness"]), attempt = null, format = "ce_structured",
                data = obj["data"] ?: JsonNull, payload = payload,
            )
        }
        if (str(read("ce-specversion")) != null) {
            return WebhookEvent(
                id = str(read("ce-id")), type = stripType(str(read("ce-type"))), time = str(read("ce-time")), subject = str(read("ce-subject")),
                source = str(read("ce-source")), business = int(read("ce-srbusiness")), attempt = int(read("ce-srattempt")), format = "ce_binary",
                data = payload, payload = payload,
            )
        }
        val id = listOf("webhook-id", "X-Webhook-Event-Id", "X-Webhook-Id", "X-Open-Delivery").firstNotNullOfOrNull { str(read(it)) }
            ?: str(obj["event_id"])
        val type = listOf("X-Webhook-Event-Type", "X-Open-Event", "X-Webhook-Event").firstNotNullOfOrNull { str(read(it)) }
            ?: str(obj["event_type"]) ?: str(obj["event"])
        val time = str(obj["occurred_at"]) ?: str(obj["event_time"]) ?: str(obj["timestamp"])
        return WebhookEvent(id, type, time, null, null, null, null, "native", payload, payload)
    }
}
