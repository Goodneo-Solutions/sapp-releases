package ca.superroute.sapp

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.put
import okhttp3.Call
import okhttp3.Callback
import okhttp3.FormBody
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.min

const val SDK_VERSION: String = "0.2.1"
const val DEFAULT_BASE_URL: String = "https://open.superroute.ca"

private const val TOKEN_EXCHANGE = "urn:ietf:params:oauth:grant-type:token-exchange"
private const val ID_TOKEN = "urn:ietf:params:oauth:token-type:id_token"
/** Refresh this long before the access token expires, so a call never starts with a token about to lapse. */
private const val REFRESH_MARGIN_MS = 60_000L

internal val json = Json { ignoreUnknownKeys = true; explicitNulls = false }

// ---------------------------------------------------------------------------------------------------------- errors

/**
 * Every failed call. [status] is the HTTP status (0 when the request never got an answer), [code] the server's error
 * code (`invalid_token`, `insufficient_scope`, `access_denied`, a platform app code such as `APP_ACCESS_DENIED`, …).
 */
class SuperrouteException(
    val status: Int,
    val code: String?,
    message: String?,
    val body: JsonElement = JsonNull,
    val requestId: String? = null,
) : Exception(message ?: code ?: "Request failed with status $status") {
    /** The person must sign in again: the session ended or was revoked. */
    val signInRequired: Boolean get() = status == 401 || code == "invalid_grant"

    internal companion object {
        fun from(status: Int, body: JsonElement, requestId: String?): SuperrouteException {
            val map = body as? JsonObject ?: JsonObject(emptyMap())
            fun text(key: String) = (map[key] as? JsonPrimitive)?.takeIf { it.isString }?.content
            var code = text("error") ?: text("code")
            val message = map["message"]
            val plain = (message as? JsonPrimitive)?.takeIf { it.isString }?.content
            if (code == null && plain != null && Regex("^[A-Z_]+$").matches(plain)) code = plain
            val description = text("error_description")
                ?: (message as? JsonArray)?.joinToString(" ") { (it as? JsonPrimitive)?.content ?: it.toString() }
                ?: plain
                ?: text("title")
            return SuperrouteException(status, code, description, body, text("request_id") ?: requestId)
        }
    }
}

// ---------------------------------------------------------------------------------------------------------- tokens

@Serializable
data class Tokens(
    val accessToken: String,
    val refreshToken: String? = null,
    /** Milliseconds since the epoch. */
    val expiresAt: Long,
    val scope: List<String> = emptyList(),
)

/** Where tokens are kept. Use the Android Keystore in an app (`KeystoreTokenStore` in sapp-android). */
interface TokenStore {
    suspend fun read(): Tokens?
    suspend fun write(tokens: Tokens)
    suspend fun clear()
}

/** Keeps the tokens in memory only. */
class MemoryTokenStore(initial: Tokens? = null) : TokenStore {
    @Volatile private var tokens: Tokens? = initial
    override suspend fun read(): Tokens? = tokens
    override suspend fun write(tokens: Tokens) { this.tokens = tokens }
    override suspend fun clear() { tokens = null }
}

// ---------------------------------------------------------------------------------------------------------- PKCE

private val random = SecureRandom()

private fun base64Url(bytes: ByteArray): String = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)

private fun randomString(bytes: Int): String = base64Url(ByteArray(bytes).also(random::nextBytes))

/** S256 code challenge of a verifier (RFC 7636 §4.2). */
fun codeChallenge(verifier: String): String =
    base64Url(MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.US_ASCII)))

/** A started sign-in on the Superroute sign-in page. */
class AuthorizationRequest internal constructor(
    val url: String,
    val verifier: String,
    val state: String,
    val redirectUri: String,
)

// ---------------------------------------------------------------------------------------------------------- requests

private fun text(value: Any?): String = when (value) {
    null -> ""
    is Boolean -> if (value) "1" else "0"
    is JsonPrimitive -> if (value.booleanOrNull != null) (if (value.booleanOrNull == true) "1" else "0") else value.content
    is JsonElement -> value.toString()
    is Double -> if (value % 1.0 == 0.0 && kotlin.math.abs(value) < 1e15) value.toLong().toString() else value.toString()
    else -> value.toString()
}

internal fun buildUrl(base: String, operation: Operation, params: Map<String, Any?>): HttpUrl {
    var path = Regex("\\{([^}]+)}").replace(operation.path) { m ->
        val value = params[m.groupValues[1]]
        if (value == null || text(value).isEmpty()) "" else percent(text(value))
    }
    path = path.replace(Regex("/{2,}"), "/").replace(Regex("(?<=.)/+$"), "")
    val builder = base.toHttpUrl().newBuilder().encodedPath(path.ifEmpty { "/" })
    for (name in operation.query) {
        when (val value = params[name]) {
            null, JsonNull -> {}
            is Iterable<*> -> value.forEach { builder.addQueryParameter(name, text(it)) }
            is JsonArray -> value.forEach { builder.addQueryParameter(name, text(it)) }
            else -> builder.addQueryParameter(name, text(value))
        }
    }
    return builder.build()
}

private fun percent(value: String): String =
    java.net.URLEncoder.encode(value, "UTF-8").replace("+", "%20").replace("%7E", "~")

private val JSON_TYPE = "application/json".toMediaType()

internal fun buildRequest(
    url: HttpUrl,
    operation: Operation,
    headers: Map<String, String>,
    body: JsonObject?,
    files: List<OperationFile>,
): Request {
    val requestBody = when (operation.body) {
        OperationBody.NONE -> null
        OperationBody.JSON -> body?.toString()?.toRequestBody(JSON_TYPE)
        OperationBody.FORM -> body?.let { fields ->
            FormBody.Builder().apply { fields.forEach { (k, v) -> if (v != JsonNull) add(k, text(v)) } }.build()
        }
        OperationBody.MULTIPART -> if (body == null && files.isEmpty()) null else MultipartBody.Builder().setType(MultipartBody.FORM).apply {
            body?.forEach { (k, v) ->
                when (v) {
                    JsonNull -> {}
                    is JsonArray -> v.forEach { addFormDataPart("$k[]", text(it)) }
                    else -> addFormDataPart(k, text(v))
                }
            }
            files.forEach { addFormDataPart(it.field, it.filename, it.bytes.toRequestBody(it.contentType.toMediaType())) }
        }.build()
    }
    val method = operation.method
    val payload = requestBody ?: if (method == "POST" || method == "PUT" || method == "PATCH") ByteArray(0).toRequestBody() else null
    return Request.Builder().url(url).apply { headers.forEach { (k, v) -> header(k, v) } }.method(method, payload).build()
}

private suspend fun OkHttpClient.await(request: Request): Response = suspendCancellableCoroutine { continuation ->
    val call: Call = newCall(request)
    continuation.invokeOnCancellation { call.cancel() }
    call.enqueue(object : Callback {
        override fun onFailure(call: Call, e: IOException) = continuation.resumeWithException(e)
        override fun onResponse(call: Call, response: Response) = continuation.resume(response)
    })
}

internal class Answer(val status: Int, val body: JsonElement, val requestId: String?)

/** Repeatable calls are retried on a lost connection, 502–504 and 429 with Retry-After. Writes are never retried. */
internal suspend fun send(http: OkHttpClient, request: Request, retries: Int, retryable: Boolean): Answer {
    var attempt = 0
    while (true) {
        val response = try {
            http.await(request)
        } catch (e: IOException) {
            if (retryable && attempt < retries) {
                delay(300L shl attempt)
                attempt++
                continue
            }
            throw SuperrouteException(0, "network_error", "The request could not reach Superroute. ${e.message ?: ""}".trim())
        }
        response.use {
            val retryAfter = it.header("Retry-After")
            val throttled = it.code == 429 && retryAfter != null
            if (retryable && attempt < retries && (it.code in 502..504 || throttled)) {
                delay(if (throttled) min(30L, retryAfter!!.toLongOrNull() ?: 1L) * 1000 else 300L shl attempt)
                attempt++
                return@use null
            }
            val raw = it.body?.string().orEmpty()
            val parsed = if (raw.isEmpty()) JsonNull else runCatching { json.parseToJsonElement(raw) }.getOrElse { JsonPrimitive(raw) }
            Answer(it.code, parsed, it.header("X-Request-Id"))
        }?.let { return it }
    }
}

internal fun Answer.orThrow(): JsonElement {
    if (status >= 400) throw SuperrouteException.from(status, body, requestId)
    return body
}

private fun JsonElement.field(key: String): JsonElement? = (this as? JsonObject)?.get(key)

private fun JsonElement.string(key: String): String? = (field(key) as? JsonPrimitive)?.takeIf { it.isString }?.content

// ---------------------------------------------------------------------------------------------------------- partner

/**
 * The partner profile: an app registered on the Open Platform console, acting for one person at one service provider
 * (docs/PLATFORM-APP-SDK-DESIGN.md §8).
 *
 * ```
 * val sr = PartnerClient(appCode = "p_acme_parcels", clientCode = code, appKey = key, tokenStore = KeystoreTokenStore(context))
 * sr.signInWithIdToken(googleIdToken)
 * val wallet = sr.api.platformAppWallet()
 * ```
 */
class PartnerClient(
    val appCode: String,
    @Volatile var clientCode: String? = null,
    val appKey: String? = null,
    val tokenStore: TokenStore = MemoryTokenStore(),
    baseUrl: String = DEFAULT_BASE_URL,
    @Volatile var locale: String? = null,
    val deviceId: String? = null,
    val retries: Int = 2,
    private val http: OkHttpClient = OkHttpClient(),
    private val now: () -> Long = System::currentTimeMillis,
) {
    val baseUrl: String = baseUrl.trimEnd('/')
    private val refreshLock = Mutex()
    @Volatile private var refreshing: CompletableDeferred<Tokens>? = null
    private val listeners = CopyOnWriteArrayList<(Boolean) -> Unit>()

    /** One method per operation of the partner surface. */
    val api: PartnerApi = PartnerApi(::call)

    /** Called with true when a sign-in starts a session and false when it ends. Answers the function that stops it. */
    fun onSessionChange(listener: (Boolean) -> Unit): () -> Unit {
        listeners.add(listener)
        return { listeners.remove(listener) }
    }

    private fun emit(signedIn: Boolean) = listeners.forEach { runCatching { it(signedIn) } }

    private val baseHeaders: Map<String, String>
        get() = buildMap {
            put("Accept", "application/json")
            put("X-SApp", "kotlin/$SDK_VERSION")
            locale?.let { put("Accept-Language", it) }
        }

    private fun requireClientCode(): String =
        clientCode?.takeIf { it.isNotEmpty() } ?: throw IllegalStateException("clientCode is required to sign in")

    private suspend fun tokenRequest(fields: Map<String, String?>): Tokens {
        val form = FormBody.Builder().add("client_id", appCode).apply {
            fields.forEach { (k, v) -> if (!v.isNullOrEmpty()) add(k, v) }
        }.build()
        val request = Request.Builder().url("$baseUrl/app/oauth/token").apply { baseHeaders.forEach { (k, v) -> header(k, v) } }.post(form).build()
        val body = send(http, request, 0, false).orThrow()
        val access = body.string("access_token")
            ?: throw SuperrouteException(200, "invalid_response", "The token answer had no access token.", body)
        val expiresIn = (body.field("expires_in") as? JsonPrimitive)?.doubleOrNull ?: 3600.0
        val tokens = Tokens(
            accessToken = access,
            refreshToken = body.string("refresh_token"),
            expiresAt = now() + (expiresIn * 1000).toLong(),
            scope = body.string("scope").orEmpty().split(' ').filter { it.isNotEmpty() },
        )
        val wasSignedIn = tokenStore.read() != null
        tokenStore.write(tokens)
        if (!wasSignedIn) emit(true)
        return tokens
    }

    private suspend fun endSession() {
        tokenStore.clear()
        emit(false)
    }

    /** The Superroute sign-in page (method 1): open [AuthorizationRequest.url] in a Custom Tab and pass the URL it returns to [completeSignIn]. */
    fun authorizationRequest(redirectUri: String, scope: List<String> = emptyList(), language: String? = null): AuthorizationRequest {
        val verifier = randomString(48)
        val state = randomString(16)
        val url = "$baseUrl/app/oauth/authorize".toHttpUrl().newBuilder().apply {
            addQueryParameter("response_type", "code")
            addQueryParameter("client_id", appCode)
            addQueryParameter("client_code", requireClientCode())
            addQueryParameter("redirect_uri", redirectUri)
            addQueryParameter("state", state)
            addQueryParameter("code_challenge", codeChallenge(verifier))
            addQueryParameter("code_challenge_method", "S256")
            if (scope.isNotEmpty()) addQueryParameter("scope", scope.joinToString(" "))
            (language ?: locale)?.let { addQueryParameter("language", it) }
        }.build()
        return AuthorizationRequest(url.toString(), verifier, state, redirectUri)
    }

    /** Finishes method 1 with the URL the sign-in page returned to. Throws when it does not belong to the request. */
    suspend fun completeSignIn(request: AuthorizationRequest, returnedUrl: String): Tokens {
        val query = java.net.URI(returnedUrl).rawQuery.orEmpty().split('&').filter { it.isNotEmpty() }.associate {
            val (k, v) = (it.split('=', limit = 2) + "").take(2)
            java.net.URLDecoder.decode(k, "UTF-8") to java.net.URLDecoder.decode(v, "UTF-8")
        }
        if (query["state"] != request.state) {
            throw SuperrouteException(400, "invalid_state", "The sign-in answer does not belong to this request.")
        }
        query["error"]?.let { throw SuperrouteException(400, it, query["error_description"]) }
        return tokenRequest(mapOf(
            "grant_type" to "authorization_code", "code" to query["code"], "redirect_uri" to request.redirectUri,
            "code_verifier" to request.verifier, "device_id" to deviceId,
        ))
    }

    /** Method 2: a Google or Apple ID token issued for one of the app's registered audiences. */
    suspend fun signInWithIdToken(idToken: String, scope: List<String> = emptyList()): Tokens = tokenRequest(mapOf(
        "grant_type" to TOKEN_EXCHANGE, "client_code" to requireClientCode(), "subject_token" to idToken,
        "subject_token_type" to ID_TOKEN, "scope" to scope.joinToString(" "), "device_id" to deviceId,
    ))

    /** Method 3: email and password in the app's own screens, for apps approved for it. */
    suspend fun signInWithPassword(username: String, password: String, scope: List<String> = emptyList()): Tokens = tokenRequest(mapOf(
        "grant_type" to "password", "client_code" to requireClientCode(), "username" to username, "password" to password,
        "scope" to scope.joinToString(" "), "device_id" to deviceId,
    ))

    /** One refresh at a time: concurrent calls wait for the same one (a refresh token works once). */
    suspend fun refresh(): Tokens {
        val (deferred, owner) = refreshLock.withLock {
            refreshing?.let { it to false } ?: CompletableDeferred<Tokens>().also { refreshing = it }.let { it to true }
        }
        if (!owner) return deferred.await()
        try {
            val refreshToken = tokenStore.read()?.refreshToken
            if (refreshToken == null) {
                endSession()
                throw SuperrouteException(401, "invalid_grant", "Not signed in.")
            }
            val tokens = try {
                tokenRequest(mapOf("grant_type" to "refresh_token", "refresh_token" to refreshToken, "device_id" to deviceId))
            } catch (e: SuperrouteException) {
                if (e.code == "invalid_grant" || e.status == 401) endSession()
                throw e
            }
            deferred.complete(tokens)
            return tokens
        } catch (e: Throwable) {
            deferred.completeExceptionally(e)
            throw e
        } finally {
            refreshLock.withLock { refreshing = null }
        }
    }

    private suspend fun accessToken(): String? {
        val tokens = tokenStore.read() ?: return null
        if (tokens.refreshToken != null && tokens.expiresAt - REFRESH_MARGIN_MS <= now()) return refresh().accessToken
        return tokens.accessToken
    }

    /** Ends this sign-in on the server and forgets the tokens. */
    suspend fun signOut() {
        tokenStore.read()?.refreshToken?.let { refreshToken ->
            val request = Request.Builder().url("$baseUrl/app/oauth/revoke").apply { baseHeaders.forEach { (k, v) -> header(k, v) } }
                .post(FormBody.Builder().add("token", refreshToken).add("client_id", appCode).build()).build()
            // Signing out locally never waits on the network.
            runCatching { send(http, request, 0, false) }
        }
        endSession()
    }

    suspend fun isSignedIn(): Boolean = tokenStore.read() != null

    private suspend fun headers(operation: Operation): Map<String, String> {
        val headers = baseHeaders.toMutableMap()
        if (operation.auth == OperationAuth.TOKEN || operation.auth == OperationAuth.TOKEN_OR_KEY) {
            val token = accessToken()
            if (token != null) {
                headers["Authorization"] = "Bearer $token"
                return headers
            }
            if (operation.auth == OperationAuth.TOKEN) throw SuperrouteException(401, "invalid_token", "Not signed in.")
        }
        if ((operation.auth == OperationAuth.KEY || operation.auth == OperationAuth.TOKEN_OR_KEY) && appKey != null) {
            headers["X-App-Key"] = appKey
        }
        return headers
    }

    private suspend fun call(operation: Operation, params: Map<String, Any?>, body: JsonObject?, files: List<OperationFile>): JsonElement {
        val values = params.toMutableMap()
        // Public calls name the service provider in the path; take it from the client unless the caller passes one.
        if (operation.path.contains("{clientCode}") && values["clientCode"] == null) values["clientCode"] = clientCode
        val url = buildUrl(baseUrl, operation, values)
        val retryable = operation.method == "GET"
        var headers = headers(operation)
        var answer = send(http, buildRequest(url, operation, headers, body, files), retries, retryable)
        // An access token can end early (revoked, the person's access changed): refresh once and try again.
        if (answer.status == 401 && headers.containsKey("Authorization")) {
            refresh()
            headers = headers(operation)
            answer = send(http, buildRequest(url, operation, headers, body, files), retries, retryable)
        }
        return answer.orThrow()
    }

    /** A partner GraphQL operation (open.superroute.ca/app/graphql), with the token when signed in, else the app key. */
    suspend fun graphql(query: String, variables: JsonObject = JsonObject(emptyMap())): JsonElement {
        val answer = call(
            Operation("POST", "/app/graphql", OperationAuth.TOKEN_OR_KEY, emptyList(), OperationBody.JSON),
            emptyMap(),
            buildJsonObject { put("query", query); put("variables", variables) },
            emptyList(),
        )
        val errors = answer.field("errors") as? JsonArray
        if (errors != null && errors.isNotEmpty()) {
            throw SuperrouteException(200, "graphql_error", errors.joinToString(" ") { it.string("message").orEmpty() }, answer)
        }
        return answer.field("data") ?: JsonNull
    }
}

// ---------------------------------------------------------------------------------------------------------- open

/**
 * The open profile: Open Platform capabilities (routing, geocoding, ETA, packing, …) at open.superroute.ca/v1.
 * Pass [getToken], which your backend answers with a short-lived token, inside an app; an API key only on a server.
 */
class OpenClient(
    private val getToken: suspend () -> String,
    baseUrl: String = DEFAULT_BASE_URL,
    private val locale: String? = null,
    private val retries: Int = 2,
    private val http: OkHttpClient = OkHttpClient(),
) {
    private val baseUrl = baseUrl.trimEnd('/')

    /** One method per Open Platform operation. */
    val api: OpenApi = OpenApi { operation, params, body, files ->
        val headers = buildMap {
            put("Accept", "application/json")
            put("Authorization", "Bearer ${getToken()}")
            put("X-SApp", "kotlin/$SDK_VERSION")
            locale?.let { put("Accept-Language", it) }
        }
        val request = buildRequest(buildUrl(this.baseUrl, operation, params), operation, headers, body, files)
        send(http, request, retries, operation.method == "GET").orThrow()
    }
}

// ---------------------------------------------------------------------------------------------------------- theme

/**
 * Theme tokens from the service provider's branding (the bootstrap's `client.settings.branding`, §10.3). Colours are
 * `#RRGGBB` strings; rebranding is configuration, never code.
 */
class ThemeTokens(branding: JsonObject) {
    val displayName: String? = branding.string("display_name")
    val logoUrl: String? = branding.string("logo_url")
    val colors: Map<String, String>
    val radius: Map<String, Double> = mapOf("small" to 6.0, "medium" to 10.0, "large" to 16.0)
    val spacing: Map<String, Double> = mapOf("xs" to 4.0, "s" to 8.0, "m" to 12.0, "l" to 16.0, "xl" to 24.0)
    val type: Map<String, Double> = mapOf("body" to 15.0, "small" to 13.0, "title" to 20.0, "headline" to 26.0)

    init {
        val raw = branding.string("primary_color").orEmpty()
        val primary = if (Regex("^#[0-9a-fA-F]{6}$").matches(raw)) raw.uppercase() else "#E02020"
        colors = mapOf(
            "primary" to primary,
            "onPrimary" to if (luminance(primary) > 0.4) "#111111" else "#FFFFFF",
            "primaryContainer" to mix(primary, 255, 0.85),
            "onPrimaryContainer" to mix(primary, 0, 0.55),
            "surface" to "#FFFFFF",
            "onSurface" to "#1C1C1E",
            "muted" to "#6B7280",
            "success" to "#16A34A",
            "warning" to "#FD7E14",
            "danger" to "#DC2626",
        )
    }

    private companion object {
        fun channel(hex: String, i: Int) = hex.substring(1 + i * 2, 3 + i * 2).toInt(16)

        fun luminance(hex: String): Double {
            val c = (0..2).map { i ->
                val v = channel(hex, i) / 255.0
                if (v <= 0.03928) v / 12.92 else Math.pow((v + 0.055) / 1.055, 2.4)
            }
            return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]
        }

        fun mix(hex: String, target: Int, amount: Double): String = "#" + (0..2).joinToString("") { i ->
            val v = channel(hex, i)
            "%02X".format(Math.round(v + (target - v) * amount))
        }
    }
}
